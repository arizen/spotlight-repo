function nextPage(id) {
	window.location.href = "showReport?id=" + id;
	return false;
}

flagComments=0;
function AlterComment()
{
	if(flagComments)
	{
		document.getElementById('ShowComments').className='';	
		document.getElementById('lnkShowComments').innerHTML="Hide Comments";	
		document.getElementById('ShowHideArrow').src="resources/images/Arrow_HideComments.png";	
		flagComments=0;
	}
	else
	{
		document.getElementById('ShowComments').className='hide';	
		document.getElementById('lnkShowComments').innerHTML="Show Comments";	
		document.getElementById('ShowHideArrow').src="resources/images/Arrow_ShowComments.png";	
		flagComments=1;
	}
}
function AddComments()
{
	var comment = $("#CommentsTxtArea").val();
	if(comment != null && comment != '') {
		$.post( 'addComment', $("#addCommentForm").serialize(),
			      function( data ) {
			          $("#ShowComments").html('');
			          $("#ShowComments").html(data);
			          $("#CommentsTxtArea").val("");
			          var html = $("#commentCount").html();
			          if(html.indexOf('(') != -1) {
			        	  var countStr = html.substring(html.indexOf('(')+1, html.indexOf(')'));
			        	  var count = parseInt(countStr);
			        	  count = count + 1;
			        	  $("#commentCount").html('Comments('+count+')');
			          } else {
			        	  $("#commentCount").html('Comments(1)');
			          }
			      }
		);
	}
}
	
function showMap()
{
	document.getElementById('MapDetails').className='';
}

function openBigView(ImageSrc)
{
	document.getElementById('MainImage').src=ImageSrc;
}
function updateIssue() {
	var selectedValue = $('#selectedStatus').val();
	
	if(selectedValue == 'CLOSED') {
		var choice = confirm("No further changes can be made once issue is closed. Do you still want to close the issue?");
	    if (choice == true) {
	    	if(selectedValue != '<c:out value="${issueStatus}"/>'){
	    		$('#updateIssueForm').submit();
	    	}
		} else {
			return false;
		}	
	} else {
		if(selectedValue != '<c:out value="${issueStatus}"/>'){
    		$('#updateIssueForm').submit();
    	}
	}
}