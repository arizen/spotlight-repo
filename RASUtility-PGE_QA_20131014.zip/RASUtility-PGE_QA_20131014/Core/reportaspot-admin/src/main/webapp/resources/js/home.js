function nextPage(id) {
	window.location.href = "showReport?id=" + id;
	return false;
}

function searchFilterBasedDomChanges(status,categoryType,isSpam) {

	var selectorOfa = null;
	var selectedSpan = null;
	var titleofH3 = null;
	var returnValue = "all";
	if (status != null && status != '') {
		switch (status) {
		case 'ALL':
			selectorOfa = "#allissues";
			selectedSpan = "#allissueSpan";
			titleofH3 = "All Issues ";
			if(isSpam != null && isSpam == 'true') {
				titleofH3 = "All Spam Issues";
				selectorOfa = "#spamissues";
				selectedSpan = "#spamissueSpan";
			}
			if(categoryType != null && categoryType != '' && categoryType != 'ALL') {
				titleofH3 = titleofH3 + "("+categoryType+")";
			}
			returnValue = "all";
			break;
		case 'CLOSED':
			selectorOfa = "#cloissues";
			selectedSpan = "#cloissueSpan";
			titleofH3 = "Closed Issues ";
			if(categoryType != null && categoryType != '' && categoryType != 'ALL') {
				titleofH3 = titleofH3 + "("+categoryType+")";
			}
			returnValue = "clo";
			break;
		case 'OPEN':
			selectorOfa = "#newissues";
			selectedSpan = "#newissueSpan";
			titleofH3 = "Open Issues ";
			if(categoryType != null && categoryType != '' && categoryType != 'ALL') {
				titleofH3 = titleofH3 + "("+categoryType+")";
			}
			returnValue = "new";
			break;
		case 'PENDING':
			selectorOfa = "#penissues";
			selectedSpan = "#penissueSpan";
			titleofH3 = "Pending Issues ";
			if(categoryType != null && categoryType != '' && categoryType != 'ALL') {
				titleofH3 = titleofH3 + "("+categoryType+")";
			}
			returnValue = "pen";
			break;
		default:
			selectorOfa = "#allissues";
			selectedSpan = "#allissueSpan";
			titleofH3 = "All Issues ";
			if(isSpam != null && isSpam == 'true') {
				titleofH3 = "All Spam Issues";
				selectorOfa = "#spamissues";
				selectedSpan = "#spamissueSpan";
			}
			if(categoryType != null && categoryType != '' && categoryType != 'ALL') {
				titleofH3 = titleofH3 + "("+categoryType+")";
			}
			returnValue = "all";
			break;
		}
	}
	$(selectorOfa).attr("class", "selected");
	//$(selectedSpan).attr("class", "ArrowForSelected");
	
	$(selectorOfa).parent().attr("class","allIssuesArrow");

	$("#titleh3Issues").text(titleofH3);
	
	return returnValue;
}

function pagination(currentPageNumber,totalItems) {
	
	var url = "home.html";
	if (totalItems > 1) {
		if (currentPageNumber == 0) {
			$("#pagePrev").hide();
		}else{
			$("#pagePrev a").on("click",  function(){return pageNumberSelect(currentPageNumber - 1);});
		}
		

		if(currentPageNumber == 0) {
			
			$("#page1").attr("class", "selectedpage");
			$("#page2").attr("class", "pages");
			$("#page3").attr("class", "pages");
			$("#page4").attr("class", "pages");
			
			$("#page1 a").text(currentPageNumber+1);
			$("#page2 a").text((currentPageNumber + 2));
			$("#page3 a").text((currentPageNumber + 3));
			$("#page4 a").text((currentPageNumber + 4));
			
			if (totalItems-(currentPageNumber *10) > 10) {
				$("#page2 a").on("click", function(){return pageNumberSelect(currentPageNumber + 1);});
				$("#pageNext a").on("click", function(){return pageNumberSelect(currentPageNumber + 1);});

				if (totalItems-(currentPageNumber *10) > 20) {
					$("#page3 a").on("click", function(){return pageNumberSelect(currentPageNumber + 2);});
					if (totalItems-(currentPageNumber *10) > 30) {
						$("#page4 a").on("click", function(){return pageNumberSelect(currentPageNumber + 3);});
					} else {
						$("#page4").hide();
					}
				} else {
					$("#page3").hide();
					$("#page4").hide();
				}

			} else {
				$("#page2").hide();
				$("#page3").hide();
				$("#page4").hide();
				$("#pageNext").hide();
			}
			
		} else if(currentPageNumber == 1){
			$("#page2").attr("class", "selectedpage");
			$("#page1").attr("class", "pages");
			$("#page3").attr("class", "pages");
			$("#page4").attr("class", "pages");
			
			$("#page1 a").text(currentPageNumber);
			$("#page2 a").text((currentPageNumber + 1));
			$("#page3 a").text((currentPageNumber + 2));
			$("#page4 a").text((currentPageNumber + 3));
			
			$("#page1 a").on("click", function(){return pageNumberSelect(currentPageNumber-1);});
			
			if (totalItems-(currentPageNumber *10) > 10) {
				$("#page3 a").on("click", function(){return pageNumberSelect(currentPageNumber + 1);});
				$("#pageNext a").on("click", function(){return pageNumberSelect(currentPageNumber + 1);});

				if (totalItems-(currentPageNumber *10) > 20) {
					$("#page4 a").on("click", function(){return pageNumberSelect(currentPageNumber + 2);});
				} else {
					$("#page4").hide();
				}

			} else {
				$("#page3").hide();
				$("#page4").hide();
				$("#pageNext").hide();
			}
		} else {
			
			$("#page1 a").text(currentPageNumber-1);
			$("#page2 a").text((currentPageNumber));
			$("#page3 a").text((currentPageNumber+1));
			$("#page4 a").text((currentPageNumber + 2));
			
			$("#page3").attr("class", "selectedpage");
			$("#page1").attr("class", "pages");
			$("#page2").attr("class", "pages");
			$("#page4").attr("class", "pages");
			
			$("#page1 a").on("click", function(){pageNumberSelect(currentPageNumber -2);});
			$("#page2 a").on("click", function(){pageNumberSelect(currentPageNumber-1);});
		
			if (totalItems-(currentPageNumber *10) > 10) {
				$("#page4 a").on("click", function(){pageNumberSelect(currentPageNumber + 1);});
				$("#pageNext a").on("click", function(){pageNumberSelect(currentPageNumber + 1);});
			} else {
				$("#page4").hide();
				$("#pageNext").hide();
			}
		}

		if((currentPageNumber+1)*10 > totalItems) {
			$("#showingissuetext").html("<span>Showing</span> "+(currentPageNumber*10+1)+"-"+totalItems+" <span>of</span> "+totalItems+" Issues");
		} else {
			$("#showingissuetext").html("<span>Showing</span> "+(currentPageNumber*10+1)+"-"+(currentPageNumber+1)*10+" <span>of</span> "+totalItems+" Issues");
		}
	}
}

function pageNumberSelect(pageNumber){
	$("#pageNumber").val(pageNumber);
	$("#searchFilterForm").submit();
	return false;
}


function showAdminLoginPopup() {
	$('#adminPopupDiv').show();
}


/*function validateAndSubmitForm(isGet){
	var fromdate = new Date($("#datepicker").val());
	var toDate = new Date($("#datepicker2").val());
	
	if(toDate>fromdate){
		
		if(isGet){
			$("#searchFilterForm").attr("method","get");
		}
		$("#searchFilterForm").submit();
		
	}else{
		alert("From Date cannot be larger than To Date. Please change date filter.");
		$("#datepicker2").focus();
		return false;
	}
}*/

function validateAndSubmitForm(isGet){
	
		if(isGet){
			$("#searchFilterForm").attr("method","get");
		}
		$("#searchFilterForm").submit();
		
}

function validateAndSubmitFormOnCategoryChange(changedCategoryVal, isGet) {
	
	var prevCategoryVal = $("#categoryType").val();
	if(prevCategoryVal == changedCategoryVal) {
		return false;
	}
	
	$("#categoryType").val(changedCategoryVal);
	$("#pageNumber").val("0");
	validateAndSubmitForm(isGet);
	return false;
}