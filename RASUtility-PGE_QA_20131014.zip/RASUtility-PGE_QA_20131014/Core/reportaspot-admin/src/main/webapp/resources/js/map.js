function initialize(issue,issues) {
	  var myLatlng = new google.maps.LatLng(37.846260, -121.978537);
	  var myOptions = {
	    zoom: 7,
	    center: myLatlng,
	    mapTypeId: google.maps.MapTypeId.ROADMAP
	  };
	  var map = new google.maps.Map(document.getElementById("mapThis"), myOptions);
	  var infowindow = new google.maps.InfoWindow();
	  var markers = [];

	  	$.each(issues,function(i,val){
	  		
	  		
	  		var contentString = '<div class="popupContainer">'+
			'<ul class="issueoverall">'+
				'<li class="thumbnail">'+
					'<div class="thumbnailParentDiv">';
	  		
	  		if(val.isPublic =='true' || val.isPublic ==''){
	  			contentString =contentString+'<div ></div>';
	  		}else{
	  			contentString =contentString+'<div class="MostUrgent"></div>';
	  		}
	  		contentString = contentString+	'<div class="ThumbnailData">'+
							'<img width="129" height="96"'+' src="'+val.thumbnailUrl+'">'+
						'</div>'+
					'</div>'+
				'</li>'+
				'<li class="issuedata"><a href="showReport?id='+val.id+'">'+val.titleString+'</a></li>'+
				'<li class="issuedetail">'+val.description+'</li>'+
				'<li class="issueposting">via '+val.device+'</li>'+
				'<li class="issuedate">'+val.creationTimeString+' ago <br /> '+val.status+
				'</li>'+
			'</ul>'+
		'</div>';
	  		
	  		
	  		var currentLat =  new google.maps.LatLng(val.latitude,val.longitude);
	  		
	  		 var marker = new google.maps.Marker({
		  	      position: currentLat,
//		  	      map: map,
		  	      title:val.title,
		  	  });
	  		 
	  		 markers.push(marker);
	  		 
	  		 switch (val.status) {
				case 'OPEN':
					marker.setIcon('http://maps.google.com/mapfiles/ms/icons/red-dot.png');
					break;
				case 'CLOSED':
					marker.setIcon('http://maps.google.com/mapfiles/ms/icons/green-dot.png');
					break;
				case 'PENDING':
					marker.setIcon('http://maps.google.com/mapfiles/ms/icons/orange-dot.png');
					break;
				default:
					break;
			}
	  		 
	  		 
	  		google.maps.event.addListener(marker, 'click', function() {
	  			 infowindow.close();//hide the infowindow
	  			 infowindow.setContent(contentString);//update the content for this marker
			     infowindow.open(map, marker);//"move" the info window to the clicked marker and open it
	  		});
	  	});
	  	
	  	 var markerCluster = new MarkerClusterer(map, markers);
	  
	 
  }