function validateIssue() {
	var returnVal;
	if($('#address').val() == null || $('#address').val() == '') {
		alert("Please select the location on the map");
	} else if(($('#firstName').val() != '' || $('#lastName').val() != '' || $('#phoneNumber').val() != '') && $('#emailId').val() == '') {
		alert("Email id field is mandatory if any of the reported by details are provided");
	} else if($('#latitude').val() == null || $('#latitude').val() == '' || $('#longitude').val() == null || $('#longitude').val() == '') {
		alert("Please select a proper address");
	}else if(returnVal = checkForNotification()){
		alert(returnVal);
	}else {
		saveNewIssue();
	}
}

function checkForNotification(){
	if($("#emailNoti").prop("checked")){
		if($('#emailId').val() == '' || $('#emailId').val() == undefined){
			return "Please provide Email Address for recieving Email Notifications.";
		}
	}
	
	if($("#smsNoti").prop("checked")){
		if($('#phoneNumber').val() == '' || $('#phoneNumber').val() == undefined){
			return "Please provide Phone Number for recieving SMS Notifications.";
		}
	}
}

function saveNewIssue() {
	$('#reportIssueForm').submit();
}
FotoFlag=1;
function AddMorePhoto()
{

	if(FotoFlag<3)
	{
		FotoFlag++;
		document.getElementById('photoDiv'+FotoFlag).className='';
		
		if(FotoFlag == 3){
			$("#cross2").attr("style","display: none;");
			$("#plus2").attr("class","hide");
		}else if(FotoFlag == 2){
			$("#plus1").attr("class","hide");
			$("#cross1").attr("class","hide");
		}
	}
	else
	{
		alert("You can upload a maximum of 3 photographs");
	}
	
	return false;
}

function changeClassResetVal(fileElemId,divId,isThird){
	FotoFlag--;
	$("#"+fileElemId).val("");
	$("#"+divId).attr("class","hide");
	if(isThird == 1){
		$("#cross2").attr("style","");
		$("#plus2").attr("class","");
	}else{
		$("#plus1").attr("class","");
		$("#cross1").attr("class","");
	}
	
	return false;
}

function removeFirstImage(id){
	$("#"+id).val('');
}