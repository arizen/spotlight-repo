function loadAjax(){
	
}

function registerCallbackForScroll(){
	$(window).scroll(function()
			{
			    if($(window).scrollTop() == $(document).height() - $(window).height())
			    {
			    	loadMoreData();
			    }
			});
}

function loadMoreData(){

	var selectedIssueCount = $("#selectedIssueCount").val();
	var currentPageNumber = + $("#pageNumber").val();
	if(selectedIssueCount/10 > (currentPageNumber-1)){
    	$('div#loadmoreajaxloader').show();
        $("#pageNumber").val(currentPageNumber+1);
        $.post("issues_ajax.html", $("#searchFilterForm").serialize(),
	        function(html)
	        {
	            if(html)
	            {
	                $("#postswrapper").append(html);
	                $('div#loadmoreajaxloader').hide();
	            }else
	            {
	                $('div#loadmoreajaxloader').html('<center>No more posts to show.</center>');
	            }
	        }
       );
	}else{
		$('div#loadmoreajaxloader').html('<center>No more posts to show.</center>');
		return 123;
	}

}