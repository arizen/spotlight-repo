
function normalChart(isCategory) {
	var chart;
	chart = new Highcharts.Chart({
		chart: {
			renderTo: 'highDiv',
			plotBackgroundColor: null,
			plotBorderWidth: null,
			plotShadow: false,
			events: {
                load: function(){
                	if(isCategory){
	                	$.ajax({
	                	       url: 'getCategoryChartData',
	                	       success: function(point) {
	                	           // add the point
	                	    	   $.each(point,function(index,value){
	                	    		   chart.series[0].addPoint(value);
	                	    	   });
	                	          
	                	           
	                	       },
	                	       cache: false
	                	   });
                	}else{
	                	$.ajax({
	             	       url: 'getChartPieData',
	             	       success: function(point) {
	             	           // add the point
	             	    	   $.each(point,function(index,value){
	             	    		   chart.series[0].addPoint(value);
	             	    	   });
	             	          
	             	           
	             	       },
	             	       cache: false
	             	   });
                	}
                }
            }
		},
		title: {
			text: 'Issues by Status'
		},
		tooltip: {
			formatter: function() {
				return '<b>'+ this.point.name +'</b>: '+ this.percentage.toFixed(2) +' %';
			},
			valueDecimals: 2
		},
		plotOptions: {
			pie: {
				allowPointSelect: true,
				cursor: 'pointer',
				dataLabels: {
					enabled: true,
					color: '#000000',
					connectorColor: '#000000',
					formatter: function() {
						return '<b>'+ this.point.name +'</b>: '+ this.point.y +' ';
					}
				}
			}
		},
		series: [{
			type: 'pie',
			name: 'Issue Stat',
			data: [
/*				['Firefox',   45.0],
				['IE',       26.8],
				{
					name: 'Chrome',
					y: 12.8,
					sliced: true,
					selected: true
				},
				['Safari',    8.5],
				['Opera',     6.2],
				['Others',   0.7]
*/			]
		}]
	});
};

