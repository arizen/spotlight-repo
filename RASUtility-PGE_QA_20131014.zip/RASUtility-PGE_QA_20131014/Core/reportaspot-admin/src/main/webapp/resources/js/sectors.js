function initializeMap() {
	var myLatlng = new google.maps.LatLng(42, -124);
	var myOptions = {
		zoom : 7,
		center : myLatlng,
		mapTypeId : google.maps.MapTypeId.ROADMAP
	}
	var map = new google.maps.Map(document.getElementById("mapThis"), myOptions);

	var marker = new google.maps.Marker({
		position : myLatlng,
		map : map
	});

	var drawingManager = new google.maps.drawing.DrawingManager({
		drawingMode : google.maps.drawing.OverlayType.POLYGON,
		drawingControl : true,
		drawingControlOptions : {
			position : google.maps.ControlPosition.TOP_CENTER,
			drawingModes : [google.maps.drawing.OverlayType.POLYGON ]
		},
		polygonOptions :  {editable: true},
		polylineOptions : {editable: true}
	});
	drawingManager.setMap(map);

	google.maps.event.addListener(drawingManager, 'overlaycomplete', function(
			event) {
		if (event.type == google.maps.drawing.OverlayType.POLYGON) {
			var mvcArray = event.overlay.getPaths();// This is MVCArray.
			console.log(mvcArray.getLength());
			mvcArray.forEach(function(element,index){
				console.log(JSON.stringify(element.getArray()));
				$("#polygonPathJson").val(JSON.stringify(element.getArray()));
//				element.forEach(function(latlng,index){
//					console.log(JSON.stringify(latlng));
//				});
			});
		}
	});

	return map;
}

function drawPolygonOverlays(polygonOverlays,map){

	//This iterates over region which contains the region name and the region geoPoints
	infowindow = new google.maps.InfoWindow();
	$.each(polygonOverlays,function(index,region){
		var regionGeoPoints = region.geoPoints;
		var arrayPoints = new Array();
		$.each(regionGeoPoints,function(index,point){
			var latLng = new google.maps.LatLng(point.Xa,point.Ya);
			arrayPoints[index] = latLng;
		});

		var bermudaTriangle = new google.maps.Polygon({
		    paths: arrayPoints,
		    strokeColor: "#FF0000",
		    strokeOpacity: 0.8,
		    strokeWeight: 3,
		    fillColor: "#FF0000",
		    fillOpacity: 0.35,
		    title: region.name
		  });
		bermudaTriangle.setMap(map);

		  google.maps.event.addListener(bermudaTriangle, 'click', function(event){
			  showArrays(event,map,infowindow,region.name,bermudaTriangle);
		  });
	});
}

function showArrays(event,map,infowindow,region,triangle) {
	 infowindow.close();//hide the infowindow
	  // Since this Polygon only has one path, we can call getPath()
	  // to return the MVCArray of LatLngs
	  var vertices = triangle.getPath();

	  var contentString = "<b>"+region+"</b><br />";
//	  // Iterate over the vertices.
//	  for (var i =0; i < vertices.length; i++) {
//	    var xy = vertices.getAt(i);
//	    contentString += "<br />" + "Coordinate: " + i + "<br />" + xy.lat() +"," + xy.lng();
//	  }

	  // Replace our Info Window's content and position
	  infowindow.setContent(contentString);
	  infowindow.setPosition(event.latLng);

	  infowindow.open(map);
	}


function submitCheck() {
	if ($("#polygonPathJson").val() == '') {
		alert("Select Area");
		return false;
	}
	if ($("#name").val == '') {
		alert("give region name");
		return false;
	}

	$("#formSubmit").submit();
	return true;
};
