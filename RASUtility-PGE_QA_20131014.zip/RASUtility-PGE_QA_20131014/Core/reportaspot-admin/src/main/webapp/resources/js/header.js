$(document).ready(function() {
	
	$(function(){
		$.pnotify.defaults.styling = "jqueryui";
		$.pnotify.defaults.history = false;
		$.pnotify.defaults.delay = 500;
	});
	
	$('textarea[maxlength]').live('keyup blur', function() { 
        // Store the maxlength and value of the field. 
        var maxlength = $(this).attr('maxlength'); 
        var val = $(this).val(); 
 
        // Trim the field if it has content over the maxlength. 
        if (val.length > maxlength) { 
        	alert("Maximum 255 characters are allowed");
            $(this).val(val.slice(0, maxlength)); 
        } 
    }); 

	
	//select all the a tag with name equal to modal
	$('a[name=modal]').click(function(e) {
		//Cancel the link behavior
		e.preventDefault();
		
		//Get the A tag
		var id = $(this).attr('href');
	
		//Get the screen height and width
		var maskHeight = $(document).height();
		var maskWidth = $(window).width();
	
		//Set heigth and width to mask to fill up the whole screen
		$('#mask').css({'width':maskWidth,'height':maskHeight});
		
		//transition effect		
		$('#mask').fadeIn("fast");	
		$('#mask').fadeTo("fast",0.8);	
	
		//Get the window height and width
		var winH = $(window).height();
		var winW = $(window).width();
              
		//Set the popup window to center
		$(id).css('top',  winH/2-$(id).height()/2);
		$(id).css('left', winW/2-$(id).width()/2);
	
		//transition effect
		$(id).fadeIn("fast"); 
	
	});
	
	//if close button is clicked
	$('.window .close').click(function (e) {
		//Cancel the link behavior
		e.preventDefault();
		
		$('#mask').hide();
		$('.window').hide();
	});		
	
	//if mask is clicked
	/*$('#mask').click(function () {
		$(this).hide();
		$('.window').hide();
	});		*/
	$('.closepopup').click(function () {
		$('#mask').hide();
		$('.window').hide();
	});	
		

	$(window).resize(function () {
	 
 		var box = $('#boxes .window');
 
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();
      
        //Set height and width to mask to fill up the whole screen
        $('#mask').css({'width':maskWidth,'height':maskHeight});
               
        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        box.css('top',  winH/2 - box.height()/2);
        box.css('left', winW/2 - box.width()/2);
	 
	});
	
	$("#searchLink").click(function(){
		var value = $("#searchInputField").val();
		window.location.href = "home.html?se=" + value;
	});
	
	$("#searchInputField").bind("click",function(){
		var searchFieldValue = $("#searchInputField").val();
		if(searchFieldValue == 'Search'){
			$("#searchInputField").val('');
		}
	});
	
	$("#searchInputField").blur(function(){
		if($("#searchInputField").val() == ''){
			$("#searchInputField").val('Search');
		}
	});
	
	$("#searchInputField").autocomplete({
		source: function(request,response){
			$.getJSON("searchissues?query="+request.term ,function(data){
				
				var arraySi = [];
				
				$.each(data,function(index,val){
					arraySi[index] = {label: val.title ,value :val.id};
				});
				
				response(arraySi);
			});
		}
	
	,select: function(event, ui) { 
		window.location.href = "showReport?id=" + ui.item.value;
	}
});
	
});

function login(){
	var userName = $("#usernameField").val();
	var passwd = $("#passwordField").val();
	if (userName == null || userName.trim()=="") {
		alert("Please enter the username");
		return false;
	} else if(passwd == null || passwd.trim()=="") {
		alert("Please enter the password");
		return false;
	} else {
		$.ajax({
		    url: "j_spring_security_check",
		    type: "POST",
		    data: $("#loginForm").serialize(),
		    beforeSend: function (xhr) {
		        xhr.setRequestHeader("X-Ajax-call", "true");
		    },
		    success: function(result) {
		        if (result == "ok") {
		        	window.location.href = "admin/home.html";
		        } else if (result == "error") {
		        	$(".error").remove();
		            $("#loginheading").before('<div class="error">Incorrect username/password. Please try again.</div>');
		            $("#passwordField").val('');
		        }
		    }
		});
		return false;
	}
}

function loginFromLoginPage() {
	var userName = $("#usernameField").val();
	var passwd = $("#passwordField").val();
	if (userName == null || userName.trim()=="") {
		alert("Please enter the username");
		return false;
	} else if(passwd == null || passwd.trim()=="") {
		alert("Please enter the password");
		return false;
	} 
	return true;
}