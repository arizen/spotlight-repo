/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wizni.reportaspot.model.constants.ICitiConstants;
import com.wizni.reportaspot.model.domain.Admin;
import com.wizni.reportaspot.model.domain.Customer;
import com.wizni.reportaspot.model.domain.GlobalPropertyKeyValue;
import com.wizni.reportaspot.model.domain.IssueCategory;
import com.wizni.reportaspot.model.domain.LinesOfBusiness;
import com.wizni.reportaspot.model.domain.QAdminAlert;
import com.wizni.reportaspot.model.domain.QIssue;
import com.wizni.reportaspot.model.domain.QIssueCategory;
import com.wizni.reportaspot.model.domain.QLinesOfBusiness;
import com.wizni.reportaspot.model.domain.QRASWorkflows;
import com.wizni.reportaspot.model.domain.QUserRole;
import com.wizni.reportaspot.model.domain.RASWorkflows;
import com.wizni.reportaspot.model.domain.Region;
import com.wizni.reportaspot.model.domain.UserRole;
import com.wizni.reportaspot.model.domain.custom.CustomerCategoryCustomField;
import com.wizni.reportaspot.model.enums.CustomColumnType;
import com.wizni.reportaspot.model.security.ReportASpotUser;
import com.wizni.reportaspot.model.util.RASUtility;
import com.wizni.reportaspot.model.viewdto.AdminUsersDto;
import com.wizni.reportaspot.model.viewdto.CategoryDto;
import com.wizni.reportaspot.model.viewdto.ConfigurationsDto;
import com.wizni.reportaspot.model.viewdto.LineOfBusinessDto;
import com.wizni.reportaspot.model.viewdto.RASWorkflowsDto;
import com.wizni.reportaspot.model.viewdto.UserRolesDto;
import com.wizni.reportaspot.service.AdministrationService;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.service.filehandler.IFileHandlerService;
import com.wizni.reportaspot.service.filehandler.dto.FileDataDto;
import com.wizni.reportaspot.storage.repositories.AdminAlertRepository;
import com.wizni.reportaspot.storage.repositories.AdminRepository;
import com.wizni.reportaspot.storage.repositories.CustomerRepository;
import com.wizni.reportaspot.storage.repositories.IssueCategoryRepository;
import com.wizni.reportaspot.storage.repositories.IssueRepository;
import com.wizni.reportaspot.storage.repositories.LineOfBusinessRepository;
import com.wizni.reportaspot.storage.repositories.RASWorkflowsRepository;
import com.wizni.reportaspot.storage.repositories.UserRoleRepository;
import com.wizni.reportaspot.websecurity.impl.CitiUserDetailsService;

/**
 * The Class AdministratorTabController.
 */
@Controller
@RequestMapping("admin")
public class AdministratorTabController {

	/** The Constant SHOW_ADMINISTRATION_PAGE. */
	public static final String SHOW_ADMINISTRATION_PAGE = "showCategory";

	/** The Constant SHOW_CATEGORY_PAGE. */
	public static final String SHOW_CATEGORY_PAGE = "showCategory";

	/** The Constant SHOW_LINES_OF_BUSINESS_PAGE. */
	public static final String SHOW_LINES_OF_BUSINESS_PAGE = "showLineOfBusiness";

	/** The Constant SHOW_REGION_PAGE. */
	public static final String SHOW_REGION_PAGE = "showRegion";

	/** The Constant SHOW_REGION_MAP. */
	public static final String SHOW_REGION_MAP = "showRegionMap";

	/** The Constant SHOW_ADMIN_USERS_PAGE. */
	public static final String SHOW_ADMIN_USERS_PAGE = "showAdminUsers";

	/** The Constant SHOW_ROLES_PAGE. */
	public static final String SHOW_ROLES_PAGE = "showRoles";

	/** The Constant SHOW_GROOVY_FILES. */
	public static final String SHOW_DYNAMIC_RULES = "showDynamicRules";

	/** The Constant SHOW_GROOVY_FILES. */
	public static final String SHOW_CONFIGURATIONS = "showConfigurations";

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/** The issue repository. */
	@Autowired
	private IssueRepository issueRepository;

	/** The ras workflows repository. */
	@Autowired
	private RASWorkflowsRepository rasWorkflowsRepository;

	/** The customer repository. */
	@Autowired
	private CustomerRepository customerRepository;

	/** The administration service. */
	@Autowired
	private AdministrationService administrationService;

	/** The admin repository. */
	@Autowired
	private AdminRepository adminRepository;

	/** The admin alert repository. */
	@Autowired
	private AdminAlertRepository adminAlertRepository;

	/** The custom user detail service. */
	@Autowired
	private CitiUserDetailsService customUserDetailService;

	/** The issue category repository. */
	@Autowired
	private IssueCategoryRepository issueCategoryRepository;

	/** The line of business repository. */
	@Autowired
	private LineOfBusinessRepository lineOfBusinessRepository;

	/** The user role repository. */
	@Autowired
	private UserRoleRepository userRoleRepository;

	/** The file handler service. */
	@Autowired
	IFileHandlerService fileHandlerService;

	/** The Constant LOGGER. */
	private static final Logger logger = LoggerFactory.getLogger(AdministratorTabController.class);

	/**
	 * Inits the binder.
	 * 
	 * @param binder the binder
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	/**
	 * Shows Administration tab. *
	 * 
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "showAdministration.html", method = RequestMethod.GET)
	public String showAdministration(Model model, HttpServletRequest request) {
		return showCategory(model, request);
	}

	/**
	 * Shows Category Sub tab *.
	 * 
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "showCategory.html", method = RequestMethod.GET)
	public String showCategory(Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get categories view dto
		CategoryDto categoryDto = administrationService.getCategoryDto(customerId);
		model.addAttribute("categoryDto", categoryDto);
		model.addAttribute("issueCategory", new IssueCategory());

		// get region menu
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_CATEGORY_TAB);

		return SHOW_ADMINISTRATION_PAGE;
	}

	/**
	 * This adds a new category to the syste *.
	 * 
	 * @param issueCategory the issue category
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "addNewCategory", method = RequestMethod.POST)
	public String addNewCategory(@ModelAttribute("issueCategory") IssueCategory issueCategory, Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		/*
		 * Check Issue category Name if present.
		 */
		QIssueCategory qIssueCategory = QIssueCategory.issueCategory;
		IssueCategory issueCatDB = issueCategoryRepository.findOne(qIssueCategory.categoryType.eq(issueCategory.getCategoryType()));

		if (issueCatDB == null) {
			boolean isCategoryAdded = true;
			try {
				administrationService.addNewCategory(issueCategory, customerId);
			} catch (Exception e) {
				isCategoryAdded = false;
			}
			model.addAttribute("isCategoryAdded", isCategoryAdded);
		} else {
			model.addAttribute("isSameName", true);
		}

		return showCategory(model, request);
	}

	/**
	 * Shows Category Sub t *.
	 * 
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "showLineOfBusiness.html", method = RequestMethod.GET)
	public String showLinesOfBusiness(Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get line of business
		LineOfBusinessDto lineOfBusinessDto = administrationService.getLineOfBusinessDto(customerId);
		model.addAttribute("lineOfBusinessDto", lineOfBusinessDto);

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_LINE_OF_BUSINESS_TAB);

		return SHOW_LINES_OF_BUSINESS_PAGE;
	}

	/**
	 * Edits the line of busin *.
	 * 
	 * @param lineOfBusinessId the line of business id
	 * @param arrayOrder the array order
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "editLineOfBusiness.html", method = RequestMethod.GET)
	public String editLineOfBusiness(@RequestParam(value = "lineOfBusinessId") Long lineOfBusinessId,
			@RequestParam(value = "arrayOrder") List<Long> arrayOrder, Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get line of business dto for edit
		LineOfBusinessDto lineOfBusinessDto = administrationService.getLineOfBusinessDtoForEdit(customerId, lineOfBusinessId);

		if (CollectionUtils.isNotEmpty(arrayOrder)) {
			Map<Long, LinesOfBusiness> categoriesMap = new HashMap<Long, LinesOfBusiness>();
			for (LinesOfBusiness issueCategory : lineOfBusinessDto.getLineOfBusinessList()) {
				categoriesMap.put(issueCategory.getId(), issueCategory);
			}
			List<LinesOfBusiness> categories = new ArrayList<LinesOfBusiness>();
			for (Long categoryName : arrayOrder) {
				LinesOfBusiness cat = categoriesMap.remove(categoryName);
				if (cat != null) {
					categories.add(cat);
				}
			}
			for (LinesOfBusiness issueCategory : categoriesMap.values()) {
				categories.add(issueCategory);
			}
			lineOfBusinessDto.getLineOfBusinessList().clear();
			lineOfBusinessDto.getLineOfBusinessList().addAll(categories);
		}

		model.addAttribute("lineOfBusinessDto", lineOfBusinessDto);

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_LINE_OF_BUSINESS_TAB);

		return SHOW_LINES_OF_BUSINESS_PAGE;
	}

	/**
	 * Edits the cate *.
	 * 
	 * @param categoryId the category id
	 * @param arrayOrder the array order
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "editCategory.html", method = RequestMethod.GET)
	public String editCategory(@RequestParam(value = "categoryId") Long categoryId,
			@RequestParam(value = "arrayOrder") List<String> arrayOrder, Model model, HttpServletRequest request) {

		Long customerId = (Long) request.getAttribute("customerId");

		// get category dto for edit
		CategoryDto categoryDto = administrationService.getCategoryDtoForEdit(categoryId, customerId);
		model.addAttribute("categoryDto", categoryDto);

		if (CollectionUtils.isNotEmpty(arrayOrder)) {
			Map<String, IssueCategory> categoriesMap = new HashMap<String, IssueCategory>();
			for (IssueCategory issueCategory : categoryDto.getCategories()) {
				categoriesMap.put(issueCategory.getCategoryType(), issueCategory);
			}
			List<IssueCategory> categories = new ArrayList<IssueCategory>();
			for (String categoryName : arrayOrder) {
				IssueCategory cat = categoriesMap.remove(categoryName);
				if (cat != null) {
					categories.add(cat);
				}
			}
			for (IssueCategory issueCategory : categoriesMap.values()) {
				categories.add(issueCategory);
			}
			categoryDto.getCategories().clear();
			categoryDto.getCategories().addAll(categories);
		}
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_CATEGORY_TAB);

		return SHOW_CATEGORY_PAGE;
	}

	/**
	 * Save line of bus *.
	 * 
	 * @param lineOfBusinessDto the line of business dto
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "addEditLineOfBusiness", method = RequestMethod.POST)
	public String saveLineOfBusiness(@ModelAttribute("lineOfBusinessDto") LineOfBusinessDto lineOfBusinessDto, Model model,
			HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		boolean isSaved = true;
		String failureReason = "";
		try {
			boolean isSameNameExists = false;

			if (lineOfBusinessDto.getLineOfBusiness().getId() == null) {
				QLinesOfBusiness qLinesOfBusiness = QLinesOfBusiness.linesOfBusiness;
				LinesOfBusiness linesOfBusinessDB = lineOfBusinessRepository.findOne(qLinesOfBusiness.name.eq(lineOfBusinessDto
						.getLineOfBusiness().getName()));

				if (linesOfBusinessDB != null) {
					isSameNameExists = true;
					failureReason = "Line of Business changes cannot be saved as another exists with the same name";
					isSaved = false;
				}
			}
			if (!isSameNameExists) {
				isSaved = administrationService.saveLineOfBusiness(lineOfBusinessDto, customerId);
				failureReason = "Line of Business changes cannot be saved as issues are present in the system for the Category";
			}
		} catch (Exception e) {
			isSaved = false;
			failureReason = "Some error occurred while saving line of business";
		}
		request.getSession().setAttribute("isSaved", isSaved);
		request.getSession().setAttribute("failureReason", failureReason);

		return "redirect:showLineOfBusiness.html";
	}

	/**
	 * Save ca *.
	 * 
	 * @param categoryDto the category dto
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "addEditCategory", method = RequestMethod.POST)
	public String saveCategory(@ModelAttribute("categoryDto") CategoryDto categoryDto, Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		boolean isSaved = true;
		String failureReason = "";
		try {
			boolean isSameNameExists = false;

			if (categoryDto.getIssueCategory().getId() == null) {
				QIssueCategory qIssueCategory = QIssueCategory.issueCategory;
				IssueCategory issueCategory = issueCategoryRepository.findOne(qIssueCategory.categoryType.eq(categoryDto.getIssueCategory()
						.getCategoryType()));

				if (issueCategory != null) {
					isSameNameExists = true;
					failureReason = "Category cannot be saved as another exists with the same name";
					isSaved = false;
				}
			}
			if (!isSameNameExists) {
				failureReason = administrationService.saveCategory(categoryDto, customerId);
				if (StringUtils.isNotBlank(failureReason)) {
					isSaved = false;
				}
			}
		} catch (Exception e) {
			logger.error("Error saving category", e);
			isSaved = false;
			failureReason = "Some error occurred while saving Category";
		}
		request.getSession().setAttribute("isSaved", isSaved);
		request.getSession().setAttribute("failureReason", failureReason);

		return "redirect:showCategory.html";
	}

	/**
	 * Enable/Disable Category.
	 * 
	 * @param adminAlertId the admin alert id
	 * @param action the action
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "disableEnableCategory.html", method = RequestMethod.GET)
	public String disableEnableCategory(@RequestParam("notification") Long adminAlertId, @RequestParam("action") Boolean action, Model model) {
		issueCategoryRepository.disableEnableCategory(action, adminAlertId);

		return "redirect:showCategory.html";
	}

	/**
	 * Enable/Disable Category.
	 * 
	 * @param adminAlertId the admin alert id
	 * @param action the action
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "disableEnableTwitterUpdateCategory.html", method = RequestMethod.GET)
	public String deleteAdminAlert(@RequestParam("notification") Long adminAlertId, @RequestParam("action") Boolean action, Model model) {
		issueCategoryRepository.disableEnableTwitterForCategory(action, adminAlertId);

		return "redirect:showCategory.html";
	}

	/**
	 * Sync/Async flow.
	 * 
	 * @param workflowId the workflow id
	 * @param action the action
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "changeSyncAsyncFlow.html", method = RequestMethod.GET)
	public String changeSyncAsyncFlow(@RequestParam("id") Long workflowId, @RequestParam("action") Boolean action, Model model) {
		rasWorkflowsRepository.changeSyncAsync(action, workflowId);
		return "redirect:showDynamicRules.html";
	}

	/**
	 * Enable/Disable Category.
	 * 
	 * @param adminAlertId the admin alert id
	 * @param action the action
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "disableEnableAnonymousUpdateCategory.html", method = RequestMethod.GET)
	public String disableEnableAnonymousReporting(@RequestParam("notification") Long adminAlertId, @RequestParam("action") Boolean action,
			Model model) {
		issueCategoryRepository.disableEnableAnonymousReportingForCategory(action, adminAlertId);

		return "redirect:showCategory.html";
	}

	/**
	 * Shows Region *.
	 * 
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "showRegion.html", method = RequestMethod.GET)
	public String showRegion(Model model, HttpServletRequest request) {

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		// get configured regions
		Customer customer = customerRepository.findOne(1L);
		model.addAttribute("regions", customer.getRegions());
		Region region = new Region();
		region.setCustomer(customer);
		model.addAttribute("regionDto", region);

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_REGION_TAB);

		return SHOW_REGION_PAGE;
	}

	/**
	 * get the map for the region and its child *.
	 * 
	 * @param id the id
	 * @param model the model
	 * @return the region
	 */
	@RequestMapping(value = "getRegion", method = RequestMethod.GET)
	public String getRegion(@RequestParam(value = "id") Long id, Model model) {

		// get child region list for region id
		List<Region> regions = administrationService.getRegionListForRegionId(id);
		model.addAttribute("regions", regions);

		return SHOW_REGION_MAP;
	}

	/**
	 * Adds the edit custom *.
	 * 
	 * @param model the model
	 * @param region the region
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "addEditCustomerRegion1", method = RequestMethod.POST)
	public String addEditCustomerRegion(Model model, @ModelAttribute("regionDto") Region region, HttpServletRequest request) {
		administrationService.saveRegion(region);
		customUserDetailService.refreshRoleSettingsForUser();
		return showRegion(model, request);
	}

	/**
	 * Shows Catego *.
	 * 
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "showRoles.html", method = RequestMethod.GET)
	public String showRoles(Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get line of business
		UserRolesDto userRolesDto = administrationService.getUserRolesDto(customerId, null);
		model.addAttribute("userRolesDto", userRolesDto);

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_ROLES_TAB);

		return SHOW_ROLES_PAGE;
	}

	/**
	 * Edit *.
	 * 
	 * @param model the model
	 * @param userRoleId the user role id
	 * @param arrayOrder the array order
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "editRole.html", method = RequestMethod.GET)
	public String editRoles(Model model, @RequestParam("userRoleId") Long userRoleId,
			@RequestParam(value = "arrayOrder") List<Long> arrayOrder, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get line of business
		UserRolesDto userRolesDto = administrationService.getUserRolesDto(customerId, userRoleId);

		if (CollectionUtils.isNotEmpty(arrayOrder)) {
			Map<Long, UserRole> categoriesMap = new HashMap<Long, UserRole>();
			for (UserRole issueCategory : userRolesDto.getUserRoles()) {
				categoriesMap.put(issueCategory.getId(), issueCategory);
			}
			List<UserRole> categories = new ArrayList<UserRole>();
			for (Long categoryName : arrayOrder) {
				UserRole cat = categoriesMap.remove(categoryName);
				if (cat != null) {
					categories.add(cat);
				}
			}
			for (UserRole issueCategory : categoriesMap.values()) {
				categories.add(issueCategory);
			}
			userRolesDto.getUserRoles().clear();
			userRolesDto.getUserRoles().addAll(categories);
		}

		model.addAttribute("userRolesDto", userRolesDto);

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_ROLES_TAB);

		return SHOW_ROLES_PAGE;
	}

	/**
	 * 
	 .
	 * 
	 * @param userRolesDto the user roles dto
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "addEditUserRole", method = RequestMethod.POST)
	public String saveRoles(@ModelAttribute("userRolesDto") UserRolesDto userRolesDto, Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		boolean isSaved = true;
		String failureReason = "";
		try {
			boolean isSameNameExists = false;

			if (userRolesDto.getUserRole().getId() == null) {
				QUserRole qUserRole = QUserRole.userRole;
				UserRole userRoleDB = userRoleRepository.findOne(qUserRole.name.eq(userRolesDto.getUserRole().getName()));

				if (userRoleDB != null) {
					isSameNameExists = true;
					failureReason = "User Role cannot be saved as another exists with the same name";
					isSaved = false;
				}
			}

			if (!isSameNameExists) {
				administrationService.saveRole(userRolesDto, customerId);
			}
		} catch (Exception e) {
			isSaved = false;
			failureReason = "Some error occurred while saving user role";
		}
		request.getSession().setAttribute("isSaved", isSaved);
		request.getSession().setAttribute("failureReason", failureReason);

		return "redirect:showRoles.html";
	}

	/**
	 * Show * s.
	 * 
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "showAdminUsers.html", method = RequestMethod.GET)
	public String showAdminUsers(Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get line of business
		AdminUsersDto adminUsersDto = administrationService.getAdminUsersDto(customerId, null);
		model.addAttribute("adminUsersDto", adminUsersDto);

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_ADMIN_USERS_TAB);

		return SHOW_ADMIN_USERS_PAGE;
	}

	/**
	 * ed * rs.
	 * 
	 * @param model the model
	 * @param adminUserId the admin user id
	 * @param arrayOrder the array order
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "editAdminUser.html", method = RequestMethod.GET)
	public String editAdminUsers(Model model, @RequestParam("adminUserId") String adminUserId,
			@RequestParam(value = "arrayOrder") List<String> arrayOrder, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		// get line of business
		AdminUsersDto adminUsersDto = administrationService.getAdminUsersDto(customerId, adminUserId);
		if (CollectionUtils.isNotEmpty(arrayOrder)) {
			Map<String, Admin> categoriesMap = new HashMap<String, Admin>();
			for (Admin issueCategory : adminUsersDto.getAdmins()) {
				categoriesMap.put(issueCategory.getLoginId(), issueCategory);
			}
			List<Admin> categories = new ArrayList<Admin>();
			for (String categoryName : arrayOrder) {
				Admin cat = categoriesMap.remove(categoryName);
				if (cat != null) {
					categories.add(cat);
				}
			}
			for (Admin issueCategory : categoriesMap.values()) {
				categories.add(issueCategory);
			}
			adminUsersDto.getAdmins().clear();
			adminUsersDto.getAdmins().addAll(categories);
		}

		model.addAttribute("adminUsersDto", adminUsersDto);

		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());

		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_ADMIN_USERS_TAB);

		return SHOW_ADMIN_USERS_PAGE;
	}

	/**
	 * Del * ers.
	 * 
	 * @param model the model
	 * @param adminUserId the admin user id
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "deleteAdminUser.html", method = RequestMethod.GET)
	public String deleteAdminUsers(Model model, @RequestParam("adminUserId") String adminUserId, HttpServletRequest request) {

		boolean isSaved = true;
		String failureReason = "";
		try {
			QAdminAlert qAdminAlert = QAdminAlert.adminAlert;
			QIssue qIssue = QIssue.issue;
			if (adminAlertRepository.count(qAdminAlert.admin.loginId.eq(adminUserId)) > 0
					|| issueRepository.count(qIssue.assignee.loginId.eq(adminUserId)) > 0) {
				isSaved = false;
				failureReason = "References to Admin User exists so User cannot be deleted.";
			} else {
				adminRepository.delete(adminUserId);
			}
		} catch (Exception e) {
			isSaved = false;
			failureReason = "References to Admin User exists so User cannot be deleted.";
		}
		request.getSession().setAttribute("isDeleted", isSaved);
		request.getSession().setAttribute("failureReason", failureReason);

		return "redirect:showAdminUsers.html";
	}

	/**
	 * 
	 dmin.
	 * 
	 * @param adminUsersDto the admin users dto
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "addEditAdminUser", method = RequestMethod.POST)
	public String saveAdmin(@ModelAttribute("adminUsersDto") AdminUsersDto adminUsersDto, Model model, HttpServletRequest request) {

		// get customer id
		Long customerId = (Long) request.getAttribute("customerId");

		boolean isSaved = true;
		String failureReason = "";
		try {
			administrationService.saveAdmin(adminUsersDto.getAdmin(), customerId);
		} catch (Exception e) {
			isSaved = false;
			failureReason = "Some error occurred while saving admin user";
		}
		request.getSession().setAttribute("isSaved", isSaved);
		request.getSession().setAttribute("failureReason", failureReason);

		return "redirect:showAdminUsers.html";
	}

	/**
	 * Deletes lines of * om DB.
	 * 
	 * @param lineOfBusinessId the line of business id
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "deleteLineOfBusiness.html", method = RequestMethod.GET)
	public String deleteLineOfBusiness(@RequestParam("lineOfBusinessId") Long lineOfBusinessId, Model model, HttpServletRequest request) {

		boolean isDeleted = true;
		try {
			isDeleted = administrationService.deleteLineOfBusiness(lineOfBusinessId);
		} catch (Exception e) {
			logger.error("Error while deleting line of business with id - " + lineOfBusinessId, e);
			isDeleted = false;
		}
		model.addAttribute("isDeleted", isDeleted);

		return showLinesOfBusiness(model, request);
	}

	/**
	 * Deletes lines o * rom DB.
	 * 
	 * @param categoryId the category id
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "deleteCategory.html", method = RequestMethod.GET)
	public String deleteCategory(@RequestParam("categoryId") Long categoryId, Model model, HttpServletRequest request) {

		boolean isDeleted = true;
		try {
			isDeleted = administrationService.deleteCustomerCategory(categoryId);
		} catch (Exception e) {
			logger.error("Error while deleting Category with id - " + categoryId, e);
			isDeleted = false;
		}
		model.addAttribute("isDeleted", isDeleted);

		return showCategory(model, request);
	}

	/**
	 * Delete * from DB.
	 * 
	 * @param roleId the role id
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "deleteRole.html", method = RequestMethod.GET)
	public String deleteRole(@RequestParam("roleId") Long roleId, Model model, HttpServletRequest request) {

		boolean isDeleted = true;
		try {
			isDeleted = administrationService.deleteUserRole(roleId);
		} catch (Exception e) {
			logger.error("Error while deleting user role with id - " + roleId, e);
			isDeleted = false;
		}
		model.addAttribute("isDeleted", isDeleted);

		return showRoles(model, request);
	}

	/**
	 * For * vy Files.
	 * 
	 * @param httpServletRequest the http servlet request
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "showDynamicRules.html", method = RequestMethod.GET)
	public final String showDynamicRules(final HttpServletRequest httpServletRequest, final Model model) {

		Long customerId = (Long) httpServletRequest.getAttribute("customerId");

		RASWorkflowsDto rasWorkflowsDto = new RASWorkflowsDto();

		QRASWorkflows qrasWorkflows = QRASWorkflows.rASWorkflows;
		Iterable<RASWorkflows> iterable = rasWorkflowsRepository.findAll(qrasWorkflows.customer.id.eq(customerId));
		if (iterable != null) {
			rasWorkflowsDto.setRasWorkflows(RASUtility.asList(iterable.iterator()));
		}

		model.addAttribute("rasWorkflowsDto", rasWorkflowsDto);
		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_DYNAMIC_RULES);

		return SHOW_DYNAMIC_RULES;
	}

	/**
	 * Export custom field.
	 * 
	 * @param id the id
	 * @param httpServletRequest the http servlet request
	 * @param httpServletResponse the http servlet response
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@RequestMapping(value = "exportCustomField.html", method = RequestMethod.GET)
	public final void exportCustomField(@RequestParam("id") Long id, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws IOException {

		List<CustomerCategoryCustomField> categoryCustomFields = administrationService.getCustomFieldList(id);

		String fileName = categoryCustomFields.get(0).getIssueCategory().getCategoryType();
		if (fileName != null) {
			fileName = fileName.replaceAll(" ", "");
		}
		exportCustomFields(categoryCustomFields, fileName, httpServletResponse);

		httpServletResponse.setHeader("Content-Disposition", "inline; filename=" + fileName + ".xls");
		httpServletResponse.setContentType("application/vnd.ms-excel");
		httpServletResponse.flushBuffer();
	}

	/**
	 * Export custom fields.
	 * 
	 * @param customFields the custom fields
	 * @param fileName the file name
	 * @param response the response
	 */
	public void exportCustomFields(List<CustomerCategoryCustomField> customFields, String fileName, HttpServletResponse response) {
		List<List<String>> excelDataList = new ArrayList<List<String>>();
		// This loop reads data for each object and populates the data in
		// the
		// List of List of string.
		for (CustomerCategoryCustomField pType : customFields) {
			List<String> rowData = new ArrayList<String>();
			rowData.add(CustomColumnType.getDisplayValueForExcel(pType.getCustomColumnType()));
			rowData.add(pType.getXmlTagName());
			rowData.add(pType.getTitle());
			if (pType.getIsMandatory() != null && pType.getIsMandatory()) {
				rowData.add("yes");
			} else {
				rowData.add("no");
			}
			if (pType.getIsVisibleOnForm() != null && pType.getIsVisibleOnForm()) {
				rowData.add("User");
			} else {
				rowData.add("System");
			}
			if (pType.getIsVisibleOnDisplay() != null && pType.getIsVisibleOnDisplay()) {
				rowData.add("yes");
			} else {
				rowData.add("no");
			}
			rowData.add(pType.getPossibleValues());

			rowData.add(pType.getServiceReqType().toString());

			excelDataList.add(rowData);
		}
		// Create the fileDataDto for excel preparation.
		FileDataDto fileDataDto = new FileDataDto();
		fileDataDto.setDataList(excelDataList);
		fileDataDto.setHeaders(getCustomFieldExcelHeaders());
		fileDataDto.setFieldsDescription(getFieldDescriptionsForExcel());

		fileHandlerService.exportFile(fileDataDto, fileName, response);
	}

	/**
	 * Gets the custom field excel headers.
	 * 
	 * @return the custom field excel headers
	 */
	private List<String> getCustomFieldExcelHeaders() {
		List<String> headers = null;
		headers = Arrays
				.asList("Type", "ID", "Label", "Is Mandatory", "Source", "Show in Issue details", "possible_values", "Service Type");
		return headers;
	}

	/**
	 * Gets the field descriptions for excel.
	 * 
	 * @return the field descriptions for excel
	 */
	private List<String> getFieldDescriptionsForExcel() {
		List<String> descriptions = null;
		descriptions = Arrays.asList("1", "1", "1", "1", "1", "1", "1", "1");
		return descriptions;
	}

	/**
	 * For * vy Files.
	 * 
	 * @param httpServletRequest the http servlet request
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "showConfigurations.html", method = RequestMethod.GET)
	public final String showConfigurations(final HttpServletRequest httpServletRequest, final Model model) {
		List<GlobalPropertyKeyValue> dataDbFetch = administrationService.getConfigToShowOnUI();

		List<GlobalPropertyKeyValue> globalPropertyKeyValuesCheckBoxes = new ArrayList<GlobalPropertyKeyValue>();
		List<GlobalPropertyKeyValue> globalPropertyKeyValuesDropDowns = new ArrayList<GlobalPropertyKeyValue>();
		List<GlobalPropertyKeyValue> globalPropertyKeyValuesTextBoxes = new ArrayList<GlobalPropertyKeyValue>();
		List<GlobalPropertyKeyValue> globalPropertyKeyValuesReadOnlys = new ArrayList<GlobalPropertyKeyValue>();

		for (GlobalPropertyKeyValue globalPropertyKeyValue : dataDbFetch) {

			if (BooleanUtils.isTrue(globalPropertyKeyValue.getIsEditableOnUi())) {
				switch (globalPropertyKeyValue.getUiControlType()) {
				case DROP_DOWN:
					globalPropertyKeyValuesDropDowns.add(globalPropertyKeyValue);
					break;
				case TEXT_FIELD:
					globalPropertyKeyValuesTextBoxes.add(globalPropertyKeyValue);
					break;
				case CHECK_BOX:
				case RADIO_BUTTON:
					globalPropertyKeyValuesCheckBoxes.add(globalPropertyKeyValue);
					break;
				}
			} else {
				globalPropertyKeyValuesReadOnlys.add(globalPropertyKeyValue);
			}
		}

		ConfigurationsDto configurationsDto = new ConfigurationsDto();
		configurationsDto.setGlobalPropertyKeyValuesCheckBoxes(globalPropertyKeyValuesCheckBoxes);
		configurationsDto.setGlobalPropertyKeyValuesDropDowns(globalPropertyKeyValuesDropDowns);
		configurationsDto.setGlobalPropertyKeyValuesReadOnlys(globalPropertyKeyValuesReadOnlys);
		configurationsDto.setGlobalPropertyKeyValuesTextBoxes(globalPropertyKeyValuesTextBoxes);

		model.addAttribute("configurationsDto", configurationsDto);
		model.addAttribute("globalPropertyKeyValue", new GlobalPropertyKeyValue());
		model.addAttribute("selectedTab", ICitiConstants.ADMINISTRATION_TAB);
		// select sub tab
		model.addAttribute("selectedSubTab", ICitiConstants.ADMIN_CONFIGURATIONS);

		return SHOW_CONFIGURATIONS;
	}

	/**
	 * Update configuration.
	 * 
	 * @param globalPropertyKeyValue the global property key value
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "updateConfiguration", method = RequestMethod.POST)
	public @ResponseBody
	String updateConfiguration(@ModelAttribute("globalPropertyKeyValue") GlobalPropertyKeyValue globalPropertyKeyValue, Model model,
			HttpServletRequest request) {

		boolean isUpdated = administrationService.updateConfiguration(globalPropertyKeyValue.getUiID(), globalPropertyKeyValue.getValue());
		return isUpdated ? "true" : "false";
	}
}
