/**
 * This contains the Web Interceptors used in the application.
 */
package com.wizni.reportaspot.admin.interceptors;