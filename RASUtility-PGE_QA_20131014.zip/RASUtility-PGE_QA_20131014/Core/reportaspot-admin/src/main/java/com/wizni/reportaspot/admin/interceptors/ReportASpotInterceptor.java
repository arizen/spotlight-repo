/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * The Class ReportASpotInterceptor.
 */
public class ReportASpotInterceptor extends HandlerInterceptorAdapter {

	/** The Constant LOGGER. */
	private static final Logger logger = LoggerFactory.getLogger(ReportASpotInterceptor.class);

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle(HttpServletRequest, HttpServletResponse, Object) - start"); //$NON-NLS-1$
		}

		updateRequest(request);
		boolean returnboolean = super.preHandle(request, response, handler);
		if (logger.isDebugEnabled()) {
			logger.debug("preHandle(HttpServletRequest, HttpServletResponse, Object) - end"); //$NON-NLS-1$
		}
		return returnboolean;
	}

	/**
	 * Update the request for the web interception.
	 * 
	 * @param request {@link HttpServletRequest}
	 */
	private void updateRequest(HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("updateRequest(HttpServletRequest) - start"); //$NON-NLS-1$
		}

		request.setAttribute("customerId", 1L);

		if (logger.isDebugEnabled()) {
			logger.debug("updateRequest(HttpServletRequest) - end"); //$NON-NLS-1$
		}
	}
}
