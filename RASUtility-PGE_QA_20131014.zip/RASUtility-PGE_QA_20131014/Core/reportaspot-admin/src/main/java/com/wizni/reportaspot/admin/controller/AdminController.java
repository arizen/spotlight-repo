/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mysema.query.types.Order;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.expr.BooleanExpression;
import com.wizni.reportaspot.model.constants.ICitiConstants;
import com.wizni.reportaspot.model.domain.Admin;
import com.wizni.reportaspot.model.domain.AdminAlert;
import com.wizni.reportaspot.model.domain.Customer;
import com.wizni.reportaspot.model.domain.Issue;
import com.wizni.reportaspot.model.domain.IssueCategory;
import com.wizni.reportaspot.model.domain.LOBIssueCategory;
import com.wizni.reportaspot.model.domain.QAdmin;
import com.wizni.reportaspot.model.domain.QAdminAlert;
import com.wizni.reportaspot.model.domain.QIssue;
import com.wizni.reportaspot.model.domain.Region;
import com.wizni.reportaspot.model.domain.audit.AdminAlertsAudit;
import com.wizni.reportaspot.model.domain.audit.QAdminAlertsAudit;
import com.wizni.reportaspot.model.dto.view.JsonIssueDto;
import com.wizni.reportaspot.model.enums.IssueStatus;
import com.wizni.reportaspot.model.security.ReportASpotUser;
import com.wizni.reportaspot.model.util.RASUtility;
import com.wizni.reportaspot.model.viewdto.HomeViewDto;
import com.wizni.reportaspot.model.viewdto.IssueAutocompleteDto;
import com.wizni.reportaspot.model.viewdto.SearchFilterDto;
import com.wizni.reportaspot.model.viewdto.SearchFilterDto.AdminPageType;
import com.wizni.reportaspot.model.viewdto.UpdateUIIssueDto;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.storage.repositories.AdminAlertRepository;
import com.wizni.reportaspot.storage.repositories.AdminAlertsAuditRepository;
import com.wizni.reportaspot.storage.repositories.AdminRepository;
import com.wizni.reportaspot.storage.repositories.CustomerRepository;
import com.wizni.reportaspot.storage.repositories.IssueCategoryRepository;
import com.wizni.reportaspot.storage.repositories.IssueRepository;
import com.wizni.reportaspot.storage.repositories.IssueRepositoryCustom;
import com.wizni.reportaspot.storage.repositories.RegionRepository;

/**
 * The Class AdminController is used as a Web Controller for Admin Web Application. This contains methods for the Issue
 * tab and its ajax actions.
 */
@Controller
@RequestMapping("admin")
public class AdminController {

	/** The Constant ADMIN_COMMENTS. This is the tile definition for showing Admin Comments. */
	private static final String ADMIN_COMMENTS = "adminComments";

	/** The Constant SHOW_ADMIN_REPORT. This is the tile definition for showing Admin Report. */
	private static final String SHOW_ADMIN_REPORT = "showAdminReport";

	/** The Constant ADMIN_ISSUES_AJAX_LOAD. This is the tile definition for loading issues via ajax. */
	private static final String ADMIN_ISSUES_AJAX_LOAD = "adminIssuesAjaxLoad";

	/** The Constant GRID_VIEW_ISSUES_PAGE. This is the tile definition for showing the Issues list. */
	public static final String GRID_VIEW_ISSUES_PAGE = "gridViewIssues";

	/** The Constant MAP_VIEW_ISSUES_PAGE. This is the tile definition for showing the Map for Issues. */
	public static final String MAP_VIEW_ISSUES_PAGE = "mapViewIssues";

	/** The Constant GRAPH_VIEW_ISSUES_PAGE. This is the tile definition for showing the Dashboard. */
	public static final String GRAPH_VIEW_ISSUES_PAGE = "graphViewIssues";

	/** The Constant SHOW_ADMIN_ALERTS_PAGE. This is the tile definition for showing Admin Alerts. */
	public static final String SHOW_ADMIN_ALERTS_PAGE = "showAdminAlerts";

	/** The Constant SHOW_ADMIN_ALERTS_AUDIT_PAGE. This is the tile definition for showing Admin Alerts Audits. */
	public static final String SHOW_ADMIN_ALERTS_AUDIT_PAGE = "showAdminAlertAudits";

	/** The Constant ADD_ADMIN_ALERTS_PAGE. This is the tile definition for showing page for showing AdminAlerts. */
	public static final String ADD_ADMIN_ALERTS_PAGE = "addAdminAlert";

	/** The Constant SHOW_VIEW_ERROR_PAGE. This is the tile definition for showing Error Page. */
	public static final String SHOW_VIEW_ERROR_PAGE = "showViewErrorPage";

	/** The customer repository. */
	@Autowired
	private CustomerRepository customerRepository;

	/** The region repository. */
	@Autowired
	private RegionRepository regionRepository;

	/** The issue repository custom. */
	@Autowired
	private IssueRepositoryCustom issueRepositoryCustom;

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/** The issue repository. */
	@Autowired
	private IssueRepository issueRepository;

	/** The admin alert repository. */
	@Autowired
	private AdminAlertRepository adminAlertRepository;

	/** The admin alerts audit repository. */
	@Autowired
	private AdminAlertsAuditRepository adminAlertsAuditRepository;

	/** The admin repository. */
	@Autowired
	private AdminRepository adminRepository;

	/** The issue category repository. */
	@Autowired
	private IssueCategoryRepository issueCategoryRepository;

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);

	/** The Constant SESSION_VAR_FROM_DATE. */
	private static final String SESSION_VAR_FROM_DATE = "session.fromDate";

	/** The Constant SESSION_VAR_TO_DATE. */
	private static final String SESSION_VAR_TO_DATE = "session.toDate";

	/**
	 * Inits the binder. This is used for Binding the Controller with the said dateformat which takes care of
	 * Initialization.
	 * 
	 * @param binder {@link WebDataBinder}
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM, yyyy");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	/**
	 * View Method for Sector Selection.
	 * 
	 * @param model {@link Model}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "sectors.html", method = RequestMethod.GET)
	public String sectorSelect(Model model) {
		Customer customer = customerRepository.findOne(1L);
		model.addAttribute("customer", customer);
		Region region = new Region();
		region.setCustomer(customer);
		model.addAttribute("regionDto", region);
		return "sectorSelect";
	}

	/**
	 * Saves/Edits Customer Region to DB.
	 * 
	 * @param model {@link Model}
	 * @param region the region
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "addEditCustomerRegion", method = RequestMethod.POST)
	public String addEditCustomerRegion(Model model, @ModelAttribute("regionDto") Region region) {
		regionRepository.save(region);
		return sectorSelect(model);
	}

	/**
	 * Admin show issues grid.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param search The Search Keyword.
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = { "", "home.html" }, method = RequestMethod.GET)
	public String adminShowIssuesGrid(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model,
			@RequestParam(value = "se", required = false) String search, HttpServletRequest request) {

		String returnString = GRID_VIEW_ISSUES_PAGE;

		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		searchFilter.setLobIds(reportASpotUser.getLobIds());

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);
		searchFilter.setSearchTerm(search);
		if (searchFilter.getFromDate() == null) {
			Object obj = request.getSession().getAttribute(SESSION_VAR_FROM_DATE);
			if (obj != null) {
				searchFilter.setFromDate((Date) obj);
			} else {
				Calendar cal = Calendar.getInstance();
				cal.setTime(new Date());
				cal.add(Calendar.MONTH, -1);
				searchFilter.setFromDate(cal.getTime());
			}
		}
		if (searchFilter.getToDate() == null) {
			Object obj = request.getSession().getAttribute(SESSION_VAR_TO_DATE);
			if (obj != null) {
				searchFilter.setToDate((Date) obj);
			} else {
				Calendar cal2 = Calendar.getInstance();
				cal2.add(Calendar.DATE, 1);
				cal2.set(Calendar.SECOND, 0);
				cal2.set(Calendar.MINUTE, 0);
				cal2.set(Calendar.HOUR, 0);
				searchFilter.setToDate(cal2.getTime());
			}
		}
		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(customerId);

		HomeViewDto viewDto = new HomeViewDto();
		setIssueCount(viewDto, searchFilter);
		model.addAttribute("issueCategories", issueCategories);
		model.addAttribute("searchFilter", searchFilter);

		String selectedTab = ICitiConstants.ISSUES_TAB;
		if (searchFilter.getAdminPageType() == AdminPageType.GRID_VIEW) {
			List<Issue> issuesList = getIssuesForFilter(searchFilter);
			viewDto.setIssues(issuesList);
			model.addAttribute("selectedTab", selectedTab);
			returnString = GRID_VIEW_ISSUES_PAGE;
		} else if (searchFilter.getAdminPageType() == AdminPageType.MAP_VIEW) {
			Customer customer = customerRepository.findOne(1L);
			model.addAttribute("regions", customer.getRegions());
			model.addAttribute("selectedTab", selectedTab);
			returnString = MAP_VIEW_ISSUES_PAGE;
		} else if (searchFilter.getAdminPageType() == AdminPageType.GRAPH_VIEW) {
			selectedTab = ICitiConstants.DASHBOARD_TAB;
			model.addAttribute("selectedTab", selectedTab);
			returnString = GRAPH_VIEW_ISSUES_PAGE;
		}
		model.addAttribute("viewDto", viewDto);

		request.getSession().setAttribute(SESSION_VAR_FROM_DATE, searchFilter.getFromDate());
		request.getSession().setAttribute(SESSION_VAR_TO_DATE, searchFilter.getToDate());

		return returnString;
	}

	/**
	 * Retrieves Issues Objects from Database based on the {@link SearchFilterDto} used.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @return The Issues for this search selection
	 */
	private List<Issue> getIssuesForFilter(SearchFilterDto searchFilter) {

		List<Issue> issuesList = null;

		switch (searchFilter.getAdminPageType()) {
		case GRID_VIEW:
			issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(), ICitiConstants.PAGINATION_SIZE,
					true);
			break;
		case MAP_VIEW:
			issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(), 100, true);
		case GRAPH_VIEW:
			break;
		}

		return issuesList;
	}

	/**
	 * Shows the UI Page for Dashboard or Issues tab based on user selection.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "home.html", method = RequestMethod.POST)
	public String adminPost(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		String returnString = GRID_VIEW_ISSUES_PAGE;
		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		searchFilter.setLobIds(reportASpotUser.getLobIds());

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(customerId);

		HomeViewDto viewDto = new HomeViewDto();
		setIssueCount(viewDto, searchFilter);
		model.addAttribute("issueCategories", issueCategories);
		model.addAttribute("searchFilter", searchFilter);

		String selectedTab = ICitiConstants.ISSUES_TAB;
		if (searchFilter.getAdminPageType() == AdminPageType.GRID_VIEW) {
			model.addAttribute("selectedTab", selectedTab);
			List<Issue> issuesList = getIssuesForFilter(searchFilter);
			viewDto.setIssues(issuesList);
			returnString = GRID_VIEW_ISSUES_PAGE;
		} else if (searchFilter.getAdminPageType() == AdminPageType.MAP_VIEW) {
			Customer customer = customerRepository.findOne(1L);
			model.addAttribute("regions", customer.getRegions());
			model.addAttribute("selectedTab", selectedTab);
			returnString = MAP_VIEW_ISSUES_PAGE;
		} else if (searchFilter.getAdminPageType() == AdminPageType.GRAPH_VIEW) {
			selectedTab = ICitiConstants.DASHBOARD_TAB;
			model.addAttribute("selectedTab", selectedTab);
			returnString = GRAPH_VIEW_ISSUES_PAGE;
		}
		model.addAttribute("viewDto", viewDto);

		request.getSession().setAttribute(SESSION_VAR_FROM_DATE, searchFilter.getFromDate());
		request.getSession().setAttribute(SESSION_VAR_TO_DATE, searchFilter.getToDate());

		return returnString;
	}

	/**
	 * Retrieves Issues via Ajax for the given {@link SearchFilterDto} criteria.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "issues_ajax.html", method = RequestMethod.POST)
	public String homeAjaxGetIssues(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		searchFilter.setLobIds(reportASpotUser.getLobIds());

		/*
		 * Long selectedRegionId = searchFilter.getSelectedRegionId(); if (selectedRegionId == null) { selectedRegionId = (Long)
		 * request.getSession().getAttribute("regionId"); if (selectedRegionId == null) { selectedRegionId =
		 * reportASpotUser.getDefaultUserRegionId(); } searchFilter.setSelectedRegionId(selectedRegionId); } searchFilter.setRegionIds
		 * (Utility.getRegionIdsForUser(selectedRegionId, reportASpotUser.getRegionDropDownDto()));
		 */

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		List<Issue> issuesList = getIssuesForFilter(searchFilter);

		HomeViewDto viewDto = new HomeViewDto();
		viewDto.setIssues(issuesList);

		model.addAttribute("viewDto", viewDto);
		model.addAttribute("searchFilter", searchFilter);

		return ADMIN_ISSUES_AJAX_LOAD;
	}

	/**
	 * Shows the detailed issue display for a particular issue based on the Id. The SearchFilter Criteria is passed for
	 * saving search state.
	 * 
	 * @param id The Id for the issue to fetch from Database.
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "showReport", method = RequestMethod.GET)
	public String showReport(@RequestParam(value = "id") Long id, @ModelAttribute("searchFilter") SearchFilterDto searchFilter,
			Model model, HttpServletRequest request) {

		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		searchFilter.setLobIds(reportASpotUser.getLobIds());

		/*
		 * Long selectedRegionId = (Long) request.getSession().getAttribute("regionId"); if (selectedRegionId == null) { selectedRegionId =
		 * reportASpotUser.getDefaultUserRegionId(); } searchFilter.setSelectedRegionId(selectedRegionId);
		 * request.getSession().setAttribute("regionId", selectedRegionId); searchFilter
		 * .setRegionIds(Utility.getRegionIdsForUser(selectedRegionId, reportASpotUser.getRegionDropDownDto()));
		 */

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		Issue issue = issueService.getIssue(id);

		if (searchFilter.getFromDate() == null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			cal.add(Calendar.MONTH, -1);
			searchFilter.setFromDate(cal.getTime());
		}

		if (searchFilter.getToDate() == null) {
			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DATE, 1);
			cal2.set(Calendar.SECOND, 0);
			cal2.set(Calendar.MINUTE, 0);
			cal2.set(Calendar.HOUR, 0);
			searchFilter.setToDate(cal2.getTime());
		}

		model.addAttribute("regionMenu", reportASpotUser.getRegionDropDownDto());
		model.addAttribute("normalRegionMenu", reportASpotUser.getNormalDropDownDtos());
		model.addAttribute("searchFilter", searchFilter);
		// set selected tab in session
		model.addAttribute("selectedTab", ICitiConstants.ISSUES_TAB);

		// check for permissions for viewing this issue by user
		boolean isPermitted = true;
		boolean isIssueFound = true;
		if (issue != null) {
			isPermitted = checkUserPermissions(searchFilter.getCustomerId(), searchFilter.getLobIds(),
					reportASpotUser.getAllAccessibleRegionIds(), issue);
		} else {
			isIssueFound = false;
		}

		if (isPermitted && isIssueFound) {
			UpdateUIIssueDto updateIssueDto = new UpdateUIIssueDto();
			updateIssueDto.setIssue(issue);
			updateIssueDto.setIssueId(issue.getId());
			updateIssueDto.setIssueStatus(issue.getStatus());
			updateIssueDto.setIsSpam(issue.getIsSpam());
			if (issue.getAssignee() != null) {
				updateIssueDto.setAssigneeLoginId(issue.getAssignee().getLoginId());
			} else {
				updateIssueDto.setAssigneeLoginId("");
			}

			// get near by issues
			List<Object[]> nearByIssues = issueRepositoryCustom.getNearbyIssues(id, issue.getLatitude(), issue.getLongitude(), customerId,
					ICitiConstants.NEARBY_ISSUES_LIMIT, ICitiConstants.NEARBY_ISSUES_DISTANCE_MILES, searchFilter.getLobIds(),
					searchFilter.getRegionIds());
			List<Issue> nearByIssueList = new ArrayList<Issue>();
			for (Object[] objects : nearByIssues) {
				Issue nearByIssue = new Issue();

				Long nearIssueId = null;
				if (objects[0] instanceof BigDecimal) {
					nearIssueId = ((BigDecimal) objects[0]).longValue();
				} else {
					nearIssueId = ((BigInteger) objects[0]).longValue();
				}
				nearByIssue.setId(nearIssueId);
				nearByIssue.setThumbnailUrl((String) objects[1]);

				Double nearByLatitude = null;
				if (objects[2] instanceof BigDecimal) {
					nearByLatitude = ((BigDecimal) objects[2]).doubleValue();
				} else {
					nearByLatitude = (Double) objects[2];
				}
				nearByIssue.setLatitude(nearByLatitude);

				Double nearByLongitude = null;
				if (objects[3] instanceof BigDecimal) {
					nearByLongitude = ((BigDecimal) objects[3]).doubleValue();
				} else {
					nearByLongitude = (Double) objects[3];
				}
				nearByIssue.setLongitude(nearByLongitude);

				nearByIssue.setTitle((String) objects[4]);
				nearByIssue.setAddress((String) objects[6]);

				Long nearByCategoryId = null;
				if (objects[7] instanceof BigDecimal) {
					nearByCategoryId = ((BigDecimal) objects[7]).longValue();
				} else {
					nearByCategoryId = ((BigInteger) objects[7]).longValue();
				}
				nearByIssue.setIssueCategory(issueCategoryRepository.findOne(nearByCategoryId));

				nearByIssueList.add(nearByIssue);
			}
			updateIssueDto.setNearByIssues(nearByIssueList);

			// get location history issues
			List<Issue> locationHistoryIssues = issueService.getLocationHistoryIssues(issue.getLatitude(), issue.getLongitude(),
					searchFilter.getRegionIds(), searchFilter.getLobIds(), ICitiConstants.LOCATION_HISTORY_ISSUES_LIMIT, customerId, id,
					ICitiConstants.LOCATION_HISTORY_DISTANCE_MILES);
			updateIssueDto.setLocationHistoryIssues(locationHistoryIssues);

			// get list of admins
			QAdmin qAdmin = QAdmin.admin;
			Iterable<Admin> iterable = adminRepository.findAll(qAdmin.customer.id.eq(customerId));
			if (iterable != null) {
				updateIssueDto.setAdminList(RASUtility.asList(iterable.iterator()));
			}

			model.addAttribute("updateIssueDto", updateIssueDto);

			return SHOW_ADMIN_REPORT;
		} else if (!isPermitted) {
			request.getSession().setAttribute("failureReason", "no_permission");
			return SHOW_VIEW_ERROR_PAGE;
		} else {
			request.getSession().setAttribute("failureReason", "not_found");
			return SHOW_VIEW_ERROR_PAGE;
		}
	}

	/**
	 * Action to Archive the Issue based on the Issue id given in {@link UpdateUIIssueDto}.
	 * 
	 * @param updateIssueDto The DTO object used for Updating an aspect of an issue.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "archiveIssue", method = RequestMethod.POST)
	public String archiveIssue(@ModelAttribute(value = "updateIssueDto") UpdateUIIssueDto updateIssueDto, Model model,
			HttpServletRequest request) {

		boolean isArchived = false;
		try {
			issueService.archiveIssue(updateIssueDto.getIssueId());
			isArchived = true;
		} catch (Exception e) {
			LOGGER.error("Archiving Issue Error", e);
		}
		request.getSession().setAttribute("isArchived", isArchived);
		return "redirect:/admin/showReport?id=" + updateIssueDto.getIssueId();
	}

	/**
	 * Updates the Issue data with the new fields of Issue.
	 * 
	 * @param updateIssueDto The DTO object used for Updating an aspect of an issue.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @param redirectAttributes the redirect attributes
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "updateIssue", method = RequestMethod.POST)
	public String updateIssue(@ModelAttribute(value = "updateIssueDto") UpdateUIIssueDto updateIssueDto, Model model,
			HttpServletRequest request, final RedirectAttributes redirectAttributes) {

		boolean isIssueUpdated = false;
		try {
			issueService.updateIssue(updateIssueDto);
			isIssueUpdated = true;
		} catch (Exception e) {
			LOGGER.error("Saving Issue Error", e);
		}
		request.getSession().setAttribute("isIssueUpdated", isIssueUpdated);
		redirectAttributes.addFlashAttribute("isComingUpdate", true);
		return "redirect:/admin/showReport?id=" + updateIssueDto.getIssueId();
	}

	/**
	 * Adds comment for an issue based on the {@link UpdateUIIssueDto}.
	 * 
	 * @param updateIssueDto The DTO object used for Updating an aspect of an issue.
	 * @param model {@link Model}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "addComment", method = RequestMethod.POST)
	public String addComment(@ModelAttribute(value = "updateIssueDto") UpdateUIIssueDto updateIssueDto, Model model) {

		issueService.addComment(updateIssueDto);

		// get issue
		Issue issue = issueService.getIssue(updateIssueDto.getIssueId());
		updateIssueDto.setIssue(issue);
		model.addAttribute("updateIssueDto", updateIssueDto);

		return ADMIN_COMMENTS;
	}

	/**
	 * This is used in search ajax to provide a autocomplete for Issues. It only retrieves the first 10 results.
	 * 
	 * @param query The query for retrieving the results.
	 * @param request {@link HttpServletRequest}
	 * @return The list of the {@link IssueAutocompleteDto} retrived for this query result.
	 */
	@RequestMapping(value = "searchissues", method = RequestMethod.GET)
	public @ResponseBody
	List<IssueAutocompleteDto> searchTitle(@RequestParam(required = true, value = "query") String query, HttpServletRequest request) {

		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();

		Long selectedRegionId = (Long) request.getSession().getAttribute("regionId");
		List<Long> regionIds = RASUtility.getRegionIdsForUser(selectedRegionId, reportASpotUser.getRegionDropDownDto());

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");

		List<Issue> issues = issueService.getIssuesSearchFilter(query, customerId, reportASpotUser.getLobIds(), regionIds);

		List<IssueAutocompleteDto> dto = new ArrayList<IssueAutocompleteDto>();
		for (Issue issue : issues) {
			IssueAutocompleteDto cDto = new IssueAutocompleteDto(issue.getId(), "Id: " + issue.getId() + " - " + issue.getTitle());
			dto.add(cDto);
		}

		return dto;
	}

	/**
	 * This is a private method for setting issue counts for the Home Page.
	 * 
	 * @param homeViewDto {@link HomeViewDto}
	 * @param searchFilterDto The Search Filter Object DTO contains search params.
	 */
	private void setIssueCount(HomeViewDto homeViewDto, SearchFilterDto searchFilterDto) {
		/*
		 * Calendar cal = Calendar.getInstance(); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.HOUR, 0);
		 *
		 * Timestamp previousDayTimeStamp = new Timestamp(cal.getTimeInMillis()); cal.add(Calendar.DATE, 1); Timestamp nextDayTimeStamp =
		 * new Timestamp(cal.getTimeInMillis());
		 */

		QIssue qIssue = QIssue.issue;

		// get the date filter predicate
		BooleanExpression dateFilterPredicate = null;
		if (searchFilterDto.getFromDate() != null) {
			dateFilterPredicate = qIssue.creationDate.goe(new Timestamp(searchFilterDto.getFromDate().getTime()));
			if (searchFilterDto.getToDate() != null) {
				dateFilterPredicate = dateFilterPredicate
						.and(qIssue.creationDate.loe(new Timestamp(searchFilterDto.getToDate().getTime())));
			}
		}

		// get the customer id and lob ids and region ids predicate
		BooleanExpression commonPredicate = qIssue.isSpam.eq(false).and(qIssue.isArchived.eq(false)).and(qIssue.isRequestComplete.eq(true));
		BooleanExpression commonPredicateForSpamIssues = qIssue.isSpam.eq(true).and(qIssue.isArchived.eq(false));
		if (searchFilterDto.getCustomerId() != null) {
			commonPredicate = commonPredicate.and(qIssue.customer.id.eq(searchFilterDto.getCustomerId()));
			commonPredicateForSpamIssues = commonPredicateForSpamIssues.and(qIssue.customer.id.eq(searchFilterDto.getCustomerId()));
		}
		if (searchFilterDto.getLobIds() != null && !searchFilterDto.getLobIds().isEmpty()) {
			commonPredicate = commonPredicate.and(qIssue.linesOfBusiness.id.in(searchFilterDto.getLobIds()));
			commonPredicateForSpamIssues = commonPredicateForSpamIssues.and(qIssue.linesOfBusiness.id.in(searchFilterDto.getLobIds()));
		}
		if (searchFilterDto.getRegionIds() != null && !searchFilterDto.getRegionIds().isEmpty()) {
			commonPredicate = commonPredicate.and(qIssue.region.id.in(searchFilterDto.getRegionIds()));
			commonPredicateForSpamIssues = commonPredicateForSpamIssues.and(qIssue.region.id.in(searchFilterDto.getRegionIds()));
		}

		homeViewDto.setAllIssueCount(issueRepository.count(commonPredicate.and(dateFilterPredicate)));
		homeViewDto.setClosedIssueCount(issueRepository.count(qIssue.status.eq(IssueStatus.CLOSED).and(dateFilterPredicate)
				.and(commonPredicate)));
		homeViewDto.setPendingIssueCount(issueRepository.count(qIssue.status.eq(IssueStatus.PENDING).and(dateFilterPredicate)
				.and(commonPredicate)));
		homeViewDto.setNewIssueCount(issueRepository
				.count(qIssue.status.eq(IssueStatus.OPEN).and(dateFilterPredicate).and(commonPredicate)));

		/*
		 * homeViewDto.setTodayNewIssueCount(issueRepository.count(qIssue.status.eq(IssueStatus.OPEN)
		 * .and(qIssue.creationDate.between(previousDayTimeStamp, nextDayTimeStamp)).and(commonPredicate)));
		 *
		 * homeViewDto.setTodayClosedIssueCount(issueRepository.count(qIssue.status.eq(IssueStatus.CLOSED)
		 * .and(qIssue.lastStatusChangeDate.between(previousDayTimeStamp, nextDayTimeStamp)).and(commonPredicate)));
		 *
		 * homeViewDto.setSpamIssueCount(issueRepository.count(commonPredicateForSpamIssues.and(dateFilterPredicate)));
		 */

		homeViewDto.setSelectedIssueCount(issueService.getCountOnSearch(searchFilterDto, true));

		/*
		 * homeViewDto.setAllTotal(issueRepository.count(commonPredicate));
		 * homeViewDto.setNewTotal(issueRepository.count(qIssue.status.eq(IssueStatus.OPEN).and(commonPredicate)));
		 * homeViewDto.setClosedTotal(issueRepository.count(qIssue.status.eq(IssueStatus.CLOSED).and(commonPredicate)));
		 * homeViewDto.setPendingTotal(issueRepository.count(qIssue.status.eq(IssueStatus.PENDING).and(commonPredicate)));
		 */

	}

	/**
	 * Shows the View page for Admin Alerts. It shows a list of Admin Alerts the admin has configured in the system.
	 * 
	 * @param model the model {@link Model}
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "showAdminAlerts.html", method = RequestMethod.GET)
	public String showAdminAlerts(Model model) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		QAdminAlert qAdminAlert = QAdminAlert.adminAlert;
		List<AdminAlert> adminAlerts = RASUtility.asList(adminAlertRepository.findAll(
				qAdminAlert.admin.loginId.eq(authentication.getName())).iterator());
		model.addAttribute("notificationsList", adminAlerts);

		model.addAttribute("selectedSubTab", "showAdminAlerts");
		// set selected tab in session
		model.addAttribute("selectedTab", ICitiConstants.NOTIFICATION_TAB);

		return SHOW_ADMIN_ALERTS_PAGE;
	}

	/**
	 * Shows the View page for Admin Audits Alerts. It shows a list of Admin Audit alerts to show the alerts which have
	 * been sent/raised by the system.
	 * 
	 * @param model the model {@link Model}
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "alertAudit.html", method = RequestMethod.GET)
	public String showAlertsAudit(Model model) {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		QAdminAlertsAudit qAdminAlertAudit = QAdminAlertsAudit.adminAlertsAudit;
		List<AdminAlertsAudit> adminAlertsAudits = RASUtility.asList(adminAlertsAuditRepository.findAll(
				qAdminAlertAudit.adminLoginId.eq(authentication.getName()),
				new OrderSpecifier<Date>(Order.DESC, qAdminAlertAudit.creationDate)).iterator());
		model.addAttribute("notificationsList", adminAlertsAudits);

		model.addAttribute("selectedSubTab", "alertAudit");
		// set selected tab in session
		model.addAttribute("selectedTab", ICitiConstants.NOTIFICATION_TAB);

		return SHOW_ADMIN_ALERTS_AUDIT_PAGE;
	}

	/**
	 * Deletes AdminAlert from DB permanently.
	 * 
	 * @param adminAlertId The id of the {@link AdminAlert}
	 * @param model the model {@link Model}
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "deleteNotification.html", method = RequestMethod.GET)
	public String deleteAdminAlert(@RequestParam("notification") Long adminAlertId, Model model) {

		adminAlertRepository.delete(adminAlertId);
		model.addAttribute("isDeleted", true);

		return showAdminAlerts(model);
	}

	/**
	 * Enable/Disable Alert based on the adminAlertId.
	 * 
	 * @param adminAlertId The id of the {@link AdminAlert}
	 * @param action Whether to disable or enable the alert
	 * @param model the model {@link Model}
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "disableEnableNotification.html", method = RequestMethod.GET)
	public String enableDisableAlert(@RequestParam("notification") Long adminAlertId, @RequestParam("action") Boolean action, Model model) {
		adminAlertRepository.disableEnableAlert(action, adminAlertId);

		return showAdminAlerts(model);
	}

	/**
	 * Adds Admin Alert Notification. If the request param is present then it is editNotification else it is an adding a
	 * new notification.
	 * 
	 * @param adminAlertId The id of the {@link AdminAlert}
	 * @param model the model {@link Model}
	 * @param request the request
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "addEditNotification.html", method = RequestMethod.GET)
	public String addAdminAlert(@RequestParam(value = "notification", required = false) Long adminAlertId, Model model,
			HttpServletRequest request) {

		AdminAlert adminAlert = null;
		if (adminAlertId == null) {
			adminAlert = new AdminAlert();
		} else {
			adminAlert = adminAlertRepository.findOne(adminAlertId);
		}
		model.addAttribute("issueCategories", issueService.getAllIssueCategoriesForCustomer((Long) request.getAttribute("customerId")));
		model.addAttribute("adminAlert", adminAlert);

		model.addAttribute("selectedSubTab", "showAdminAlerts");
		model.addAttribute("selectedTab", ICitiConstants.NOTIFICATION_TAB);

		return ADD_ADMIN_ALERTS_PAGE;
	}

	/**
	 * Adds Admin Alert Notification. If the request param is present then it is editNotification else it is an adding a
	 * new notification.
	 * 
	 * @param adminAlert The {@link AdminAlert} to save in Database.
	 * @param model the model {@link Model}
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "addEditNotification.html", method = RequestMethod.POST)
	public String submitAdminAlert(@ModelAttribute("adminAlert") AdminAlert adminAlert, Model model) {

		if (adminAlert.getIssueCategory().getId() == null) {
			adminAlert.setIssueCategory(null);
		}
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		adminAlert.setAdmin(adminRepository.findOne(authentication.getName()));
		adminAlertRepository.save(adminAlert);
		model.addAttribute("isSaved", true);
		return showAdminAlerts(model);
	}

	/**
	 * Deletes An Issue from the Database.
	 * 
	 * @param id The {@link Issue} id
	 * @param model the model {@link Model}
	 * @return the tile defination to use
	 */
	@RequestMapping(value = "deleteIssue", method = RequestMethod.GET)
	public String deleteIssue(@RequestParam("id") Long id, Model model) {

		try {
			issueRepository.delete(id);
			model.addAttribute("issueDeletion", "Issue id : " + id + " deleted");
		} catch (Exception e) {
			LOGGER.error("Error Deleting Issue id " + id, e);
			model.addAttribute("issueDeletion", "Issue id : " + id + " not deleted");
		}

		return "forward:home.html";
	}

	/**
	 * Check user permissions based on the given parameters.
	 * 
	 * @param customerId {@link Customer} id
	 * @param lobIds {@link LOBIssueCategory} id's
	 * @param regionIds {@link Region} id's
	 * @param issue The {@link Issue} in the system.
	 * @return true, if successful else returns false.
	 */
	private boolean checkUserPermissions(Long customerId, List<Long> lobIds, List<Long> regionIds, Issue issue) {

		if (!issue.getCustomer().getId().equals(customerId)) {
			return false;
		}

		if (lobIds != null && !lobIds.isEmpty()) {
			if (issue.getLinesOfBusiness() == null || !lobIds.contains(issue.getLinesOfBusiness().getId())) {
				return false;
			}
		}

		if (!regionIds.contains(issue.getRegion().getId())) {
			return false;
		}
		return true;
	}

	/**
	 * Loads Issues using Ajax for the Map sending response as JSON based on the {@link SearchFilterDto} criteria.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model Model of the data transferred. {@link Model}
	 * @param request {@link HttpServletRequest} for this request.
	 * @param response {@link HttpServletResponse} for this response.
	 * @throws IOException Exception in case of Response.
	 */
	@RequestMapping(value = "loadMoreIssues.html", method = RequestMethod.POST)
	public @ResponseBody
	final void homeAjaxGetIssues(@ModelAttribute("searchFilter") final SearchFilterDto searchFilter, final Model model,
			final HttpServletRequest request, final HttpServletResponse response) throws IOException {
		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		searchFilter.setLobIds(reportASpotUser.getLobIds());
		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);
		List<Issue> issuesList = getIssuesForFilter(searchFilter);
		response.setContentType("application/json");

		JsonIssueDto jsonIssueDto = new JsonIssueDto();
		if (issuesList != null && issuesList.size() > 0) {
			jsonIssueDto.setMoredata(true);
			jsonIssueDto.setIssueList(issuesList);
		}
		response.getWriter().println(jsonIssueDto.toString());
		response.flushBuffer();
	}

}
