/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.NavigableSet;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mysema.query.types.expr.BooleanExpression;
import com.wizni.reportaspot.model.domain.IssueCategory;
import com.wizni.reportaspot.model.domain.QIssue;
import com.wizni.reportaspot.model.enums.IssueStatus;
import com.wizni.reportaspot.model.security.ReportASpotUser;
import com.wizni.reportaspot.model.util.RASUtility;
import com.wizni.reportaspot.model.viewdto.SearchFilterDto;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.storage.repositories.IssueCategoryRepository;
import com.wizni.reportaspot.storage.repositories.IssueRepository;
import com.wizni.reportaspot.storage.repositories.IssueRepositoryCustom;

/**
 * The Class {@link ChartController} is used as a Web Controller for Admin Web Application for Dashboard page. This
 * contains methods for Loading different graphs.
 */
@Controller
@RequestMapping("admin")
public class ChartController {

	/** The issue repository. */
	@Autowired
	private IssueRepository issueRepository;

	/** The issue repository custom. */
	@Autowired
	private IssueRepositoryCustom issueRepositoryCustom;

	/** The issue category repository. */
	@Autowired
	private IssueCategoryRepository issueCategoryRepository;

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/**
	 * Retrieve Data for HighStockChart based on the {@link SearchFilterDto} criteria.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the list of Data needed to display the chart
	 */
	@RequestMapping(value = "getIssueCount", method = RequestMethod.GET)
	public @ResponseBody
	List<Object[]> highstockChart(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		boolean isFilterStatus = false;
		boolean isFilterCategory = false;

		setLobAndRegionInSearchFilter(request, searchFilter);

		List<Object[]> issues = null;

		if (!searchFilter.getStatus().equals(SearchFilterDto.STATUS_ALL)) {
			isFilterStatus = true;
		}
		if (!searchFilter.getCategoryType().equals(SearchFilterDto.CATEGORY_ALL)) {
			isFilterCategory = true;
		}

		Calendar calToDate = Calendar.getInstance();
		calToDate.setTime(searchFilter.getToDate());
		calToDate.add(Calendar.DATE, 1);

		if (isFilterStatus && isFilterCategory) {
			issues = issueRepositoryCustom.getIssuesChartByCatAndStatus(searchFilter.getFromDate(), calToDate.getTime(),
					searchFilter.getIsSpam(), searchFilter.getCategoryType(), searchFilter.getStatus(), searchFilter.getCustomerId(),
					searchFilter.getLobIds(), searchFilter.getRegionIds());
		} else if (isFilterStatus) {
			issues = issueRepositoryCustom.getIssuesChartByStatus(searchFilter.getFromDate(), calToDate.getTime(),
					searchFilter.getIsSpam(), searchFilter.getStatus(), searchFilter.getCustomerId(), searchFilter.getLobIds(),
					searchFilter.getRegionIds());
		} else if (isFilterCategory) {
			issues = issueRepositoryCustom.getIssuesChartByCat(searchFilter.getFromDate(), calToDate.getTime(), searchFilter.getIsSpam(),
					searchFilter.getCategoryType(), searchFilter.getCustomerId(), searchFilter.getLobIds(), searchFilter.getRegionIds());
		} else {
			issues = issueRepositoryCustom.getIssuesChartByTimeBasic(searchFilter.getFromDate(), calToDate.getTime(),
					searchFilter.getIsSpam(), searchFilter.getCustomerId(), searchFilter.getLobIds(), searchFilter.getRegionIds());
		}

		List<Object[]> dupliIssues = new ArrayList<Object[]>();
		TreeMap<String, Object[]> mapToDetect = new TreeMap<String, Object[]>();
		if (issues != null && issues.size() > 0) {

			Object[] issueFirst = issues.get(0);
			long datumFirst = -1;
			if (issueFirst[0] instanceof BigDecimal) {
				datumFirst = ((BigDecimal) issueFirst[0]).longValue();
			} else {
				datumFirst = ((BigInteger) issueFirst[0]).longValue();
			}

			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MINUTE, 0);
			long lastDate = cal.getTimeInMillis();
			long oneDay = 86400000L;

			for (long i = datumFirst; i <= lastDate; i = i + oneDay) {
				mapToDetect.put(i + IssueStatus.OPEN.toString(), (new Object[] { i, 0, IssueStatus.OPEN.toString() }));
				mapToDetect.put(i + IssueStatus.CLOSED.toString(), (new Object[] { i, 0, IssueStatus.CLOSED.toString() }));
				mapToDetect.put(i + IssueStatus.PENDING.toString(), (new Object[] { i, 0, IssueStatus.PENDING.toString() }));
			}

			for (Object[] issue : issues) {
				long datum = -1;
				if (issue[0] instanceof BigDecimal) {
					datum = ((BigDecimal) issue[0]).longValue();
				} else {
					datum = ((BigInteger) issue[0]).longValue();
				}

				String key = datum + (String) issue[2];

				mapToDetect.put(key, issue);

				if (!issue[2].equals(IssueStatus.OPEN.toString()) && !mapToDetect.containsKey(datum + IssueStatus.OPEN.toString())) {
					mapToDetect.put(datum + IssueStatus.OPEN.toString(), (new Object[] { issue[0], 0, IssueStatus.OPEN.toString() }));
				}
				if (!issue[2].equals(IssueStatus.CLOSED.toString()) && !mapToDetect.containsKey(datum + IssueStatus.CLOSED.toString())) {
					mapToDetect.put(datum + IssueStatus.CLOSED.toString(), new Object[] { issue[0], 0, IssueStatus.CLOSED.toString() });
				}
				if (!issue[2].equals(IssueStatus.PENDING.toString()) && !mapToDetect.containsKey(datum + IssueStatus.PENDING.toString())) {
					mapToDetect.put(datum + IssueStatus.PENDING.toString(), new Object[] { issue[0], 0, IssueStatus.PENDING.toString() });
				}

			}

		}

		NavigableSet<String> keySet = mapToDetect.navigableKeySet();
		for (String key : keySet) {
			dupliIssues.add(mapToDetect.get(key));
		}

		// long minTime = ((BigInteger) dupliIssues.get(0)[0]).longValue();
		// Calendar cal = Calendar.getInstance();
		// cal.setTimeInMillis(minTime);
		// for (int i = 0; i < 4; i++) {
		// cal.add(Calendar.DATE, -1);
		// dupliIssues.add(0, new Object[] { cal.getTimeInMillis(), 0,
		// IssueStatus.OPEN.toString() });
		// dupliIssues.add(0, new Object[] { cal.getTimeInMillis(), 0,
		// IssueStatus.CLOSED.toString() });
		// dupliIssues.add(0, new Object[] { cal.getTimeInMillis(), 0,
		// IssueStatus.PENDING.toString() });
		// }

		return dupliIssues;
	}

	/**
	 * Retrieve Data for Pie chart by category based on the {@link SearchFilterDto} criteria.This shows the number of
	 * issues reported based on the category.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the list of Data needed to display the chart
	 */
	@RequestMapping(value = "getCategoryChartData", method = RequestMethod.GET)
	public @ResponseBody
	List<PieChartDataDto> categoryChartData(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model,
			HttpServletRequest request) {

		Calendar calToDate = Calendar.getInstance();
		calToDate.setTime(searchFilter.getToDate());
		calToDate.add(Calendar.DATE, 1);

		setLobAndRegionInSearchFilter(request, searchFilter);

		List<PieChartDataDto> pieData = new ArrayList<PieChartDataDto>();

		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(searchFilter.getCustomerId());
		QIssue qIssue = QIssue.issue;

		BooleanExpression predicate = qIssue.creationDate
				.between(new Timestamp(searchFilter.getFromDate().getTime()), new Timestamp(calToDate.getTimeInMillis()))
				.and(qIssue.isSpam.eq(searchFilter.getIsSpam())).and(qIssue.isArchived.eq(false)).and(qIssue.isRequestComplete.eq(true));

		if (!searchFilter.getStatus().equals(SearchFilterDto.STATUS_ALL)) {
			predicate = predicate.and(qIssue.status.eq(IssueStatus.getStatus(searchFilter.getStatus())));
		}
		if (searchFilter.getCustomerId() != null) {
			predicate = predicate.and(qIssue.customer.id.eq(searchFilter.getCustomerId()));
		}
		if (searchFilter.getLobIds() != null && !searchFilter.getLobIds().isEmpty()) {
			predicate = predicate.and(qIssue.linesOfBusiness.id.in(searchFilter.getLobIds()));
		}
		if (searchFilter.getRegionIds() != null && !searchFilter.getRegionIds().isEmpty()) {
			predicate = predicate.and(qIssue.region.id.in(searchFilter.getRegionIds()));
		}

		for (IssueCategory issueCategory : issueCategories) {
			String categoryType = issueCategory.getCategoryType();
			long count = issueRepository.count(predicate.and(qIssue.issueCategory.categoryType.eq(categoryType)));
			if (count > 0) {
				PieChartDataDto data = new PieChartDataDto(categoryType, count);
				pieData.add(data);
			}
		}

		return pieData;
	}

	/**
	 * Retrieve Data for Bar chart showing the number of issues reported based on the category by month. It shows the
	 * issues moved from open to pending and pending to closed.
	 * 
	 * @param model {@link Model}
	 * @param categoryId The primary id of the Category for Filtering.
	 * @param request {@link HttpServletRequest}
	 * @return the list of Data needed to display the chart
	 */
	@RequestMapping(value = "getAvgAgeBarChart", method = RequestMethod.GET)
	public @ResponseBody
	List<BarGraphDataDto> avgAgeBarChart(Model model, @RequestParam("category") String categoryId, HttpServletRequest request) {

		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();

		List<Long> regionIds = null;
		/*
		 * Long selectedRegionId = (Long) request.getSession().getAttribute("regionId"); if (selectedRegionId == null) { selectedRegionId =
		 * reportASpotUser.getDefaultUserRegionId(); request.getSession().setAttribute("regionId", selectedRegionId); } regionIds =
		 * Utility.getRegionIdsForUser(selectedRegionId, reportASpotUser.getRegionDropDownDto());
		 */
		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");

		List<BarGraphDataDto> result = new ArrayList<BarGraphDataDto>();
		List<Object[]> pendingIssuesAvgCloseCount = null;
		List<Object[]> closedIssuesAvgCloseCount = null;

		if (categoryId.equals("666")) {
			pendingIssuesAvgCloseCount = issueRepositoryCustom.getAvgAgeOfIssues(IssueStatus.PENDING.toString(), customerId,
					reportASpotUser.getLobIds(), regionIds);
			closedIssuesAvgCloseCount = issueRepositoryCustom.getAvgAgeOfIssues(IssueStatus.CLOSED.toString(), customerId,
					reportASpotUser.getLobIds(), regionIds);
		} else {
			pendingIssuesAvgCloseCount = issueRepositoryCustom.getAvgAgeOfIssues(IssueStatus.PENDING.toString(),
					Long.parseLong(categoryId), customerId, reportASpotUser.getLobIds(), regionIds);
			closedIssuesAvgCloseCount = issueRepositoryCustom.getAvgAgeOfIssues(IssueStatus.CLOSED.toString(), Long.parseLong(categoryId),
					customerId, reportASpotUser.getLobIds(), regionIds);
		}
		/*
		 * 1st is integer and second is average.
		 */
		BigDecimal[] bigDecimalsDataPending = new BigDecimal[12];
		for (Object[] data : pendingIssuesAvgCloseCount) {
			Integer x = null;
			if (data[0] instanceof String) {
				x = Integer.parseInt((String) data[0]);
			} else {
				x = (Integer) data[0];
			}
			bigDecimalsDataPending[x - 1] = (BigDecimal) data[1];
		}

		for (int i = 0; i < bigDecimalsDataPending.length; i++) {
			if (bigDecimalsDataPending[i] == null) {
				bigDecimalsDataPending[i] = BigDecimal.ZERO;
			}
		}

		result.add(new BarGraphDataDto("Open to Pending", bigDecimalsDataPending));

		/*
		 * 1st is integer and second is average.
		 */
		BigDecimal[] bigDecimalsDataPending2 = new BigDecimal[12];
		for (Object[] data : closedIssuesAvgCloseCount) {
			Integer x = null;
			if (data[0] instanceof String) {
				x = Integer.parseInt((String) data[0]);
			} else {
				x = (Integer) data[0];
			}

			bigDecimalsDataPending2[x - 1] = (BigDecimal) data[1];
		}

		for (int i = 0; i < bigDecimalsDataPending2.length; i++) {
			if (bigDecimalsDataPending2[i] == null) {
				bigDecimalsDataPending2[i] = BigDecimal.ZERO;
			}
		}

		result.add(new BarGraphDataDto("Open to Closed", bigDecimalsDataPending2));

		return result;
	}

	/**
	 * Sets the lob and region in search filter.
	 * 
	 * @param request {@link HttpServletRequest}
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 */
	private void setLobAndRegionInSearchFilter(HttpServletRequest request, SearchFilterDto searchFilter) {

		// get user role for user
		ReportASpotUser reportASpotUser = RASUtility.getReportASpotUser();
		searchFilter.setLobIds(reportASpotUser.getLobIds());

		/*
		 * Long selectedRegionId = searchFilter.getSelectedRegionId(); if (selectedRegionId == null) { selectedRegionId = (Long)
		 * request.getSession().getAttribute("regionId"); if (selectedRegionId == null) { selectedRegionId =
		 * reportASpotUser.getDefaultUserRegionId(); } searchFilter.setSelectedRegionId(selectedRegionId); }
		 * request.getSession().setAttribute("regionId", selectedRegionId);
		 * searchFilter.setRegionIds(Utility.getRegionIdsForUser(selectedRegionId, reportASpotUser.getRegionDropDownDto()));
		 */

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);
	}

	/**
	 * Retrieve Data for Pie chart by category based on the {@link SearchFilterDto} criteria.This shows the number of
	 * issues reported based on the Device used to report the issue.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the list of Data needed to display the chart
	 */
	@RequestMapping(value = "getDeviceChartData", method = RequestMethod.GET)
	public @ResponseBody
	List<PieChartDataDto> devicePieChartData(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model,
			HttpServletRequest request) {

		setLobAndRegionInSearchFilter(request, searchFilter);

		List<PieChartDataDto> pieData = new ArrayList<PieChartDataDto>();

		Calendar calToDate = Calendar.getInstance();
		calToDate.setTime(searchFilter.getToDate());
		calToDate.add(Calendar.DATE, 1);

		QIssue qIssue = QIssue.issue;

		BooleanExpression predicate = qIssue.creationDate
				.between(new Timestamp(searchFilter.getFromDate().getTime()), new Timestamp(calToDate.getTimeInMillis()))
				.and(qIssue.isSpam.eq(searchFilter.getIsSpam())).and(qIssue.isArchived.eq(false)).and(qIssue.isRequestComplete.eq(true));

		if (!searchFilter.getStatus().equals(SearchFilterDto.STATUS_ALL)) {
			predicate = predicate.and(qIssue.status.eq(IssueStatus.getStatus(searchFilter.getStatus())));
		}
		if (searchFilter.getCustomerId() != null) {
			predicate = predicate.and(qIssue.customer.id.eq(searchFilter.getCustomerId()));
		}
		if (searchFilter.getLobIds() != null && !searchFilter.getLobIds().isEmpty()) {
			predicate = predicate.and(qIssue.linesOfBusiness.id.in(searchFilter.getLobIds()));
		}
		if (searchFilter.getRegionIds() != null && !searchFilter.getRegionIds().isEmpty()) {
			predicate = predicate.and(qIssue.region.id.in(searchFilter.getRegionIds()));
		}

		List<Object[]> countDevices = issueRepositoryCustom.getDataForIssueByDevice(predicate);
		for (Object[] objects : countDevices) {
			PieChartDataDto data = new PieChartDataDto((String) (objects[0]), (Long) objects[1]);
			pieData.add(data);
		}

		return pieData;
	}

	/**
	 * The Class BarGraphDataDto. DTO used only for {@link BarGraphDataDto} for showing Bar Graph.
	 */
	class BarGraphDataDto {

		/** The name. */
		public String name;

		/** The data. */
		public BigDecimal[] data;

		/**
		 * Instantiates a new bar graph data dto.
		 * 
		 * @param name the name
		 * @param data the data
		 */
		public BarGraphDataDto(String name, BigDecimal[] data) {
			this.name = name;
			this.data = data;
		}
	}

	/**
	 * The Class PieChartDataDto. DTO used only for {@link BarGraphDataDto} for showing Bar Graph.
	 */
	class PieChartDataDto {

		/** The name. */
		public String name;

		/** The y. */
		public Long y;

		/**
		 * Instantiates a new pie chart data dto.
		 * 
		 * @param name the name
		 * @param y the y
		 */
		public PieChartDataDto(String name, Long y) {
			this.name = name;
			this.y = y;
		}

	}

}
