/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.aspects;

import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * The Java class is used for defining AOP aspects for logging purposes only.
 */
public class ReportASpotLoggerAspect {

	/** The logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReportASpotLoggerAspect.class);

	/**
     * Log before the Method is called.
     *
     * @param joinPoint @JoinPoint used
     */
	public void logBefore(JoinPoint joinPoint){
	    logger.debug("Entering Class Name {} Method Name {}",joinPoint.getSignature().getDeclaringTypeName(),joinPoint.getSignature().getName());
	}

    /**
     * Log after the Method is called.
     *
     * @param joinPoint @JoinPoint used
     */
    public void logAfter(JoinPoint joinPoint){
        logger.debug("Exiting Class Name {} Method Name {}",joinPoint.getSignature().getDeclaringTypeName(),joinPoint.getSignature().getName());
    }

}