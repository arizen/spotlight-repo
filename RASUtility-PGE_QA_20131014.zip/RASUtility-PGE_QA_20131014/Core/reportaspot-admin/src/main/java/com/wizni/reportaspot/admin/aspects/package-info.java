/**
 * Defines the Aspects used for Spring AOP for Method Pointcuts.
 *
 * @author Abhishek Chavan
 */
package com.wizni.reportaspot.admin.aspects;