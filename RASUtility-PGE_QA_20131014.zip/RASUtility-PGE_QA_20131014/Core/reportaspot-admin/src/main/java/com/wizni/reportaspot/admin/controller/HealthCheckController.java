/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBException;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wizni.reportaspot.cache.dao.CacheMeterAccount;
import com.wizni.reportaspot.cache.dao.CacheOutageDeviceId;
import com.wizni.reportaspot.cache.redis.RedisMeterAccountRepository;
import com.wizni.reportaspot.cache.redis.RedisOutageRepository;
import com.wizni.reportaspot.model.jaxb.AddIssueImageResponse;

/**
 * Dummy Health check service to see if the Service is alive.
 */
@Controller
@RequestMapping({ "/health/" })
public class HealthCheckController {

	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(HealthCheckController.class);

	/** The redis meter account repository. */
	@Autowired
	private RedisMeterAccountRepository redisMeterAccountRepository;

	/** The redis outage repository. */
	@Autowired
	private RedisOutageRepository redisOutageRepository;

	/**
	 * Ping. Used to check the Health of the system.
	 * 
	 * @return the string
	 */
	@RequestMapping("ping")
	public @ResponseBody
	String ping() {
		CacheMeterAccount meterAccount = new CacheMeterAccount();
		meterAccount.setAccountId("123433");
		meterAccount.setAddress("123, Abc");
		meterAccount.setDeviceId("2121");
		meterAccount.setMeterId("2122222");
		List<String> phoneNumbers = new ArrayList<String>();
		phoneNumbers.add("9976837623");
		phoneNumbers.add("32323");
		meterAccount.setPhoneNumbers(phoneNumbers);
		redisMeterAccountRepository.addMeter(meterAccount);

		CacheOutageDeviceId outageDeviceId = new CacheOutageDeviceId();
		outageDeviceId.setDeviceId(meterAccount.getDeviceId());
		outageDeviceId.setOutageNumber("123453");

		redisOutageRepository.addOutage(outageDeviceId);

		return "pong";
	}

	/**
	 * Pong.
	 * 
	 * @return the string
	 */
	@RequestMapping("pong")
	public @ResponseBody
	String pong() {

		redisMeterAccountRepository.getMeterByAccount("abc");
		redisMeterAccountRepository.getMeterByPhoneNumber("9976837623");
		redisMeterAccountRepository.getMeterByPhoneNumber("32323");

		return "ping";
	}

	/**
	 * Check json.
	 * 
	 * @param httpServletResponse the http servlet response
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws JAXBException the jAXB exception
	 */
	@RequestMapping(value = "jsonHit", method = RequestMethod.OPTIONS)
	public void checkJSON(HttpServletResponse httpServletResponse) throws IOException, JAXBException {

		// ServletServerHttpRequest request = new ServletServerHttpRequest(httpServletRequest);
		// ObjectMapper mapper = new ObjectMapper();

		// StringWriter writer = new StringWriter();
		// IOUtils.copy(request.getBody(), writer,"UTF-8");
		// String theString = writer.toString();
		// System.out.println(theString);

		// Report jsonString = mapper.readValue(request.getBody(), Report.class);

		/*
		 * httpServletResponse.getWriter().append("Abhishek"); httpServletResponse.flushBuffer();
		 */

		httpServletResponse.setHeader("Access-Control-Allow-Origin", "*");
		httpServletResponse.setHeader("Access-Control-Allow-Headers", "Content-Type");

	}

	/**
	 * Check json.
	 * 
	 * @param httpServletRequest the http servlet request
	 * @param httpServletResponse the http servlet response
	 * @return the save issue reponse
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws JAXBException the jAXB exception
	 */
	@RequestMapping(value = "jsonHit", method = RequestMethod.POST, produces = { "application/json", "application/xml" })
	public @ResponseBody
	AddIssueImageResponse checkJSON(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException,
			JAXBException {

		ServletServerHttpRequest request = new ServletServerHttpRequest(httpServletRequest);
		// ObjectMapper mapper = new ObjectMapper();

		StringWriter writer = new StringWriter();
		IOUtils.copy(request.getBody(), writer, "UTF-8");
		String theString = writer.toString();
		if (logger.isDebugEnabled()) {
			logger.debug("checkJSON(HttpServletRequest, HttpServletResponse) - {}", theString); //$NON-NLS-1$
		}

		// Report jsonString = mapper.readValue(request.getBody(), Report.class);

		/*
		 * httpServletResponse.getWriter().append("Abhishek"); httpServletResponse.flushBuffer();
		 */

		AddIssueImageResponse response = new AddIssueImageResponse();
		httpServletResponse.setHeader("Access-Control-Allow-Origin", "*");
		return response;

	}
}
