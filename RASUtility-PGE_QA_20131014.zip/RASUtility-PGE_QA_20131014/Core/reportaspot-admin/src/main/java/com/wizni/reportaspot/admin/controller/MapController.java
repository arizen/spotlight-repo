/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wizni.reportaspot.model.domain.Issue;
import com.wizni.reportaspot.model.domain.IssueCategory;
import com.wizni.reportaspot.model.domain.QIssue;
import com.wizni.reportaspot.model.enums.IssueStatus;
import com.wizni.reportaspot.model.viewdto.HomeViewDto;
import com.wizni.reportaspot.model.viewdto.SearchFilterDto;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.storage.repositories.IssueRepository;

/**
 * Handles requests for the application map page for User site.
 */
@Controller
public class MapController {

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/** The issue repository. */
	@Autowired
	private IssueRepository issueRepository;

	/**
	 * Inits the binder. This is used for Binding the Controller with the said dateformat which takes care of
	 * Initialization.
	 * 
	 * @param binder {@link WebDataBinder}
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	/**
	 * Shows the Map view showing Issues on the map. It also shows hot spots for easy user idenitification.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = { "/mapview.html" }, method = RequestMethod.GET)
	public String home(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		if (searchFilter.getFromDate() == null) {
			Calendar cal = Calendar.getInstance();
			cal.set(2010, 1, 1, 0, 0);
			searchFilter.setFromDate(cal.getTime());
		}

		if (searchFilter.getToDate() == null) {
			Calendar cal2 = Calendar.getInstance();
			cal2.set(Calendar.SECOND, 0);
			cal2.set(Calendar.MINUTE, 0);
			cal2.set(Calendar.HOUR, 0);
			searchFilter.setToDate(cal2.getTime());
		}

		List<Issue> issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(), 1000, false);

		HomeViewDto viewDto = new HomeViewDto();
		viewDto.setIssues(issuesList);

		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(customerId);
		viewDto.setAllIssueCount(issueRepository.count());
		viewDto.setClosedIssueCount(issueRepository.count(QIssue.issue.status.eq(IssueStatus.CLOSED)));

		viewDto.setNewIssueCount(issueRepository.count(QIssue.issue.status.eq(IssueStatus.OPEN)));
		viewDto.setPendingIssueCount(issueRepository.count(QIssue.issue.status.eq(IssueStatus.PENDING)));

		viewDto.setSelectedIssueCount(issueService.getCountOnSearch(searchFilter, false));

		model.addAttribute("viewDto", viewDto);
		model.addAttribute("searchFilter", searchFilter);
		model.addAttribute("issueCategories", issueCategories);

		return "mapview";
	}

	/**
	 * Shows the Map view showing Issues on the map. It also shows hot spots for easy user idenitification.
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "/mapview.html", method = RequestMethod.POST)
	public String homePost(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		List<Issue> issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(), 100, false);

		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(customerId);

		HomeViewDto viewDto = new HomeViewDto();
		viewDto.setIssues(issuesList);

		viewDto.setAllIssueCount(issueRepository.count());
		viewDto.setClosedIssueCount(issueRepository.count(QIssue.issue.status.eq(IssueStatus.CLOSED)));

		viewDto.setNewIssueCount(issueRepository.count(QIssue.issue.status.eq(IssueStatus.OPEN)));

		viewDto.setPendingIssueCount(issueRepository.count(QIssue.issue.status.eq(IssueStatus.PENDING)));

		viewDto.setSelectedIssueCount(issueService.getCountOnSearch(searchFilter, false));

		model.addAttribute("viewDto", viewDto);
		model.addAttribute("searchFilter", searchFilter);
		model.addAttribute("issueCategories", issueCategories);

		return "mapview";
	}
}
