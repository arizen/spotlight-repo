/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.wizni.reportaspot.model.domain.Admin;
import com.wizni.reportaspot.notification.service.SendNotificationToUserService;
import com.wizni.reportaspot.storage.repositories.AdminRepository;
import com.wizni.reportaspot.storage.repositories.GlobalPropertiesRepository;
import com.wizni.reportaspot.websecurity.ReportASpotPasswordEncoder;

/**
 * This controller takes care of the login services like forgot password, token management of forgotten passwords etc.
 * 
 * @author Abhishek Chavan
 * 
 */
@Controller
public class LoginServicesController {

	/** The logger. */
	private final Logger logger = LoggerFactory.getLogger(LoginServicesController.class);

	/**
	 * For Admin Retrieval from DB.
	 */
	@Autowired
	private AdminRepository adminRepository;

	/** The report a spot password encoder. */
	@Autowired
	private ReportASpotPasswordEncoder reportASpotPasswordEncoder;

	/**
	 * For Sending Emails.
	 */
	@Autowired
	private SendNotificationToUserService notificationToUserService;

	/** The global properties repository. */
	@Autowired
	private GlobalPropertiesRepository globalPropertiesRepository;

	/** The super admin email key. */
	private final String SUPER_ADMIN_EMAIL_KEY = "super.admin.email.key";

	/**
	 * This is the method to use via web to reset a password.
	 * 
	 * @param username the username
	 */
	@RequestMapping("/forgot_password")
	public void forgotPassword(@RequestParam(required = true, value = "j_username") String username) {
		if (StringUtils.isNotBlank(username)) {
			Admin admin = adminRepository.findOne(username);
			if (admin != null) {
				String encodedToken = reportASpotPasswordEncoder.encode(String.valueOf(System.currentTimeMillis()));
				admin.setForgotPasswordToken(encodedToken);
				adminRepository.save(admin);

				// String emailBody =
				// "<p>You have requested a new password. Please click on the link below to reset your password.</p><br/> <a href =\"\"></a> ";

			} else {
				// TODO Some error.
			}
		} else {
			// TODO Some error.
		}
	}

	/**
	 * This is the method to use via web to reset a password.
	 * 
	 * @param username the username
	 * @param redirectAttributes the redirect attributes
	 * @return the string
	 */
	@RequestMapping("/forgotPasswordAdmin.html")
	public String forgotPasswordAdmin(@RequestParam(required = true, value = "username") String username,
			final RedirectAttributes redirectAttributes) {

		String notificationMessage = null;

		if (StringUtils.isNotBlank(username)) {
			Admin admin = adminRepository.findOne(username);
			if (admin != null) {
				String emailSuperAdmin = globalPropertiesRepository.getValueForKey(SUPER_ADMIN_EMAIL_KEY);
				if (StringUtils.isNotEmpty(emailSuperAdmin)) {

					String emailBody = String.format(
							"The user %s has requested a reset of password and has used the forgot password feature", username);

					notificationToUserService.sendEmail("", "Forgot Password Requested", emailBody, emailSuperAdmin);

					notificationMessage = "Forgot Password has been requested successfully to Super Admin.";
				}
			} else {
				logger.error("Could not Send email for ForgotPassword. Could not find username.");
				redirectAttributes.addFlashAttribute("message", "Forgot Password has been requested successfully to Super Admin.");
			}
		} else {
			logger.error("Could not Send email for ForgotPassword");
			notificationMessage = "Forgot Password has been requested successfully to Super Admin.";
		}
		redirectAttributes.addFlashAttribute("message", notificationMessage);

		return "redirect:login.html";
	}
}
