/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wizni.reportaspot.model.constants.ICitiConstants;
import com.wizni.reportaspot.model.domain.Issue;
import com.wizni.reportaspot.model.domain.IssueCategory;
import com.wizni.reportaspot.model.util.RASUtility;
import com.wizni.reportaspot.model.viewdto.HomeViewDto;
import com.wizni.reportaspot.model.viewdto.ReportNewIssueDto;
import com.wizni.reportaspot.model.viewdto.SearchFilterDto;
import com.wizni.reportaspot.model.viewdto.UpdateUIIssueDto;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.storage.repositories.IssueRepository;

/**
 * Handles requests for the application home page. This is used for the user pages which are shown as user website.
 */
@Controller
public class HomeController {

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/** The issue repository. */
	@Autowired
	private IssueRepository issueRepository;

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Inits the binder. This is used for Binding the Controller with the said dateformat which takes care of
	 * Initialization.
	 * 
	 * @param binder {@link WebDataBinder}
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	/**
	 * Return the login page for the User.
	 * 
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = { "login.html" }, method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	/**
	 * Return the login page.
	 * 
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String goToAdmin() {
		return "redirect:/admin/home.html";
	}

	/**
	 * Simply selects the home view to render by returning its name. This retrieves Issues based on the
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param search The Search Keyword.
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use. {@link SearchFilterDto}.
	 */
	@RequestMapping(value = { "/home.html" }, method = RequestMethod.GET)
	public String home(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model,
			@RequestParam(value = "se", required = false) String search, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		searchFilter.setSearchTerm(search);

		List<Issue> issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(),
				ICitiConstants.PAGINATION_SIZE, false);

		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(customerId);

		HomeViewDto viewDto = new HomeViewDto();
		viewDto.setIssues(issuesList);

		viewDto.setAllIssueCount(issueRepository.count());
		viewDto.setSelectedIssueCount(issueService.getCountOnSearch(searchFilter, false));

		model.addAttribute("viewDto", viewDto);
		model.addAttribute("issueCategories", issueCategories);
		model.addAttribute("searchFilter", searchFilter);
		return "home";
	}

	/**
	 * Simply selects the home view to render by returning its name. This retrieves Issues based on the
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use. {@link SearchFilterDto}.
	 */
	@RequestMapping(value = "/home.html", method = RequestMethod.POST)
	public String homePost(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		List<Issue> issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(),
				ICitiConstants.PAGINATION_SIZE, false);

		List<IssueCategory> issueCategories = issueService.getAllIssueCategoriesForCustomer(customerId);

		HomeViewDto viewDto = new HomeViewDto();
		viewDto.setIssues(issuesList);

		viewDto.setAllIssueCount(issueRepository.count());
		viewDto.setSelectedIssueCount(issueService.getCountOnSearch(searchFilter, false));

		model.addAttribute("issueCategories", issueCategories);
		model.addAttribute("viewDto", viewDto);
		model.addAttribute("searchFilter", searchFilter);

		return "home";
	}

	/**
	 * Simply selects the home view to render by returning its name. This retrieves Issues based on the
	 * 
	 * @param searchFilter The Search Filter Object DTO contains search params.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use. {@link SearchFilterDto}. This loads issues via ajax.
	 */
	@RequestMapping(value = "/issues_ajax.html", method = RequestMethod.POST)
	public String homeAjaxGetIssues(@ModelAttribute("searchFilter") SearchFilterDto searchFilter, Model model, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		searchFilter.setCustomerId(customerId);

		List<Issue> issuesList = issueService.getIssuesSearchFilter(searchFilter, searchFilter.getPageNumber(),
				ICitiConstants.PAGINATION_SIZE, false);

		HomeViewDto viewDto = new HomeViewDto();
		viewDto.setIssues(issuesList);

		model.addAttribute("viewDto", viewDto);
		model.addAttribute("searchFilter", searchFilter);

		return "issuesAjaxLoad";
	}

	/**
	 * Shows the detailed issue display for a particular issue based on the Id.
	 * 
	 * @param id The Id for the issue to fetch from Database.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "/showReport", method = RequestMethod.GET)
	public String showReport(@RequestParam(value = "id") Long id, Model model, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");

		Issue issue = issueService.getIssue(id);

		UpdateUIIssueDto updateIssueDto = new UpdateUIIssueDto();
		updateIssueDto.setIssue(issue);
		updateIssueDto.setIssueId(issue.getId());
		updateIssueDto.setIssueStatus(issue.getStatus());
		updateIssueDto.setIsSpam(issue.getIsSpam());

		// get near by issues
		List<Object[]> nearByIssues = issueRepository.getNearbyIssues(id, issue.getLatitude(), issue.getLongitude(), customerId,
				ICitiConstants.NEARBY_ISSUES_LIMIT);
		List<Issue> nearByIssueList = new ArrayList<Issue>();
		for (Object[] objects : nearByIssues) {
			Issue nearByIssue = new Issue();

			BigInteger integer = (BigInteger) objects[0];
			nearByIssue.setId(integer.longValue());

			nearByIssue.setThumbnailUrl((String) objects[1]);

			nearByIssueList.add(nearByIssue);
		}
		updateIssueDto.setNearByIssues(nearByIssueList);
		model.addAttribute("updateIssueDto", updateIssueDto);
		return "showreport";
	}

	/**
	 * Report a new {@link Issue} in the system. This shows the Report Issue Page.
	 * 
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "/reportissue.html", method = RequestMethod.GET)
	public String reportNewIssue(Model model, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");

		ReportNewIssueDto reportNewIssueDto = new ReportNewIssueDto();
		reportNewIssueDto.setIssueCategories(issueService.getAllIssueCategoriesForCustomer(customerId));
		model.addAttribute("reportNewIssueDto", reportNewIssueDto);
		return "reportissue";
	}

	/**
	 * Saves the Reported Issue in Database.
	 * 
	 * @param reportNewIssueDto {@link ReportNewIssueDto} Object to store the properties for the new Issue reported.
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "/saveIssueFromUI", method = RequestMethod.POST)
	public String saveIssue(@ModelAttribute(value = "reportNewIssueDto") ReportNewIssueDto reportNewIssueDto, Model model,
			HttpServletRequest request) {

		boolean isReportSaved = false;

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");
		reportNewIssueDto.setCustomerId(customerId);

		// validate issue
		String invalid = RASUtility.validateIssue(reportNewIssueDto.getIssue());

		// validate issue location
		Long regionId = issueService.returnRegionForIssueLocation(reportNewIssueDto.getIssue().getLatitude(), reportNewIssueDto.getIssue()
				.getLongitude(), customerId);
		if (regionId == null) {
			invalid = "Issue cannot be saved as customer does not solve issues for the specified location";
		}

		// if issue is valid
		if (invalid == null) {
			try {
				reportNewIssueDto.setRegionId(regionId);
				issueService.saveIssueFromUI(reportNewIssueDto);
				isReportSaved = true;
			} catch (Exception e) {
				LOGGER.error("Save new Report Issue", e);
			}
			request.getSession().setAttribute("isReportSaved", isReportSaved);
			return "redirect:/home.html";
		} else {

			request.getSession().setAttribute("saveFailureReason", invalid);
			request.getSession().setAttribute("isReportSaved", isReportSaved);

			reportNewIssueDto.setIssueCategories(issueService.getAllIssueCategoriesForCustomer(customerId));
			model.addAttribute("reportNewIssueDto", reportNewIssueDto);

			return "reportissue";
		}
	}

	/**
	 * Shows the Map view for the User showing Issues on a Hot Spot for easy identification for user.
	 * 
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 * @throws JsonGenerationException the json generation exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@RequestMapping(value = "/mapView", method = RequestMethod.GET)
	public String mapView(Model model, HttpServletRequest request) throws JsonGenerationException, JsonMappingException, IOException {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");

		List<Issue> issuesList = issueService.getAllIssues(customerId);

		ObjectMapper mapper = new ObjectMapper();

		mapper.configure(JsonGenerator.Feature.QUOTE_FIELD_NAMES, false);

		String issueListJSon = mapper.writeValueAsString(issuesList);

		model.addAttribute("issuesList", issueListJSon);
		return "map";
	}
}
