/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wizni.reportaspot.model.domain.Issue;
import com.wizni.reportaspot.model.viewdto.IssueAutocompleteDto;
import com.wizni.reportaspot.service.IssueService;

/**
 * The Class SearchController.
 */
@Controller
public class SearchController {

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/**
	 * Gets the issue service.
	 * 
	 * @return the issue service
	 */
	public IssueService getIssueService() {
		return issueService;
	}

	/**
	 * Sets the issue service.
	 * 
	 * @param issueService the new issue service
	 */
	public void setIssueService(IssueService issueService) {
		this.issueService = issueService;
	}

	/**
	 * This is used in search ajax to provide a autocomplete for Issues. It only retrieves the first 10 results.
	 * 
	 * @param query The query for retrieving the results.
	 * @param request {@link HttpServletRequest}
	 * @return The list of the {@link IssueAutocompleteDto} retrived for this query result.
	 */
	@RequestMapping(value = "searchissues", method = RequestMethod.GET)
	public @ResponseBody
	List<IssueAutocompleteDto> searchTitle(@RequestParam(required = true, value = "query") String query, HttpServletRequest request) {

		// get customer id from request
		Long customerId = (Long) request.getAttribute("customerId");

		List<Issue> issues = issueService.getIssuesSearchFilter(query, customerId);

		List<IssueAutocompleteDto> dto = new ArrayList<IssueAutocompleteDto>();
		for (Issue issue : issues) {
			IssueAutocompleteDto cDto = new IssueAutocompleteDto(issue.getId(), issue.getTitle());
			dto.add(cDto);
		}

		return dto;

	}

	/**
	 * The Class StringSearcherObj.
	 */
	class StringSearcherObj {

		/** The id. */
		private String id;

		/** The title. */
		private String title;

		/**
		 * Gets the id.
		 * 
		 * @return the id
		 */
		public String getId() {
			return id;
		}

		/**
		 * Sets the id.
		 * 
		 * @param id the new id
		 */
		public void setId(String id) {
			this.id = id;
		}

		/**
		 * Gets the title.
		 * 
		 * @return the title
		 */
		public String getTitle() {
			return title;
		}

		/**
		 * Sets the title.
		 * 
		 * @param title the new title
		 */
		public void setTitle(String title) {
			this.title = title;
		}
	}

}
