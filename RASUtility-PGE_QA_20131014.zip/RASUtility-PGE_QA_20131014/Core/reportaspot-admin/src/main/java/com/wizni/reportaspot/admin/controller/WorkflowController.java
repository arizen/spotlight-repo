/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.wizni.reportaspot.model.domain.RASWorkflows;

/**
 * 
 * Wizni, Inc. Confidential
 * 
 * Time: 11:22 AM
 * .
 */
@Controller
@RequestMapping("/workflow")
public class WorkflowController {

    /** The logger. */
//    private final Logger logger = LoggerFactory.getLogger(WorkflowController.class);
//
//    @Autowired
//    WorkFlowService workflowService;
//
//    @RequestMapping(method = RequestMethod.POST)
//    public
//    void createWorkflow(HttpServletRequest request, HttpServletResponse response) {
//
//        String jsonBody = "";
//        try {
//            jsonBody = IOUtils.toString(request.getInputStream());
//            RASWorkflows workflow = new Gson().fromJson(jsonBody, RASWorkflows.class);
//            workflowService.create(workflow);
//            response.setStatus(HttpStatus.SC_CREATED);
//        } catch (IOException e) {
//            logger.error("Unable to map workflow to event", e);
//            response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(method = RequestMethod.DELETE)
//    public
//    void deleteWorkflow(@RequestParam(value = "workflowName") String workflowName, HttpServletRequest request, HttpServletResponse response) {
//
//        try {
//            workflowService.delete(workflowName);
//            response.setStatus(HttpStatus.SC_OK);
//        } catch (Exception e) {
//            logger.error("Unable to map workflow to event", e);
//            response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(method = RequestMethod.GET)
//    public
//    @ResponseBody String getWorkflows(Model model, HttpServletRequest request, HttpServletResponse response) {
//
//        //ModelAndView modelAndView = new ModelAndView();
//        try {
//            String list = new Gson().toJson(workflowService.findAll());
//            response.setStatus(HttpStatus.SC_OK);
//            model.addAttribute("workflows", list);
//        } catch (Exception e) {
//            logger.error("Unable to map workflow to event", e);
//            response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
//        }
//        return "workflowList";
//    }
}
