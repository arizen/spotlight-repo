/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.admin.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.wizni.reportaspot.model.enums.NotificationType;
import com.wizni.reportaspot.model.viewdto.NotificationUpdateDto;
import com.wizni.reportaspot.notification.service.OutageNotificationService;
import com.wizni.reportaspot.notification.service.SendNotificationToUserService;

/**
 * The Class NotificationController.
 */
@Controller
public class NotificationController {

	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);

	/** The outage notification service. */
	@Autowired
	private OutageNotificationService outageNotificationService;

	/** The send notification to user service. */
	@Autowired
	private SendNotificationToUserService sendNotificationToUserService;

	/**
	 * Shows the page for Notification.
	 * 
	 * @param model {@link Model}
	 * @param request {@link HttpServletRequest}
	 * @return the tile defination to use.
	 */
	@RequestMapping(value = "notification.html", method = RequestMethod.GET)
	public String showCategory(Model model, HttpServletRequest request) {

		model.addAttribute("notificationUpdateDto", new NotificationUpdateDto());
		return "notification";
	}

	/**
	 * The File to upload for Sending PushNotifications.
	 * 
	 * @param content the content
	 * @param apnsKey the apns key
	 * @return the string
	 */
	@RequestMapping(value = "sendPushNotification", method = RequestMethod.GET)
	public @ResponseBody
	String sendNotification(@RequestParam(value = "content") String content, @RequestParam(value = "apnsKey") String apnsKey) {

		boolean isSent = sendNotificationToUserService.sendPushNotification(apnsKey, content);

		return isSent ? "true" : "false";
	}

	/**
	 * Submit notification.
	 * 
	 * @param notificationUpdateDto the notification update dto
	 * @param model the model
	 * @param request the request
	 * @return the string
	 */
	@RequestMapping(value = "notificationUpdate", method = RequestMethod.POST)
	public String submitNotification(@ModelAttribute(value = "notificationUpdateDto") NotificationUpdateDto notificationUpdateDto,
			Model model, HttpServletRequest request) {

		List<String> messageList = new ArrayList<String>();
		if (notificationUpdateDto != null && notificationUpdateDto.getOutageFile() != null) {

			CommonsMultipartFile outageFile = notificationUpdateDto.getOutageFile();

			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(outageFile.getInputStream()));

				int trIdIndex = -1;
				int etorEndIndex = -1;
				// int causeCodeIndex = -1;

				String line = br.readLine();
				if (line != null) {
					String[] arr = line.split(",");
					int i = 0;
					for (String string : arr) {
						if (string.trim().equalsIgnoreCase("Request ID")) {
							trIdIndex = i;
						} else if (string.trim().equalsIgnoreCase("ETOR End")) {
							etorEndIndex = i;
						}
						i++;
					}
				}

				if (trIdIndex != -1 && etorEndIndex != -1) {
					while ((line = br.readLine()) != null) {
						String[] arr = line.split(",");
						String trId = arr[trIdIndex];
						String etorEnd = arr[etorEndIndex];

						StringBuilder notificationMessage = new StringBuilder("PG&E Outage " + trId + " update: Est. restoration  time "
								+ etorEnd);

						NotificationType notificationType = NotificationType.STATUS_CHANGED;
						String m = outageNotificationService.saveOutageNotification(trId, notificationMessage.toString(), notificationType);
						messageList.add(m);
					}
				} else if (trIdIndex == -1) {
					messageList.add("File format is not correct. Field with header Request ID is required.");
				} else if (etorEndIndex == -1) {
					messageList.add("File format is not correct. Field with header ETOR End is required.");
				}

				br.close();
			} catch (IOException e) {
				logger.error("submitNotification(NotificationUpdateDto, Model, HttpServletRequest)", e); //$NON-NLS-1$
			}

			notificationUpdateDto.setMessages(messageList);
		}

		return "notification";
	}

}
