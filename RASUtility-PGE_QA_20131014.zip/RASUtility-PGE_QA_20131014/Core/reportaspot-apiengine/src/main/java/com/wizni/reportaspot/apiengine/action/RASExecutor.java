/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action;

import java.util.concurrent.Future;

import com.wizni.reportaspot.model.annotation.RASAction;
import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.AbstractRASRequest;
import com.wizni.reportaspot.model.jaxb.AbstractRASResponse;

/**
 * Different implementations of this interface will handle specific types of RAS API requests. The interface provides methods for handling request
 * both in synchronous and asynchronous ways. Each implementation of this interface should be annotated with the {@link RASAction} annotation so that
 * system can register all the implementations at runtime.
 *
 * @param <R> The type of request object extending {@link AbstractRASRequest}
 * @param <T> The type of response object extending {@link AbstractRASResponse}
 * @author WizniDev
 */
public interface RASExecutor<R extends AbstractRASRequest, T extends AbstractRASResponse> {

	/**
	 * Execute.
	 *
	 * @param request the request
	 * @param clazz the clazz
	 * @return the t
	 * @throws RASException the rAS exception
	 */
	T execute(R request, Class<T> clazz) throws RASException;

	/**
	 * Handles the synchronous processing of the specific type of request.
	 *
	 * @param request The request object extending {@link AbstractRASRequest}
	 * @return The response object extending {@link AbstractRASResponse}
	 * @throws RASException if there is a problem while processing the request.
	 */
	T executeSync(R request) throws RASException;

    /**
     * Handles the asynchronous processing of the specific type of request.
     *
     * @param request The request object extending {@link AbstractRASRequest}
     * @return {@link Future} of the response object extending {@link AbstractRASResponse}
     * @throws RASException if there is a problem while processing the request.
     */
    T executeAsync(R request) throws RASException;

    /**
     * Validate.
     *
     * @param request the request
     * @return the action validate
     * @throws RASException the rAS exception
     */
    ActionValidate validate(R request) throws RASException;

    /**
     * Checks if is async supported.
     *
     * @return true, if is async supported
     */
    boolean isAsyncSupported();

    /**
     * Checks if is action execution async.
     *
     * @param request the request
     * @return true, if is action execution async
     */
    boolean isActionExecutionAsync(R request);
}
