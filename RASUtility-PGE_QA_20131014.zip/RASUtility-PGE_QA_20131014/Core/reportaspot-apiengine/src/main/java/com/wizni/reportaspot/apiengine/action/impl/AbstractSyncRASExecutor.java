/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.AbstractRASRequest;
import com.wizni.reportaspot.model.jaxb.AbstractRASResponse;
import com.wizni.reportaspot.service.util.DomainToJaxbConverterService;
import com.wizni.reportaspot.service.util.JaxbToDomainConverterService;

/**
 * The Class AbstractSyncRASExecutor.
 * 
 * @param <R> the generic type
 * @param <T> the generic type
 * @author Abhishek Chavan
 */
public abstract class AbstractSyncRASExecutor<R extends AbstractRASRequest, T extends AbstractRASResponse> extends
		AbstractRASExecutor<R, T> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AbstractSyncRASExecutor.class);

	@Autowired
	protected DomainToJaxbConverterService domainToJaxbConverterService;

	@Autowired
	protected JaxbToDomainConverterService jaxbToDomainConverterService;

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#isAsyncSupported()
	 */
	@Override
	public boolean isAsyncSupported() {
		return false;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#isActionExecutionAsync(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public boolean isActionExecutionAsync(R request) {
		return false;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#executeAsync(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public T executeAsync(R request) throws RASException {
		logger.error("Async method not supported");
		throw new RASException("Async method not supported");
	}
}
