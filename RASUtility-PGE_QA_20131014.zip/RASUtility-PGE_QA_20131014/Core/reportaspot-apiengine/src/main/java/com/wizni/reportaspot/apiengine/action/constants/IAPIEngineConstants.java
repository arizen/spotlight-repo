/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.constants;

/**
 * Constants used in APIEngine Package. For Error Messages.
 * 
 * @author Abhishek Chavan
 * 
 */
public interface IAPIEngineConstants {

	/**
	 * Custom Workflow for Retrieving User Account Details.
	 */
	String WORKFLOW_CUSTOM_USER_ACCOUNTS_RETRIEVE_ALL_DETAILS = "ras.workflows.custom.user.accounts.details.all";

	/**
	 * Custom Workflow for Create Payment for User Account.
	 */
	String WORKFLOW_CUSTOM_USER_ACCOUNTS_PAYMENTS_CREATE_PAYMENT_DETAILS = "ras.workflows.custom.user.accounts.payments.create";

	/**
	 * User Missing from Create Payment.
	 */
	String USER_ACCOUNTS_CREATE_PAYMENT_USER_NOT_FOUND = "user.accounts.create.payment.user.missing.error";

	/**
	 * Account Missing from Create Payment.
	 */
	String USER_ACCOUNTS_CREATE_PAYMENT_ACCOUNT_NOT_FOUND = "user.accounts.create.payment.accountId.missing.error";

}
