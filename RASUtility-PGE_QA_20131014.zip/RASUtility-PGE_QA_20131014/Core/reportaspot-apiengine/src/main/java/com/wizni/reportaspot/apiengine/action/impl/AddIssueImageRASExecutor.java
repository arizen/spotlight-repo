/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.impl;

import com.wizni.reportaspot.apiengine.action.ActionValidate;
import com.wizni.reportaspot.apiengine.action.RASExecutor;
import com.wizni.reportaspot.model.annotation.RASAction;
import com.wizni.reportaspot.model.constants.IGlobalPropConstants;
import com.wizni.reportaspot.model.constants.IMessageConstants;
import com.wizni.reportaspot.model.domain.Issue;
import com.wizni.reportaspot.model.domain.IssueImage;
import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.AddIssueImageRequest;
import com.wizni.reportaspot.model.jaxb.AddIssueImageResponse;
import com.wizni.reportaspot.model.jaxb.Image;
import com.wizni.reportaspot.model.jaxb.ServiceIssue;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.service.MessageTextService;
import com.wizni.reportaspot.service.util.DomainToJaxbConverterService;
import org.apache.camel.Consume;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of {@link RASExecutor} interface to handle add images to issue API requests. This implementation first
 * validates whether the request object is having all the required informations and then provides further processing to
 * save images for the issue in the report-a-spot system.
 * 
 * @author WizniDev
 */
@RASAction(apiVersion = IGlobalPropConstants.API_VERSION_V2)
public class AddIssueImageRASExecutor extends AbstractSyncRASExecutor<AddIssueImageRequest, AddIssueImageResponse> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AddIssueImageRASExecutor.class);

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/** The message text service. */
	@Autowired
	private MessageTextService messageTextService;

	@Autowired
	private DomainToJaxbConverterService domainToJaxbConverterService;

	/* 
	 * (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#execute(com.wizni.reportaspot.jaxb.AbstractRASRequest)
	 */
	@Override
    @Consume(uri = "direct:ADD_ISSUE_IMAGE")
	public AddIssueImageResponse executeSync(AddIssueImageRequest addIssueImageRequest) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("executeSync(AddIssueImageRequest) - start"); //$NON-NLS-1$
		}

		AddIssueImageResponse addIssueImageResponse = new AddIssueImageResponse();
		String errorMsg = null;
		String errorMsgKey = null;
		boolean isSuccess = false;

		ServiceIssue serviceIssue = addIssueImageRequest.getServiceIssue();

		Issue issue = null;

		if (serviceIssue == null) {
			errorMsgKey = IMessageConstants.PARSE_REQUEST_NULL_ERROR;
			errorMsg = messageTextService.getString(IMessageConstants.PARSE_REQUEST_NULL_ERROR);
		} else if (serviceIssue.getReportId() == null || serviceIssue.getReportId().isEmpty()) {
			errorMsgKey = IMessageConstants.ADD_IMAGE_REQUEST_XML_REPORT_ID_NULL;
			errorMsg = messageTextService.getString(IMessageConstants.ADD_IMAGE_REQUEST_XML_REPORT_ID_NULL);
		} else if (serviceIssue.getImages() == null || serviceIssue.getImages().isEmpty()) {
			errorMsgKey = IMessageConstants.ADD_IMAGE_REQUEST_XML_IMAGE_NULL;
			errorMsg = messageTextService.getString(IMessageConstants.ADD_IMAGE_REQUEST_XML_IMAGE_NULL);
		} else {
			List<IssueImage> issueImageList = new ArrayList<IssueImage>();
			List<Image> imageList = serviceIssue.getImages();
			for (Image image : imageList) {
				if (image != null && image.getImageData() != null) {
					IssueImage issueImage = new IssueImage();
					issueImage.setImageName(image.getImageName());
					issueImage.setImageData(image.getImageData());
					issueImageList.add(issueImage);
				}
			}
			issue = issueService.addImageForIssue(Long.parseLong(serviceIssue.getReportId()), issueImageList);
			if (issue == null) {
				errorMsgKey = IMessageConstants.ADD_IMAGE_UPLOAD_FAILED;
				errorMsg = messageTextService.getString(IMessageConstants.ADD_IMAGE_UPLOAD_FAILED);
			} else {
				isSuccess = true;
			}
		}

		if (errorMsgKey == null) {
			domainToJaxbConverterService.getAddIssueImageResponseFromIssue(issue, addIssueImageResponse);
		}

		addIssueImageResponse.setIsSuccess(isSuccess);
		addIssueImageResponse.setErrorMessage(errorMsg);
		addIssueImageResponse.setErrorKey(errorMsgKey);

		if (logger.isDebugEnabled()) {
			logger.debug("executeSync(AddIssueImageRequest) - end"); //$NON-NLS-1$
		}
		return addIssueImageResponse;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#validate(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public ActionValidate validate(AddIssueImageRequest request) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("validate(AddIssueImageRequest) - start"); //$NON-NLS-1$
		}

		if (logger.isDebugEnabled()) {
			logger.debug("validate(AddIssueImageRequest) - end"); //$NON-NLS-1$
		}
		return null;
	}
}
