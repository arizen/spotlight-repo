/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action;

import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.AbstractRASRequest;
import com.wizni.reportaspot.model.jaxb.AbstractRASResponse;

/**
 * This is the interface for retry logic for executors. Some executors may have retry functionality for which this
 * interface can be used.
 * 
 * @param <R> The type of request object extending {@link AbstractRASRequest}
 * @param <T> The type of response object extending {@link AbstractRASResponse}
 * @author WizniDev
 */
public interface RASRetryExecutor<R extends AbstractRASRequest, T extends AbstractRASResponse> {

	/**
	 * Execute.
	 * 
	 * @param request the request
	 * @param clazz the clazz
	 * @return the t
	 * @throws RASException the rAS exception
	 */
	T executeRetry(R request) throws RASException;

	/**
	 * This method returns the request object from the ids.
	 * 
	 * @param ids
	 * @return
	 * @throws RASException
	 */
	R getRequestObject(String ids) throws RASException;
}
