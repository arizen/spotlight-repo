/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action;

import com.wizni.reportaspot.model.constants.IMessageConstants;
import com.wizni.reportaspot.model.jaxb.NotificationJaxb;
import com.wizni.reportaspot.model.jaxb.Reporter;
import com.wizni.reportaspot.model.jaxb.SpamIssueRequest;
import com.wizni.reportaspot.model.jaxb.SupportIssueRequest;

/**
 * This class provides methods to validate whether the request Jaxb object has all 
 * information required to process the action further or not.
 */
public class JaxbValidator {

	/**
     * Validates whether notification jaxb has all the required information or not.
     * 
     * @param notification the notification
     * @param reporter the reporter
     * @return the string
     */
    public static String validateNotification(NotificationJaxb notification, Reporter reporter) {

        if (notification.getEmail() != null && !(notification.getEmail().equals("1") || notification.getEmail().equals("0"))) {
            return IMessageConstants.NOTIFICATION_REQUEST_XML_IS_EMAIL_BOOLEAN;
        }
        if (notification.getSms() != null && !(notification.getSms().equals("1") || notification.getSms().equals("0"))) {
        	return IMessageConstants.NOTIFICATION_REQUEST_XML_IS_SMS_BOOLEAN;
        }
        if (notification.getLocalNotification() != null
                && !(notification.getLocalNotification().equals("1") || notification.getLocalNotification().equals("0"))) {
        	return IMessageConstants.NOTIFICATION_REQUEST_XML_IS_DEVICE_BOOLEAN;
        }
        if (notification.getPushNotification() != null
                && !(notification.getPushNotification().equals("1") || notification.getPushNotification().equals("0"))) {
        	return IMessageConstants.NOTIFICATION_REQUEST_XML_IS_PUSH_NOTIFICATION_BOOLEAN;
        }
        if ((notification.getEmail() != null || notification.getSms() != null || notification.getLocalNotification() != null || notification
                .getPushNotification() != null) && (reporter == null || reporter.getEmailId() == null)) {
        	return IMessageConstants.NOTIFICATION_REQUEST_XML_EMAIL_NULL;
        }
        if (notification.getSms() != null && notification.getSms().equals("1") && (reporter == null || reporter.getPhoneNumber() == null)) {
        	return IMessageConstants.NOTIFICATION_REQUEST_XML_SMS_PHONE_NULL;
        }

        return null;
    }
    
    /**
	 * Validates Support issue request.
	 * 
	 * @param supportIssueRequest the support issue request
	 * @return Response error key.
	 */
    public static String validateSupportIssueRequest(SupportIssueRequest supportIssueRequest) {
        String errorKey = null;
        if(supportIssueRequest == null) {
        	errorKey = IMessageConstants.PARSE_REQUEST_NULL_ERROR;
        } else if (supportIssueRequest.getEmailAddress() == null) {
            errorKey = IMessageConstants.SUPPORT_ISSUE_REQUEST_XML_EMAIL_NULL;
        } else if (supportIssueRequest.getReportId() == null) {
            errorKey = IMessageConstants.SUPPORT_ISSUE_REQUEST_XML_REPORT_ID_NULL;
        }
        return errorKey;
    }
    
    /**
	 * Validates Spam issue request.
	 * 
	 * @param spamIssueRequest the spam issue request
	 * @return Response error key.
	 */
    public static String validateSpamIssueRequest(SpamIssueRequest spamIssueRequest) {
        String errorMsg = null;
        if(spamIssueRequest == null) {
        	errorMsg = IMessageConstants.PARSE_REQUEST_NULL_ERROR;
        } else if (spamIssueRequest.getEmailAddress() == null) {
            errorMsg = IMessageConstants.SPAM_ISSUE_REQUEST_XML_EMAIL_NULL;
        } else if (spamIssueRequest.getReportId() == null) {
            errorMsg = IMessageConstants.SPAM_ISSUE_REQUEST_XML_REPORT_ID_NULL;
        }
        return errorMsg;
    }
}