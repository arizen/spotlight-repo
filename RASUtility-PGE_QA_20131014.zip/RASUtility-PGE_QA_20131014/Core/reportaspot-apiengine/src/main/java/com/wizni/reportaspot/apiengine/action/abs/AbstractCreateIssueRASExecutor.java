/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.abs;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.wizni.reportaspot.apiengine.action.ActionValidate;
import com.wizni.reportaspot.apiengine.action.RASExecutor;
import com.wizni.reportaspot.apiengine.action.RASRetryExecutor;
import com.wizni.reportaspot.apiengine.action.impl.AbstractRASExecutor;
import com.wizni.reportaspot.apiengine.utils.ApiUtils;
import com.wizni.reportaspot.apiengine.validators.CreateIssueActionValidate;
import com.wizni.reportaspot.cache.pojo.RASCacheResponse;
import com.wizni.reportaspot.cache.service.CacheCommandService;
import com.wizni.reportaspot.model.constants.IGlobalPropConstants;
import com.wizni.reportaspot.model.constants.IMessageConstants;
import com.wizni.reportaspot.model.domain.Issue;
import com.wizni.reportaspot.model.domain.IssueComments;
import com.wizni.reportaspot.model.domain.User;
import com.wizni.reportaspot.model.domain.audit.AsyncProcessTrack;
import com.wizni.reportaspot.model.domain.audit.FailedRequest;
import com.wizni.reportaspot.model.domain.audit.enums.RequestStatus;
import com.wizni.reportaspot.model.domain.audit.enums.RequestType;
import com.wizni.reportaspot.model.domain.custom.CustomerCategoryCustomField;
import com.wizni.reportaspot.model.enums.IssueStatus;
import com.wizni.reportaspot.model.enums.ServiceRequestType;
import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.CreateIssueRequest;
import com.wizni.reportaspot.model.jaxb.CreateIssueResponse;
import com.wizni.reportaspot.model.jaxb.ServiceIssue;
import com.wizni.reportaspot.orchestration.service.IncidentCreationService;
import com.wizni.reportaspot.orchestration.service.IncidentNotificationService;
import com.wizni.reportaspot.service.*;
import com.wizni.reportaspot.service.util.DomainToJaxbConverterService;
import com.wizni.reportaspot.spamhandling.SpamDetectionService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.javatuples.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Nullable;
import java.sql.Timestamp;
import java.util.*;
/**
 * Implementation of {@link RASExecutor} interface to handle create issue API requests. This implementation does a
 * 'fail-fast' check i.e. caller is notified at first failure Following checks are implemented: <br>
 * - Issue has all expected parameters as configured for a category, including form custom fields <br>
 * - Issue Category is active <br>
 * - Issue is not a SPAM in case description is provided <br>
 * - Issue geo-cordinates are in valid watch-area supported for utility <br>
 * - Invokes configured orchestration in customer system for specific category. Incident processing workflow will do
 * cache lookup (if issue is cacheable) <br>
 * - Makes a record of issue locally, for issue streams and analytics <br>
 * - Register for notifications with Notification service(based on user specified preferences) <br>
 * - Return back to caller API ticketId
 * 
 * @param <R> the generic type
 * @param <T> the generic type
 * @author WizniDev
 */
public abstract class AbstractCreateIssueRASExecutor<R, T> extends AbstractRASExecutor<CreateIssueRequest, CreateIssueResponse> implements
		RASRetryExecutor<CreateIssueRequest, CreateIssueResponse> {

	/** The Constant logger. */
	protected static final Logger logger = LoggerFactory.getLogger(AbstractCreateIssueRASExecutor.class);

	/** The issue service. */
	@Autowired
	protected IssueService issueService;

	/** The message text service. */
	@Autowired
	protected MessageTextService messageTextService;

	/** The incident creation service. */
	@Autowired
	protected IncidentCreationService incidentCreationService;

	/** The incident notification service. */
	@Autowired
	protected IncidentNotificationService incidentNotificationService;

	/** The spam detection service *. */
	@Autowired
	protected SpamDetectionService spamDetectionService;

	/** The request execution type resolver. */
	@Autowired
	protected RequestExecutionTypeResolver requestExecutionTypeResolver;

	/** The cache command service. */
	@Autowired
	protected CacheCommandService cacheCommandService;

	/** The async process tracking service. */
	@Autowired
	protected AsyncProcessTrackingService asyncProcessTrackingService;

	/** The customer service. */
	@Autowired
	protected CustomerService customerService;

	/** The failed request service. */
	@Autowired
	protected FailedRequestService failedRequestService;

	@Autowired
	protected DomainToJaxbConverterService domainToJaxbConverterService;

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.impl.AbstractRASExecutor#execute(com.wizni.reportaspot.model.jaxb.AbstractRASRequest, java.lang.Class)
	 */
	@Override
	public CreateIssueResponse execute(CreateIssueRequest request, Class<CreateIssueResponse> clazz) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("execute(R, Class<T>) - start"); //$NON-NLS-1$
		}

		CreateIssueResponse response = null;
		CreateIssueActionValidate actionValidate = (CreateIssueActionValidate) validate(request);

		if (actionValidate.isSaveIssue()) {
			/*
			 * After Validation is complete create Issue everytime. Although not correct to support other modules and to keep the API simple
			 * I have set savedIssue in request as it is a part of request for the executeSync and executeAsync methods.
			 */
			ServiceIssue serviceIssue = request.getServiceIssue();
			Issue savedIssue = issueService.saveCreateReqIssue(serviceIssue);
			request.setSavedIssue(savedIssue);

			savedIssue.setIsSpam(actionValidate.isSpam());// Spam is by default false but set it to whatever is coming.
			if (actionValidate.isSuccess()) {
				boolean isActionExecutionAsync = isActionExecutionAsync(request);
				if (isActionExecutionAsync) {
					AsyncProcessTrack asyncProcessTrack = asyncProcessTrackingService.saveAsyncProcess();
					processAsync(request, asyncProcessTrack);
					response = new CreateIssueResponse();
					response.setIsSuccess(true);
					response.setRequestId(String.valueOf(asyncProcessTrack.getId()));
					response.setGeneratedId(String.valueOf(savedIssue.getId()));

					if (logger.isDebugEnabled()) {
						logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
					}
				} else {
					response = executeSync(request);
					if (logger.isDebugEnabled()) {
						logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
					}
					savedIssue.setStatus(IssueStatus.OPEN);
					savedIssue.setIsRequestComplete(true);
				}

				/*
				 * Setting Response Object.
				 */
				domainToJaxbConverterService.getCreateIssueResponseFromIssue(savedIssue, response);

			} else {
				response = new CreateIssueResponse();
				response.setErrorKey(actionValidate.getErrorKey());
				response.setErrorMessage(actionValidate.getErrorMessage());
				if (logger.isDebugEnabled()) {
					logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
				}
			}

			if (BooleanUtils.isFalse(response.getIsSuccess())) {
				/*
				 * Save the issue with error response failure reason etc. Change the status to Failed.
				 */
				savedIssue.setStatus(IssueStatus.FAILED);

				Set<IssueComments> issueComments = new HashSet<IssueComments>();
				IssueComments issueComment = new IssueComments();
				issueComment.setComment("Failure Reason - " + response.getErrorMessage());
				issueComment.setIssue(savedIssue);
				issueComment.setSubmittedDate(new Timestamp(System.currentTimeMillis()));

				User user = new User();
				user.setEmailId("System");
				issueComment.setUser(user);

				issueComments.add(issueComment);

				savedIssue.setCommentsSet(issueComments);

				/*
				 * Save Failed requests.
				 */
				FailedRequest failedRequest = new FailedRequest();
				failedRequest.setRequestStatus(RequestStatus.FAILURE);
				failedRequest.setErrorKey(response.getErrorKey());
				failedRequest.setErrorMsg(response.getErrorMessage());
				failedRequest.setRequestType(RequestType.CREATE_ISSUE);
				failedRequest.setRetryCount(0L);
				failedRequest.setGeneratedId(savedIssue.getId().toString());
				failedRequest.setVersion(IGlobalPropConstants.API_VERSION_V2);

				failedRequestService.saveFailedRequest(failedRequest);
			}
			response.setGeneratedId(String.valueOf(savedIssue.getId()));
			issueService.saveModifiedIssue(savedIssue);
		} else {
			response = new CreateIssueResponse();
			response.setErrorKey(actionValidate.getErrorKey());
			response.setErrorMessage(actionValidate.getErrorMessage());
			if (logger.isDebugEnabled()) {
				logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
			}
		}

		return response;
	}

	/*
	 * (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#execute(com.wizni.reportaspot.jaxb.AbstractRASRequest)
	 */
	@Override
	public CreateIssueResponse executeSync(CreateIssueRequest createIssueRequest) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("executeSync(CreateIssueRequest) - start"); //$NON-NLS-1$
		}

		CreateIssueResponse returnCreateIssueResponse = processRequest(createIssueRequest, createIssueRequest.getSavedIssue());
		if (logger.isDebugEnabled()) {
			logger.debug("executeSync(CreateIssueRequest) - end"); //$NON-NLS-1$
		}
		return returnCreateIssueResponse;
	}

	/*
	 * This is asynchornous implementation that returns to caller immediately after all business rules pass
	 * Customer system workflow is invoked in asynchornous manner
	 * All business rules checks as done as before
	 *
	 * (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#executeAsync(com.wizni.reportaspot.jaxb.AbstractRASRequest)
	 */
	@Override
	public CreateIssueResponse executeAsync(CreateIssueRequest createIssueRequest) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("executeAsync(CreateIssueRequest) - start"); //$NON-NLS-1$
		}

		Issue savedIssue = createIssueRequest.getSavedIssue();

		CreateIssueResponse createIssueResponse = processRequest(createIssueRequest, createIssueRequest.getSavedIssue());

		if (logger.isDebugEnabled()) {
			logger.debug("executeAsync(CreateIssueRequest) - end"); //$NON-NLS-1$
		}

		if (BooleanUtils.isFalse(createIssueResponse.getIsSuccess())) {
			/*
			 * Save the issue with error response failure reason etc. Change the status to Failed.
			 */
			savedIssue.setStatus(IssueStatus.FAILED);

			Set<IssueComments> issueComments = new HashSet<IssueComments>();
			IssueComments issueComment = new IssueComments();
			issueComment.setComment("Failure Reason - " + createIssueResponse.getErrorMessage());
			issueComment.setIssue(savedIssue);
			issueComment.setSubmittedDate(new Timestamp(System.currentTimeMillis()));

			User user = new User();
			user.setEmailId("System");
			issueComment.setUser(user);

			issueComments.add(issueComment);

			savedIssue.setCommentsSet(issueComments);
		} else {
			/*
			 * Save issue to set status to Pending.
			 */
			savedIssue.setStatus(IssueStatus.OPEN);
		}
		savedIssue.setIsRequestComplete(true);
		issueService.saveModifiedIssue(savedIssue);

		return createIssueResponse;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#validate(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public ActionValidate validate(CreateIssueRequest createIssueRequest) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("validate(CreateIssueRequest) - start"); //$NON-NLS-1$
		}

		CreateIssueActionValidate actionValidate = new CreateIssueActionValidate();
		String errorMsg = null;
		String errorMsgKey = null;
		boolean isSuccess = true;

		ServiceIssue serviceIssue = createIssueRequest.getServiceIssue();

		if (serviceIssue == null) {
			isSuccess = false;
			errorMsgKey = IMessageConstants.PARSE_REQUEST_NULL_ERROR;
			errorMsg = messageTextService.getString(IMessageConstants.PARSE_REQUEST_NULL_ERROR);
		} else {

			// check whether the input tags are valid
			Pair<String, String> invalid;
			if ((invalid = issueService.validateReportParams(serviceIssue)) == null) {

				// Check for Active or inactive Status of Category. If Inactive then send error back.
				if (issueService.isCategoryInactive(serviceIssue.getCategory())) {
					errorMsgKey = IMessageConstants.SAVE_ISSUE_ISSUE_CATEGORY_INACTIVE;
					errorMsg = messageTextService.getString(IMessageConstants.SAVE_ISSUE_ISSUE_CATEGORY_INACTIVE);
					isSuccess = false;
				} else {

					// Validate geo-location is in enabled watch-areas for customer-identifier
					Long regionId = issueService.returnRegionForIssueLocation(Double.parseDouble(serviceIssue.getLatitude()),
							Double.parseDouble(serviceIssue.getLongitude()), createIssueRequest.getCustomerId());

					if (regionId == null) {
						errorMsgKey = IMessageConstants.SAVE_ISSUE_LOCATION_NOT_VALID;
						errorMsg = messageTextService.getString(IMessageConstants.SAVE_ISSUE_LOCATION_NOT_VALID,
								serviceIssue.getLatitude(), serviceIssue.getLongitude());
						isSuccess = false;
					}

					// Validate Issue is not spam
					if (isSuccess && spamDetectionService.checkForSpam(serviceIssue.getDescription())) {
						errorMsgKey = IMessageConstants.SAVE_ISSUE_MARKED_AS_SPAM;
						errorMsg = messageTextService.getString(IMessageConstants.SAVE_ISSUE_MARKED_AS_SPAM, serviceIssue.getDescription());
						isSuccess = false;
						actionValidate.setSaveIssue(true); // ActionValidate set the issue to be saved.
						actionValidate.setSpam(true);
					} else {

						/*
						 * Check from cache here.
						 */
						if (isSuccess) {
							RASCacheResponse rasCacheResponse = cacheCommandService.searchInCacheForCreateRequest(serviceIssue);
							if (rasCacheResponse != null && rasCacheResponse.isSuccess()) {
								logger.info("Issue found in Cache.");
								errorMsgKey = IMessageConstants.CREATE_REPORT_OUTAGE_ALREADY_EXISTS;
								errorMsg = messageTextService.getString(IMessageConstants.CREATE_REPORT_OUTAGE_ALREADY_EXISTS);
								isSuccess = false;
							}
						}
					}
				}
			} else {
				errorMsgKey = invalid.getValue0();
				errorMsg = invalid.getValue1();
				isSuccess = false;
			}
		}
		if (isSuccess) {
			/*
			 * Issue should be saved then.
			 */
			actionValidate.setSaveIssue(true);
		}

		actionValidate.setSuccess(isSuccess);
		actionValidate.setErrorKey(errorMsgKey);
		actionValidate.setErrorMessage(errorMsg);

		if (logger.isDebugEnabled()) {
			logger.debug("validate(CreateIssueRequest) - end"); //$NON-NLS-1$
		}
		return actionValidate;
	}

	/**
	 * Process request.
	 * 
	 * @param createIssueRequest the create issue request
	 * @param savedIssue the saved issue
	 * @return the creates the issue response
	 * @throws RASException the rAS exception
	 */
	protected CreateIssueResponse processRequest(CreateIssueRequest createIssueRequest, Issue savedIssue) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("processRequest(CreateIssueRequest) - start"); //$NON-NLS-1$
		}
		CreateIssueResponse createIssueReponse = new CreateIssueResponse();

		ServiceIssue serviceIssue = createIssueRequest.getServiceIssue();

		// perform incident based on configured incident workflow for customer
        CreateIssueResponse createIncidentResponse = incidentCreationService.createIncidentWorkflow(serviceIssue);

		if (createIncidentResponse != null) {

			// save issue in RAS DB
			// Issue savedIssue = issueService.saveIssue(serviceIssue);

			// register for notification
			if (serviceIssue.getNotification() != null && createIncidentResponse.getResponseId() != null
					&& serviceIssue.getReporter() != null && StringUtils.isNotBlank(serviceIssue.getReporter().getEmailId())) {
				incidentNotificationService.registerNotification(createIncidentResponse.getResponseId(), serviceIssue);
			}

			filterCustomFieldsForResponse(createIncidentResponse, savedIssue.getIssueCategory().getId(), savedIssue.getIssueCategory()
					.getVersion(), savedIssue);

			// createIssueResponse for successful request
			// domainToJaxbConverterService.getCreateIssueResponseFromIssue(savedIssue, createIssueReponse);
			createIssueReponse.setTicketId(createIncidentResponse.getResponseId());
		}

		if (createIncidentResponse != null && CollectionUtils.isNotEmpty(createIncidentResponse.getCustomFields())) {
			createIssueReponse.setExtraInfo(ApiUtils.convertPairToCustomFieldJaxb(createIncidentResponse.getCustomFields()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("processRequest(CreateIssueRequest) - end"); //$NON-NLS-1$
		}
		return createIssueReponse;
	}

	/**
	 * This method is used to filter out the response params not needed in the response.
	 * 
	 * @param createIncidentResponse the create incident response
	 * @param categoryId the category id
	 * @param version the version
	 * @param savedIssue the saved issue
	 * @return the issue
	 */
	private Issue filterCustomFieldsForResponse(CreateIssueResponse createIncidentResponse, Long categoryId, String version,
			Issue savedIssue) {
		if (CollectionUtils.isNotEmpty(createIncidentResponse.getCustomFields())) {
			List<CustomerCategoryCustomField> customerCategoryCustomFields = customerService.getCustomFieldsForCategory(categoryId,
					version, ServiceRequestType.CREATE_RES, true);
			final List<String> xmlTags = new ArrayList<String>();

			for (CustomerCategoryCustomField customField : customerCategoryCustomFields) {
				xmlTags.add(customField.getXmlTagName());
			}

			Predicate<Pair<String, String>> predicate = new Predicate<Pair<String, String>>() {
				@Override
				public boolean apply(@Nullable Pair<String, String> input) {
					return xmlTags.contains(input.getValue0());
				}
			};
			Collection<Pair<String, String>> filtered = Collections2.filter(createIncidentResponse.getCustomFields(), predicate);
			List<Pair<String, String>> finalList = new ArrayList<Pair<String, String>>();
			finalList.addAll(filtered);
			createIncidentResponse.setCustomFields(finalList);
			savedIssue = issueService.addCustomFieldsFromResponse(savedIssue, finalList);
		}

		return savedIssue;

	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#isAsyncSupported()
	 */
	@Override
	public boolean isAsyncSupported() {
		return true;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#isActionExecutionAsync(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public boolean isActionExecutionAsync(CreateIssueRequest createIssueRequest) {
		return requestExecutionTypeResolver.isCreateIssueAsync(createIssueRequest.getServiceIssue().getCategory());
	}
}
