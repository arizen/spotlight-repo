/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.impl;

import org.apache.camel.Consume;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wizni.reportaspot.apiengine.action.ActionValidate;
import com.wizni.reportaspot.apiengine.action.RASExecutor;
import com.wizni.reportaspot.model.annotation.RASAction;
import com.wizni.reportaspot.model.constants.IGlobalPropConstants;
import com.wizni.reportaspot.model.constants.IMessageConstants;
import com.wizni.reportaspot.model.domain.IssueComments;
import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.AddCommentRequest;
import com.wizni.reportaspot.model.jaxb.AddCommentResponse;
import com.wizni.reportaspot.service.IssueService;
import com.wizni.reportaspot.service.MessageTextService;

/**
 * Implementation of {@link RASExecutor} interface to handle add issue comment API requests. This implementation first
 * validates whether request object is having all the necessary informations and then processes further to save the
 * issue comment for the issue in the database.
 * 
 * @author WizniDev
 */
@RASAction(apiVersion = IGlobalPropConstants.API_VERSION_V2)
public class AddIssueCommentRASExecutor extends AbstractSyncRASExecutor<AddCommentRequest, AddCommentResponse> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AddIssueCommentRASExecutor.class);

	/** The issue service. */
	@Autowired
	private IssueService issueService;

	/** The message text service. */
	@Autowired
	private MessageTextService messageTextService;

	/* 
	 * (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#execute(com.wizni.reportaspot.jaxb.AbstractRASRequest)
	 */
	@Override
    @Consume(uri = "direct:ADD_ISSUE_COMMENT")
	public AddCommentResponse executeSync(AddCommentRequest addCommentRequest) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("executeSync(AddCommentRequest) - start"); //$NON-NLS-1$
		}

		AddCommentResponse addCommentResponse = new AddCommentResponse();
		String errorMsg = null;
		boolean isSuccess = false;
		String errorMsgKey = null;

		if (addCommentRequest == null) {
			errorMsg = messageTextService.getString(IMessageConstants.PARSE_REQUEST_NULL_ERROR);
			errorMsgKey = IMessageConstants.PARSE_REQUEST_NULL_ERROR;
		} else if (addCommentRequest.getReportId() == null || addCommentRequest.getReportId().isEmpty()) {
			errorMsg = messageTextService.getString(IMessageConstants.ADD_COMMENT_REPORT_ID_NULL);
			errorMsgKey = IMessageConstants.ADD_COMMENT_REPORT_ID_NULL;
		} else if (addCommentRequest.getUserId() == null || addCommentRequest.getUserId().isEmpty()) {
			errorMsg = messageTextService.getString(IMessageConstants.ADD_COMMENT_EMAIL_ID_NULL);
			errorMsgKey = IMessageConstants.ADD_COMMENT_EMAIL_ID_NULL;
		} else if (addCommentRequest.getComment() == null || addCommentRequest.getComment().getText() == null) {
			errorMsg = messageTextService.getString(IMessageConstants.ADD_COMMENT_TEXT_NULL);
			errorMsgKey = IMessageConstants.ADD_COMMENT_TEXT_NULL;
		} else {
			IssueComments issueComments = jaxbToDomainConverterService.getIssueCommentObjectFromAddCommentJaxb(addCommentRequest);
			try {
				issueService.saveIssueComment(issueComments);
				isSuccess = true;
			} catch (Exception e) {
				logger.error("executeSync(AddCommentRequest)", e); //$NON-NLS-1$

				errorMsg = messageTextService.getString(IMessageConstants.ADD_COMMENT_EXCEPTION);
				errorMsgKey = IMessageConstants.ADD_COMMENT_EXCEPTION;
			}
		}

		addCommentResponse.setIsSuccess(isSuccess);
		addCommentResponse.setErrorMessage(errorMsg);
		addCommentResponse.setErrorKey(errorMsgKey);

		if (logger.isDebugEnabled()) {
			logger.debug("executeSync(AddCommentRequest) - end"); //$NON-NLS-1$
		}
		return addCommentResponse;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#validate(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public ActionValidate validate(AddCommentRequest request) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("validate(AddCommentRequest) - start"); //$NON-NLS-1$
		}

		if (logger.isDebugEnabled()) {
			logger.debug("validate(AddCommentRequest) - end"); //$NON-NLS-1$
		}
		return null;
	}
}
