/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.exception;

import com.wizni.reportaspot.apiengine.action.resolver.RASActionResolver;

/**
 * These are thrown by the {@link RASActionResolver#getAction(Class, Class, String)} if 
 * no action is found for the request class and the api version.
 * 
 * @author WizniDev
 */
public class NoActionFoundException extends Exception{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2207361188409660520L;

	/**
	 * No-arg Constructor.
	 */
    public NoActionFoundException() {
        super();
    }

    /**
	 * Constructor which takes message as a argument.
	 * 
	 * @param message - error specific message
	 */
    public NoActionFoundException(String message) {
        super(message);
    }

    /**
	 * Constructor which takes message and Throwable class instance.
	 * 
	 * @param message - error specific message
	 * @param cause - root cause
	 */
    public NoActionFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
	 * Constructor which takes Throwable class instance.
	 * 
	 * @param cause - root cause
	 */
    public NoActionFoundException(Throwable cause) {
        super(cause);
    }
}
