/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action;

/**
 * The Class ActionValidate.
 *
 * @author WizniDev
 */
public class ActionValidate {

	/** The is success. */
	private boolean isSuccess = true;
	
	/** The error message. */
	private String errorMessage;
	
	/** The error key. */
	private String errorKey;

	/**
	 * Checks if is success.
	 *
	 * @return the getIsSuccess
	 */
	public boolean isSuccess() {
		return isSuccess;
	}

	/**
	 * Sets the success.
	 *
	 * @param isSuccess the getIsSuccess to set
	 */
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the error key.
	 *
	 * @return the errorKey
	 */
	public String getErrorKey() {
		return errorKey;
	}

	/**
	 * Sets the error key.
	 *
	 * @param errorKey the errorKey to set
	 */
	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}
}
