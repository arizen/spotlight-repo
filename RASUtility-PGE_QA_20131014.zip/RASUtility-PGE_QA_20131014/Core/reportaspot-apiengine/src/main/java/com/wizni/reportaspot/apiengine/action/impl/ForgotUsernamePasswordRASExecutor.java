/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.impl;

import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;

import com.wizni.reportaspot.apiengine.action.ActionValidate;
import com.wizni.reportaspot.model.annotation.RASAction;
import com.wizni.reportaspot.model.constants.IGlobalPropConstants;
import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.login.ForgotUsernamePasswordRequest;
import com.wizni.reportaspot.model.jaxb.login.ForgotUsernamePasswordResponse;
import com.wizni.reportaspot.service.MessageTextService;

/**
 * The Class StartIssueProcessingRASExecutor.
 */
@RASAction(apiVersion = IGlobalPropConstants.API_VERSION_V2)
public class ForgotUsernamePasswordRASExecutor extends
		AbstractSyncRASExecutor<ForgotUsernamePasswordRequest, ForgotUsernamePasswordResponse> {

	/** The message text service. */
	@Autowired
	private MessageTextService messageTextService;

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#executeSync(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public ForgotUsernamePasswordResponse executeSync(ForgotUsernamePasswordRequest request) throws RASException {
		Assert.assertNotNull(request);
		ForgotUsernamePasswordResponse forgotUsernamePasswordResponse = new ForgotUsernamePasswordResponse();
		boolean isSuccess = false;
		String errorMsg = null;
		String errorCode = null;


		forgotUsernamePasswordResponse.setErrorKey(errorCode);
		forgotUsernamePasswordResponse.setErrorMessage(errorMsg);
		forgotUsernamePasswordResponse.setIsSuccess(isSuccess);

		return forgotUsernamePasswordResponse;
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#validate(com.wizni.reportaspot.model.jaxb.AbstractRASRequest)
	 */
	@Override
	public ActionValidate validate(ForgotUsernamePasswordRequest request) throws RASException {
		return null;
	}

}
