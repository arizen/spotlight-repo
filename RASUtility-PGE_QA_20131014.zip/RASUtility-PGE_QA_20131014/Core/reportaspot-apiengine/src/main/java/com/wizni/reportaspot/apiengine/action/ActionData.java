/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action;

public class ActionData<R,T> implements IActionData {
    Class requestClass;
    Class responseClass;
    R data;
    //List<responseClass>
    String apiVersion;

    @Override
    public Class getRequestClass() {
        return requestClass;
    }

    @Override
    public void setRequestClass(Class clazz) {
        this.requestClass = clazz;
    }

    @Override
    public Class getResponseClass() {
        return responseClass;
    }

    @Override
    public void setResponseClass(Class responseClass) {
        this.responseClass = responseClass;
    }

    public R getData() {
        return data;
    }

    public void setData(R data) {
        this.data = data;
    }

    @Override
    public String getApiVersion() {
        return apiVersion;
    }

    @Override
    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }
}
