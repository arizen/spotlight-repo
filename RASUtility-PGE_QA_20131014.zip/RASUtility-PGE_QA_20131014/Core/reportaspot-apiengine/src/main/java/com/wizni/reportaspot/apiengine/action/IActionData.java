/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action;

/**
 * .
 * Wizni, Inc. Confidential
 *
 * Time: 12:19 AM
 *
 */
public interface IActionData{
    Class getRequestClass();

    void setRequestClass(Class clazz);

    Class getResponseClass();

    void setResponseClass(Class responseClass);

    String getApiVersion();

    void setApiVersion(String apiVersion);
}
