/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.apiengine.action.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;

import com.wizni.reportaspot.apiengine.action.ActionValidate;
import com.wizni.reportaspot.apiengine.action.RASExecutor;
import com.wizni.reportaspot.model.domain.audit.AsyncProcessTrack;
import com.wizni.reportaspot.model.exception.RASException;
import com.wizni.reportaspot.model.jaxb.AbstractRASRequest;
import com.wizni.reportaspot.model.jaxb.AbstractRASResponse;
import com.wizni.reportaspot.service.AsyncProcessTrackingService;

/**
 * The Class AbstractRASExecutor.
 *
 * @param <R> the generic type
 * @param <T> the generic type
 * @author Abhishek Chavan
 */
public abstract class AbstractRASExecutor<R extends AbstractRASRequest, T extends AbstractRASResponse> implements RASExecutor<R, T> {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(AbstractRASExecutor.class);

	/** The task executor for async ops. */
	@Autowired
	@Qualifier("taskExecutorForAsyncOps")
	private TaskExecutor taskExecutorForAsyncOps;

	/** The async process tracking service. */
	@Autowired
	private AsyncProcessTrackingService asyncProcessTrackingService;

	/**
	 * Initialize.
	 *
	 * @param clazz the clazz
	 * @return the t
	 * @throws RASException the rAS exception
	 */
	private T initialize(Class<T> clazz) throws RASException {
		try {
			return clazz.newInstance();
		} catch (InstantiationException e) {
			logger.error("Error while instantiating response object");
			throw new RASException("Error while instantiating response object");
		} catch (IllegalAccessException e) {
			logger.error("Error while instantiating response object");
			throw new RASException("Error while instantiating response object");
		}
	}

	/* (non-Javadoc)
	 * @see com.wizni.reportaspot.apiengine.action.RASExecutor#execute(com.wizni.reportaspot.model.jaxb.AbstractRASRequest, java.lang.Class)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public T execute(R request, Class<T> clazz) throws RASException {
		if (logger.isDebugEnabled()) {
			logger.debug("execute(R, Class<T>) - start"); //$NON-NLS-1$
		}

		ActionValidate actionValidate = validate(request);

		if (actionValidate == null || actionValidate.isSuccess()) {

			boolean isAsyncSupported = isAsyncSupported();
			if (!isAsyncSupported) {
				T returnT = executeSync(request);
				if (logger.isDebugEnabled()) {
					logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
				}
				return returnT;
			} else {

				boolean isActionExecutionAsync = isActionExecutionAsync(request);
				if (isActionExecutionAsync) {
					AsyncProcessTrack asyncProcessTrack = asyncProcessTrackingService.saveAsyncProcess();
					processAsync(request, asyncProcessTrack);
					AbstractRASResponse response = initialize(clazz);
					response.setIsSuccess(true);
					response.setRequestId(asyncProcessTrack.getId() + "");
					T returnT = (T) response;
					if (logger.isDebugEnabled()) {
						logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
					}
					return returnT;
				} else {
					T returnT = executeSync(request);
					if (logger.isDebugEnabled()) {
						logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
					}
					return returnT;
				}
			}
		} else {
			AbstractRASResponse response = initialize(clazz);
			response.setErrorKey(actionValidate.getErrorKey());
			response.setErrorMessage(actionValidate.getErrorMessage());
			T returnT = (T) response;
			if (logger.isDebugEnabled()) {
				logger.debug("execute(R, Class<T>) - end"); //$NON-NLS-1$
			}
			return returnT;
		}
	}

	/**
	 * Process async.
	 *
	 * @param request the request
	 * @param asyncProcessTrack the async process track
	 */
	public void processAsync(final R request, final AsyncProcessTrack asyncProcessTrack) {

		taskExecutorForAsyncOps.execute(new Runnable() {

			@Override
			public void run() {
				if (logger.isDebugEnabled()) {
					logger.debug("processAsync(R, AsyncProcessTrack) - start"); //$NON-NLS-1$
				}

				T response = null;
				try {
					response = executeAsync(request);
					asyncProcessTrackingService.updateAsyncProcess(asyncProcessTrack, response);
				} catch (RASException e) {
					logger.error("Some error occurred while processing action", e);
				}

				if (logger.isDebugEnabled()) {
					logger.debug("processAsync(R, AsyncProcessTrack) - end"); //$NON-NLS-1$
				}

			}
		});

	}
}
