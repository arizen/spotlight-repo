/**
 * Provides the exceptions that can be thrown while registering and resolving actions
 * for RAS API's.
 */
package com.wizni.reportaspot.apiengine.action.exception;