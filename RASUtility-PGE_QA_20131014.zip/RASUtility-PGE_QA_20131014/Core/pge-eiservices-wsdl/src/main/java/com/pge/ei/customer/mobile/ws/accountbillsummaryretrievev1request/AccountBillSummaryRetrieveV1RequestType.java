
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountBillSummaryRetrieveV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountBillSummaryRetrieveV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountIDList" type="{com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Request}AccountIDListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountBillSummaryRetrieveV1RequestType", propOrder = {
    "accountIDList"
})
public class AccountBillSummaryRetrieveV1RequestType {

    @XmlElement(required = true)
    protected AccountIDListType accountIDList;

    /**
     * Gets the value of the accountIDList property.
     * 
     * @return
     *     possible object is
     *     {@link AccountIDListType }
     *     
     */
    public AccountIDListType getAccountIDList() {
        return accountIDList;
    }

    /**
     * Sets the value of the accountIDList property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountIDListType }
     *     
     */
    public void setAccountIDList(AccountIDListType value) {
        this.accountIDList = value;
    }

}
