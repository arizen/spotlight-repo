
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentAccountListRetrieveV1ResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentAccountListRetrieveV1ResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="responseCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="responseMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="paymentAccountList" type="{com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Response}PaymentAccountListType" minOccurs="0"/>
 *         &lt;element name="ActivityLogs" type="{com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Response}ArrayOfWSActivityLog"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentAccountListRetrieveV1ResponseType", propOrder = {
    "responseCode",
    "responseMessage",
    "paymentAccountList",
    "activityLogs"
})
public class PaymentAccountListRetrieveV1ResponseType {

    @XmlElement(required = true)
    protected String responseCode;
    @XmlElement(required = true)
    protected String responseMessage;
    protected PaymentAccountListType paymentAccountList;
    @XmlElement(name = "ActivityLogs", required = true, nillable = true)
    protected ArrayOfWSActivityLog activityLogs;

    /**
     * Gets the value of the responseCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseCode() {
        return responseCode;
    }

    /**
     * Sets the value of the responseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseCode(String value) {
        this.responseCode = value;
    }

    /**
     * Gets the value of the responseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseMessage() {
        return responseMessage;
    }

    /**
     * Sets the value of the responseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseMessage(String value) {
        this.responseMessage = value;
    }

    /**
     * Gets the value of the paymentAccountList property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentAccountListType }
     *     
     */
    public PaymentAccountListType getPaymentAccountList() {
        return paymentAccountList;
    }

    /**
     * Sets the value of the paymentAccountList property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentAccountListType }
     *     
     */
    public void setPaymentAccountList(PaymentAccountListType value) {
        this.paymentAccountList = value;
    }

    /**
     * Gets the value of the activityLogs property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfWSActivityLog }
     *     
     */
    public ArrayOfWSActivityLog getActivityLogs() {
        return activityLogs;
    }

    /**
     * Sets the value of the activityLogs property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfWSActivityLog }
     *     
     */
    public void setActivityLogs(ArrayOfWSActivityLog value) {
        this.activityLogs = value;
    }

}
