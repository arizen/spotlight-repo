
package com.pge.ei.customer.mobile.ws.retrieveoutagestatusv1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.data.customeroutagev1.InterfaceNameType;


/**
 * <p>Java class for MessageBodyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageBodyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="messageID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element ref="{com/pge/data/CustomerOutageV1}interfaceName"/>
 *         &lt;element name="cisServicePointID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisTransformer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisElectricPhase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisAMIStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisMeterReadRoute" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisRotatingOutageBlock" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisOperationsArea" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cisServiceCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ineligibleReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outOutageNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outCrewStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outCrewETA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outETOI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outOutageStart" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outETOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outETOREnd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outETORUpdate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outCauseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outOutageExtent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outEmergencyLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageBodyType", propOrder = {
    "messageID",
    "interfaceName",
    "cisServicePointID",
    "cisTransformer",
    "cisElectricPhase",
    "cisAMIStatus",
    "cisMeterReadRoute",
    "cisRotatingOutageBlock",
    "cisOperationsArea",
    "cisServiceCity",
    "ineligibleReason",
    "outOutageNumber",
    "outStatus",
    "outCrewStatus",
    "outCrewETA",
    "outETOI",
    "outOutageStart",
    "outETOR",
    "outETOREnd",
    "outETORUpdate",
    "outCauseCode",
    "outOutageExtent",
    "outEmergencyLevel"
})
public class MessageBodyType {

    @XmlElement(required = true)
    protected String messageID;
    @XmlElement(namespace = "com/pge/data/CustomerOutageV1", required = true)
    protected InterfaceNameType interfaceName;
    protected String cisServicePointID;
    protected String cisTransformer;
    protected String cisElectricPhase;
    protected String cisAMIStatus;
    protected String cisMeterReadRoute;
    protected String cisRotatingOutageBlock;
    protected String cisOperationsArea;
    protected String cisServiceCity;
    protected String ineligibleReason;
    protected String outOutageNumber;
    protected String outStatus;
    protected String outCrewStatus;
    protected String outCrewETA;
    protected String outETOI;
    protected String outOutageStart;
    protected String outETOR;
    protected String outETOREnd;
    protected String outETORUpdate;
    protected String outCauseCode;
    protected String outOutageExtent;
    protected String outEmergencyLevel;

    /**
     * Gets the value of the messageID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageID() {
        return messageID;
    }

    /**
     * Sets the value of the messageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageID(String value) {
        this.messageID = value;
    }

    /**
     * Gets the value of the interfaceName property.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceNameType }
     *     
     */
    public InterfaceNameType getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the value of the interfaceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceNameType }
     *     
     */
    public void setInterfaceName(InterfaceNameType value) {
        this.interfaceName = value;
    }

    /**
     * Gets the value of the cisServicePointID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisServicePointID() {
        return cisServicePointID;
    }

    /**
     * Sets the value of the cisServicePointID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisServicePointID(String value) {
        this.cisServicePointID = value;
    }

    /**
     * Gets the value of the cisTransformer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisTransformer() {
        return cisTransformer;
    }

    /**
     * Sets the value of the cisTransformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisTransformer(String value) {
        this.cisTransformer = value;
    }

    /**
     * Gets the value of the cisElectricPhase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisElectricPhase() {
        return cisElectricPhase;
    }

    /**
     * Sets the value of the cisElectricPhase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisElectricPhase(String value) {
        this.cisElectricPhase = value;
    }

    /**
     * Gets the value of the cisAMIStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisAMIStatus() {
        return cisAMIStatus;
    }

    /**
     * Sets the value of the cisAMIStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisAMIStatus(String value) {
        this.cisAMIStatus = value;
    }

    /**
     * Gets the value of the cisMeterReadRoute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisMeterReadRoute() {
        return cisMeterReadRoute;
    }

    /**
     * Sets the value of the cisMeterReadRoute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisMeterReadRoute(String value) {
        this.cisMeterReadRoute = value;
    }

    /**
     * Gets the value of the cisRotatingOutageBlock property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisRotatingOutageBlock() {
        return cisRotatingOutageBlock;
    }

    /**
     * Sets the value of the cisRotatingOutageBlock property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisRotatingOutageBlock(String value) {
        this.cisRotatingOutageBlock = value;
    }

    /**
     * Gets the value of the cisOperationsArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisOperationsArea() {
        return cisOperationsArea;
    }

    /**
     * Sets the value of the cisOperationsArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisOperationsArea(String value) {
        this.cisOperationsArea = value;
    }

    /**
     * Gets the value of the cisServiceCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisServiceCity() {
        return cisServiceCity;
    }

    /**
     * Sets the value of the cisServiceCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisServiceCity(String value) {
        this.cisServiceCity = value;
    }

    /**
     * Gets the value of the ineligibleReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIneligibleReason() {
        return ineligibleReason;
    }

    /**
     * Sets the value of the ineligibleReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIneligibleReason(String value) {
        this.ineligibleReason = value;
    }

    /**
     * Gets the value of the outOutageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutOutageNumber() {
        return outOutageNumber;
    }

    /**
     * Sets the value of the outOutageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutOutageNumber(String value) {
        this.outOutageNumber = value;
    }

    /**
     * Gets the value of the outStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutStatus() {
        return outStatus;
    }

    /**
     * Sets the value of the outStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutStatus(String value) {
        this.outStatus = value;
    }

    /**
     * Gets the value of the outCrewStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutCrewStatus() {
        return outCrewStatus;
    }

    /**
     * Sets the value of the outCrewStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutCrewStatus(String value) {
        this.outCrewStatus = value;
    }

    /**
     * Gets the value of the outCrewETA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutCrewETA() {
        return outCrewETA;
    }

    /**
     * Sets the value of the outCrewETA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutCrewETA(String value) {
        this.outCrewETA = value;
    }

    /**
     * Gets the value of the outETOI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutETOI() {
        return outETOI;
    }

    /**
     * Sets the value of the outETOI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutETOI(String value) {
        this.outETOI = value;
    }

    /**
     * Gets the value of the outOutageStart property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutOutageStart() {
        return outOutageStart;
    }

    /**
     * Sets the value of the outOutageStart property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutOutageStart(String value) {
        this.outOutageStart = value;
    }

    /**
     * Gets the value of the outETOR property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutETOR() {
        return outETOR;
    }

    /**
     * Sets the value of the outETOR property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutETOR(String value) {
        this.outETOR = value;
    }

    /**
     * Gets the value of the outETOREnd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutETOREnd() {
        return outETOREnd;
    }

    /**
     * Sets the value of the outETOREnd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutETOREnd(String value) {
        this.outETOREnd = value;
    }

    /**
     * Gets the value of the outETORUpdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutETORUpdate() {
        return outETORUpdate;
    }

    /**
     * Sets the value of the outETORUpdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutETORUpdate(String value) {
        this.outETORUpdate = value;
    }

    /**
     * Gets the value of the outCauseCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutCauseCode() {
        return outCauseCode;
    }

    /**
     * Sets the value of the outCauseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutCauseCode(String value) {
        this.outCauseCode = value;
    }

    /**
     * Gets the value of the outOutageExtent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutOutageExtent() {
        return outOutageExtent;
    }

    /**
     * Sets the value of the outOutageExtent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutOutageExtent(String value) {
        this.outOutageExtent = value;
    }

    /**
     * Gets the value of the outEmergencyLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutEmergencyLevel() {
        return outEmergencyLevel;
    }

    /**
     * Sets the value of the outEmergencyLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutEmergencyLevel(String value) {
        this.outEmergencyLevel = value;
    }

}
