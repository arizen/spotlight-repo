
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AuditLogRetrievalType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuditLogRetrievalType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="auditLogRetrieval" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuditLogRetrievalType", propOrder = {
    "auditLogRetrieval"
})
public class AuditLogRetrievalType {

    protected boolean auditLogRetrieval;

    /**
     * Gets the value of the auditLogRetrieval property.
     * 
     */
    public boolean isAuditLogRetrieval() {
        return auditLogRetrieval;
    }

    /**
     * Sets the value of the auditLogRetrieval property.
     * 
     */
    public void setAuditLogRetrieval(boolean value) {
        this.auditLogRetrieval = value;
    }

}
