
package com.pge.customerservice.ws.outagenotificationcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.customerservice.ws.outagenotificationcreatev1response.OutageNotificationCreateV1Response;


/**
 * <p>Java class for createOutageNotificationResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createOutageNotificationResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/customerservice/ws/OutageNotificationCreateV1Response}OutageNotificationCreateV1Response" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createOutageNotificationResponse", propOrder = {
    "outageNotificationCreateV1Response"
})
public class CreateOutageNotificationResponse {

    @XmlElement(name = "OutageNotificationCreateV1Response", namespace = "com/pge/customerservice/ws/OutageNotificationCreateV1Response")
    protected OutageNotificationCreateV1Response outageNotificationCreateV1Response;

    /**
     * Gets the value of the outageNotificationCreateV1Response property.
     * 
     * @return
     *     possible object is
     *     {@link OutageNotificationCreateV1Response }
     *     
     */
    public OutageNotificationCreateV1Response getOutageNotificationCreateV1Response() {
        return outageNotificationCreateV1Response;
    }

    /**
     * Sets the value of the outageNotificationCreateV1Response property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutageNotificationCreateV1Response }
     *     
     */
    public void setOutageNotificationCreateV1Response(OutageNotificationCreateV1Response value) {
        this.outageNotificationCreateV1Response = value;
    }

}
