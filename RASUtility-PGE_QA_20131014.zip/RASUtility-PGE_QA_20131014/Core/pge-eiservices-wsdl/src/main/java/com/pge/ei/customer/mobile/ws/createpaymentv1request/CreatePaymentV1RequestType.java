
package com.pge.ei.customer.mobile.ws.createpaymentv1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreatePaymentV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreatePaymentV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userAccount" type="{com/pge/ei/customer/mobile/ws/CreatePaymentV1Request}UserAccountType"/>
 *         &lt;element name="payments" type="{com/pge/ei/customer/mobile/ws/CreatePaymentV1Request}CreatePaymentListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreatePaymentV1RequestType", propOrder = {
    "userAccount",
    "payments"
})
public class CreatePaymentV1RequestType {

    @XmlElement(required = true)
    protected UserAccountType userAccount;
    @XmlElement(required = true)
    protected CreatePaymentListType payments;

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountType }
     *     
     */
    public UserAccountType getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountType }
     *     
     */
    public void setUserAccount(UserAccountType value) {
        this.userAccount = value;
    }

    /**
     * Gets the value of the payments property.
     * 
     * @return
     *     possible object is
     *     {@link CreatePaymentListType }
     *     
     */
    public CreatePaymentListType getPayments() {
        return payments;
    }

    /**
     * Sets the value of the payments property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreatePaymentListType }
     *     
     */
    public void setPayments(CreatePaymentListType value) {
        this.payments = value;
    }

}
