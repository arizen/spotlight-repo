
package com.pge.ei.customer.mobile.ws.accountprofileretrievev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountProfileRetrieveV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountProfileRetrieveV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userAccount" type="{com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Request}UserAccountType"/>
 *         &lt;element name="accountNumberList" type="{com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Request}AccountNumberListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountProfileRetrieveV1RequestType", propOrder = {
    "userAccount",
    "accountNumberList"
})
public class AccountProfileRetrieveV1RequestType {

    @XmlElement(required = true)
    protected UserAccountType userAccount;
    @XmlElement(required = true)
    protected AccountNumberListType accountNumberList;

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountType }
     *     
     */
    public UserAccountType getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountType }
     *     
     */
    public void setUserAccount(UserAccountType value) {
        this.userAccount = value;
    }

    /**
     * Gets the value of the accountNumberList property.
     * 
     * @return
     *     possible object is
     *     {@link AccountNumberListType }
     *     
     */
    public AccountNumberListType getAccountNumberList() {
        return accountNumberList;
    }

    /**
     * Sets the value of the accountNumberList property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountNumberListType }
     *     
     */
    public void setAccountNumberList(AccountNumberListType value) {
        this.accountNumberList = value;
    }

}
