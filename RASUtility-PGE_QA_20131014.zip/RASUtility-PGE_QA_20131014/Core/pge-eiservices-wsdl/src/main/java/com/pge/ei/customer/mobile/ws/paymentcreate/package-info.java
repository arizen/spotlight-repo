@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/PaymentCreate", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.ei.customer.mobile.ws.paymentcreate;
