
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.pge.data.eligibilityrulev2.EligibilityRuleListType;


/**
 * <p>Java class for AccountBillSummaryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountBillSummaryType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="financialTransactionList" type="{com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Response}FinancialTransactionListType"/>
 *         &lt;element name="lastBillID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="billDueDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element ref="{com/pge/data/EligibilityRuleV2}ineligibilityRuleList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountBillSummaryType", propOrder = {
    "financialTransactionList",
    "lastBillID",
    "billDate",
    "billDueDate",
    "ineligibilityRuleList"
})
public class AccountBillSummaryType {

    @XmlElement(required = true)
    protected FinancialTransactionListType financialTransactionList;
    @XmlElement(required = true)
    protected String lastBillID;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar billDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar billDueDate;
    @XmlElement(namespace = "com/pge/data/EligibilityRuleV2")
    protected EligibilityRuleListType ineligibilityRuleList;

    /**
     * Gets the value of the financialTransactionList property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialTransactionListType }
     *     
     */
    public FinancialTransactionListType getFinancialTransactionList() {
        return financialTransactionList;
    }

    /**
     * Sets the value of the financialTransactionList property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialTransactionListType }
     *     
     */
    public void setFinancialTransactionList(FinancialTransactionListType value) {
        this.financialTransactionList = value;
    }

    /**
     * Gets the value of the lastBillID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastBillID() {
        return lastBillID;
    }

    /**
     * Sets the value of the lastBillID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastBillID(String value) {
        this.lastBillID = value;
    }

    /**
     * Gets the value of the billDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBillDate() {
        return billDate;
    }

    /**
     * Sets the value of the billDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBillDate(XMLGregorianCalendar value) {
        this.billDate = value;
    }

    /**
     * Gets the value of the billDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBillDueDate() {
        return billDueDate;
    }

    /**
     * Sets the value of the billDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBillDueDate(XMLGregorianCalendar value) {
        this.billDueDate = value;
    }

    /**
     * Gets the value of the ineligibilityRuleList property.
     * 
     * @return
     *     possible object is
     *     {@link EligibilityRuleListType }
     *     
     */
    public EligibilityRuleListType getIneligibilityRuleList() {
        return ineligibilityRuleList;
    }

    /**
     * Sets the value of the ineligibilityRuleList property.
     * 
     * @param value
     *     allowed object is
     *     {@link EligibilityRuleListType }
     *     
     */
    public void setIneligibilityRuleList(EligibilityRuleListType value) {
        this.ineligibilityRuleList = value;
    }

}
