
package com.pge.ei.customer.mobile.ws.accountprofileretrievev1request;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.ei.customer.mobile.ws.accountprofileretrievev1request package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveAccountProfileV1RequestType_QNAME = new QName("com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Request", "retrieveAccountProfileV1RequestType");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.ei.customer.mobile.ws.accountprofileretrievev1request
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AccountProfileRetrieveV1RequestType }
     * 
     */
    public AccountProfileRetrieveV1RequestType createAccountProfileRetrieveV1RequestType() {
        return new AccountProfileRetrieveV1RequestType();
    }

    /**
     * Create an instance of {@link AccountNumberListType }
     * 
     */
    public AccountNumberListType createAccountNumberListType() {
        return new AccountNumberListType();
    }

    /**
     * Create an instance of {@link UserAccountType }
     * 
     */
    public UserAccountType createUserAccountType() {
        return new UserAccountType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountProfileRetrieveV1RequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Request", name = "retrieveAccountProfileV1RequestType")
    public JAXBElement<AccountProfileRetrieveV1RequestType> createRetrieveAccountProfileV1RequestType(AccountProfileRetrieveV1RequestType value) {
        return new JAXBElement<AccountProfileRetrieveV1RequestType>(_RetrieveAccountProfileV1RequestType_QNAME, AccountProfileRetrieveV1RequestType.class, null, value);
    }

}
