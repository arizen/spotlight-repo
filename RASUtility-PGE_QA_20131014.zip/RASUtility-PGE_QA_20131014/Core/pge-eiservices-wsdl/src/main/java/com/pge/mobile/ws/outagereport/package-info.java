@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/mobile/ws/OutageReport")
package com.pge.mobile.ws.outagereport;
