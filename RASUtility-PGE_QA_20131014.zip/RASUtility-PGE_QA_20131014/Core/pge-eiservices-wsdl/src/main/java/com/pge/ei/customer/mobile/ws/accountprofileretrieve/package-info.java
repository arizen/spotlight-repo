@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/AccountProfileRetrieve", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.ei.customer.mobile.ws.accountprofileretrieve;
