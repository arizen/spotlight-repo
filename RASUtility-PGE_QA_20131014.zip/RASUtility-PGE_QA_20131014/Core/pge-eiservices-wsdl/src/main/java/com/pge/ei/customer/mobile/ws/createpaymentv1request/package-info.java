@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Request", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.ei.customer.mobile.ws.createpaymentv1request;
