
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountBillSummaryRetrieveV1ResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountBillSummaryRetrieveV1ResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountDetailList" type="{com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Response}AccountDetailListType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountBillSummaryRetrieveV1ResponseType", propOrder = {
    "accountDetailList"
})
public class AccountBillSummaryRetrieveV1ResponseType {

    @XmlElement(required = true)
    protected AccountDetailListType accountDetailList;

    /**
     * Gets the value of the accountDetailList property.
     * 
     * @return
     *     possible object is
     *     {@link AccountDetailListType }
     *     
     */
    public AccountDetailListType getAccountDetailList() {
        return accountDetailList;
    }

    /**
     * Sets the value of the accountDetailList property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountDetailListType }
     *     
     */
    public void setAccountDetailList(AccountDetailListType value) {
        this.accountDetailList = value;
    }

}
