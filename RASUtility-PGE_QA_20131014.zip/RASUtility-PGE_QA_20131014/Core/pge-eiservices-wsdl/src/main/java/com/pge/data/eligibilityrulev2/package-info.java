@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/data/EligibilityRuleV2", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.data.eligibilityrulev2;
