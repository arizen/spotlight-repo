
package com.pge.ei.customer.mobile.ws.reportoutagev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.data.customeroutagev1.InterfaceNameType;


/**
 * <p>Java class for MessageBodyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageBodyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="messageID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element ref="{com/pge/data/CustomerOutageV1}interfaceName"/>
 *         &lt;element name="trReportNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outOutageNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="outEmergencyLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageBodyType", propOrder = {
    "messageID",
    "interfaceName",
    "trReportNumber",
    "outOutageNumber",
    "outStatus",
    "outEmergencyLevel"
})
public class MessageBodyType {

    @XmlElement(required = true)
    protected String messageID;
    @XmlElement(namespace = "com/pge/data/CustomerOutageV1", required = true)
    protected InterfaceNameType interfaceName;
    protected String trReportNumber;
    protected String outOutageNumber;
    protected String outStatus;
    protected String outEmergencyLevel;

    /**
     * Gets the value of the messageID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageID() {
        return messageID;
    }

    /**
     * Sets the value of the messageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageID(String value) {
        this.messageID = value;
    }

    /**
     * Gets the value of the interfaceName property.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceNameType }
     *     
     */
    public InterfaceNameType getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the value of the interfaceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceNameType }
     *     
     */
    public void setInterfaceName(InterfaceNameType value) {
        this.interfaceName = value;
    }

    /**
     * Gets the value of the trReportNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrReportNumber() {
        return trReportNumber;
    }

    /**
     * Sets the value of the trReportNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrReportNumber(String value) {
        this.trReportNumber = value;
    }

    /**
     * Gets the value of the outOutageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutOutageNumber() {
        return outOutageNumber;
    }

    /**
     * Sets the value of the outOutageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutOutageNumber(String value) {
        this.outOutageNumber = value;
    }

    /**
     * Gets the value of the outStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutStatus() {
        return outStatus;
    }

    /**
     * Sets the value of the outStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutStatus(String value) {
        this.outStatus = value;
    }

    /**
     * Gets the value of the outEmergencyLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutEmergencyLevel() {
        return outEmergencyLevel;
    }

    /**
     * Sets the value of the outEmergencyLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutEmergencyLevel(String value) {
        this.outEmergencyLevel = value;
    }

}
