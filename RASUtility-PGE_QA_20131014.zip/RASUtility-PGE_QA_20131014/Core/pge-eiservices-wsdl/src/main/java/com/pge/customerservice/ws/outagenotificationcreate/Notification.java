
package com.pge.customerservice.ws.outagenotificationcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="channelType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="channelValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="channelValueExt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="notifyAction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "channelType",
    "channelValue",
    "channelValueExt",
    "notifyAction"
})
@XmlRootElement(name = "notification")
public class Notification {

    @XmlElement(required = true)
    protected String channelType;
    @XmlElement(required = true)
    protected String channelValue;
    @XmlElement(defaultValue = "")
    protected String channelValueExt;
    @XmlElement(defaultValue = " ")
    protected String notifyAction;

    /**
     * Gets the value of the channelType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelType() {
        return channelType;
    }

    /**
     * Sets the value of the channelType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelType(String value) {
        this.channelType = value;
    }

    /**
     * Gets the value of the channelValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelValue() {
        return channelValue;
    }

    /**
     * Sets the value of the channelValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelValue(String value) {
        this.channelValue = value;
    }

    /**
     * Gets the value of the channelValueExt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelValueExt() {
        return channelValueExt;
    }

    /**
     * Sets the value of the channelValueExt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelValueExt(String value) {
        this.channelValueExt = value;
    }

    /**
     * Gets the value of the notifyAction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotifyAction() {
        return notifyAction;
    }

    /**
     * Sets the value of the notifyAction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotifyAction(String value) {
        this.notifyAction = value;
    }

}
