@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/customerservice/ws/OutageNotificationCreate")
package com.pge.customerservice.ws.outagenotificationcreate;
