
package com.pge.ei.customer.mobile.ws.accountprofileretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.accountprofileretrievev1request.AccountProfileRetrieveV1RequestType;


/**
 * <p>Java class for retrieveAccountProfile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveAccountProfile">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Request}retrieveAccountProfileV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveAccountProfile", propOrder = {
    "retrieveAccountProfileV1RequestType"
})
public class RetrieveAccountProfile {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Request")
    protected AccountProfileRetrieveV1RequestType retrieveAccountProfileV1RequestType;

    /**
     * Gets the value of the retrieveAccountProfileV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link AccountProfileRetrieveV1RequestType }
     *     
     */
    public AccountProfileRetrieveV1RequestType getRetrieveAccountProfileV1RequestType() {
        return retrieveAccountProfileV1RequestType;
    }

    /**
     * Sets the value of the retrieveAccountProfileV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountProfileRetrieveV1RequestType }
     *     
     */
    public void setRetrieveAccountProfileV1RequestType(AccountProfileRetrieveV1RequestType value) {
        this.retrieveAccountProfileV1RequestType = value;
    }

}
