
package com.pge.ei.customer.mobile.ws.createpaymentv1request;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.ei.customer.mobile.ws.createpaymentv1request package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreatePaymentV1RequestType_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Request", "createPaymentV1RequestType");
    private final static QName _CreatePaymentTypeNotes_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Request", "notes");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.ei.customer.mobile.ws.createpaymentv1request
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CreatePaymentV1RequestType }
     * 
     */
    public CreatePaymentV1RequestType createCreatePaymentV1RequestType() {
        return new CreatePaymentV1RequestType();
    }

    /**
     * Create an instance of {@link UserAccountType }
     * 
     */
    public UserAccountType createUserAccountType() {
        return new UserAccountType();
    }

    /**
     * Create an instance of {@link CreatePaymentType }
     * 
     */
    public CreatePaymentType createCreatePaymentType() {
        return new CreatePaymentType();
    }

    /**
     * Create an instance of {@link CreatePaymentListType }
     * 
     */
    public CreatePaymentListType createCreatePaymentListType() {
        return new CreatePaymentListType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreatePaymentV1RequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Request", name = "createPaymentV1RequestType")
    public JAXBElement<CreatePaymentV1RequestType> createCreatePaymentV1RequestType(CreatePaymentV1RequestType value) {
        return new JAXBElement<CreatePaymentV1RequestType>(_CreatePaymentV1RequestType_QNAME, CreatePaymentV1RequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Request", name = "notes", scope = CreatePaymentType.class)
    public JAXBElement<String> createCreatePaymentTypeNotes(String value) {
        return new JAXBElement<String>(_CreatePaymentTypeNotes_QNAME, String.class, CreatePaymentType.class, value);
    }

}
