
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1request.AccountBillSummaryRetrieveV1RequestType;


/**
 * <p>Java class for retrieveAccountBillSummary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveAccountBillSummary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Request}accountBillSummaryRetrieveV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveAccountBillSummary", propOrder = {
    "accountBillSummaryRetrieveV1RequestType"
})
public class RetrieveAccountBillSummary {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Request")
    protected AccountBillSummaryRetrieveV1RequestType accountBillSummaryRetrieveV1RequestType;

    /**
     * Gets the value of the accountBillSummaryRetrieveV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link AccountBillSummaryRetrieveV1RequestType }
     *     
     */
    public AccountBillSummaryRetrieveV1RequestType getAccountBillSummaryRetrieveV1RequestType() {
        return accountBillSummaryRetrieveV1RequestType;
    }

    /**
     * Sets the value of the accountBillSummaryRetrieveV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountBillSummaryRetrieveV1RequestType }
     *     
     */
    public void setAccountBillSummaryRetrieveV1RequestType(AccountBillSummaryRetrieveV1RequestType value) {
        this.accountBillSummaryRetrieveV1RequestType = value;
    }

}
