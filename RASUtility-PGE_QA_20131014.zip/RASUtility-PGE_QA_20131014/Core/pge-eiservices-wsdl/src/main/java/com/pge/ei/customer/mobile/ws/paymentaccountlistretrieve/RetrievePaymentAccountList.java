
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1request.PaymentAccountListRetrieveV1RequestType;


/**
 * <p>Java class for retrievePaymentAccountList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrievePaymentAccountList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Request}retrievePaymentAccountListV1Request" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrievePaymentAccountList", propOrder = {
    "retrievePaymentAccountListV1Request"
})
public class RetrievePaymentAccountList {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Request")
    protected PaymentAccountListRetrieveV1RequestType retrievePaymentAccountListV1Request;

    /**
     * Gets the value of the retrievePaymentAccountListV1Request property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentAccountListRetrieveV1RequestType }
     *     
     */
    public PaymentAccountListRetrieveV1RequestType getRetrievePaymentAccountListV1Request() {
        return retrievePaymentAccountListV1Request;
    }

    /**
     * Sets the value of the retrievePaymentAccountListV1Request property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentAccountListRetrieveV1RequestType }
     *     
     */
    public void setRetrievePaymentAccountListV1Request(PaymentAccountListRetrieveV1RequestType value) {
        this.retrievePaymentAccountListV1Request = value;
    }

}
