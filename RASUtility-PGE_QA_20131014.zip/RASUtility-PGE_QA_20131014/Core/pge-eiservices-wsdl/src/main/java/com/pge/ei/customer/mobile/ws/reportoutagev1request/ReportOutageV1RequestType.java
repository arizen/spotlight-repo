
package com.pge.ei.customer.mobile.ws.reportoutagev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.data.customeroutagev1.InterfaceNameType;


/**
 * <p>Java class for ReportOutageV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReportOutageV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="messageID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element ref="{com/pge/data/CustomerOutageV1}interfaceName"/>
 *         &lt;element name="function" type="{com/pge/ei/customer/mobile/ws/ReportOutageV1Request}FunctionCodeType"/>
 *         &lt;element name="cisTransformer" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cisServicePointID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cisPremiseID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cisOperationsArea" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="troubleReportID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="meterReadingRoute" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contactPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="primaryPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cause1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cause2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="statusCallback" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="restorationCallback" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="timestamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="etorPlayedFlag" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReportOutageV1RequestType", propOrder = {
    "messageID",
    "interfaceName",
    "function",
    "cisTransformer",
    "cisServicePointID",
    "cisPremiseID",
    "cisOperationsArea",
    "userID",
    "troubleReportID",
    "meterReadingRoute",
    "contactName",
    "contactPhone",
    "primaryPhone",
    "cause1",
    "cause2",
    "remarks",
    "statusCallback",
    "restorationCallback",
    "timestamp",
    "etorPlayedFlag"
})
public class ReportOutageV1RequestType {

    @XmlElement(required = true)
    protected String messageID;
    @XmlElement(namespace = "com/pge/data/CustomerOutageV1", required = true)
    protected InterfaceNameType interfaceName;
    @XmlElement(required = true)
    protected FunctionCodeType function;
    @XmlElement(required = true)
    protected String cisTransformer;
    @XmlElement(required = true)
    protected String cisServicePointID;
    @XmlElement(required = true)
    protected String cisPremiseID;
    protected String cisOperationsArea;
    @XmlElement(required = true)
    protected String userID;
    protected String troubleReportID;
    protected String meterReadingRoute;
    protected String contactName;
    protected String contactPhone;
    protected String primaryPhone;
    @XmlElement(required = true)
    protected String cause1;
    protected String cause2;
    protected String remarks;
    @XmlElement(required = true)
    protected String statusCallback;
    @XmlElement(required = true)
    protected String restorationCallback;
    protected String timestamp;
    @XmlElement(required = true)
    protected String etorPlayedFlag;

    /**
     * Gets the value of the messageID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageID() {
        return messageID;
    }

    /**
     * Sets the value of the messageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageID(String value) {
        this.messageID = value;
    }

    /**
     * Gets the value of the interfaceName property.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceNameType }
     *     
     */
    public InterfaceNameType getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the value of the interfaceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceNameType }
     *     
     */
    public void setInterfaceName(InterfaceNameType value) {
        this.interfaceName = value;
    }

    /**
     * Gets the value of the function property.
     * 
     * @return
     *     possible object is
     *     {@link FunctionCodeType }
     *     
     */
    public FunctionCodeType getFunction() {
        return function;
    }

    /**
     * Sets the value of the function property.
     * 
     * @param value
     *     allowed object is
     *     {@link FunctionCodeType }
     *     
     */
    public void setFunction(FunctionCodeType value) {
        this.function = value;
    }

    /**
     * Gets the value of the cisTransformer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisTransformer() {
        return cisTransformer;
    }

    /**
     * Sets the value of the cisTransformer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisTransformer(String value) {
        this.cisTransformer = value;
    }

    /**
     * Gets the value of the cisServicePointID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisServicePointID() {
        return cisServicePointID;
    }

    /**
     * Sets the value of the cisServicePointID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisServicePointID(String value) {
        this.cisServicePointID = value;
    }

    /**
     * Gets the value of the cisPremiseID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisPremiseID() {
        return cisPremiseID;
    }

    /**
     * Sets the value of the cisPremiseID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisPremiseID(String value) {
        this.cisPremiseID = value;
    }

    /**
     * Gets the value of the cisOperationsArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCisOperationsArea() {
        return cisOperationsArea;
    }

    /**
     * Sets the value of the cisOperationsArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCisOperationsArea(String value) {
        this.cisOperationsArea = value;
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Gets the value of the troubleReportID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTroubleReportID() {
        return troubleReportID;
    }

    /**
     * Sets the value of the troubleReportID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTroubleReportID(String value) {
        this.troubleReportID = value;
    }

    /**
     * Gets the value of the meterReadingRoute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeterReadingRoute() {
        return meterReadingRoute;
    }

    /**
     * Sets the value of the meterReadingRoute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeterReadingRoute(String value) {
        this.meterReadingRoute = value;
    }

    /**
     * Gets the value of the contactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the contactPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactPhone() {
        return contactPhone;
    }

    /**
     * Sets the value of the contactPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactPhone(String value) {
        this.contactPhone = value;
    }

    /**
     * Gets the value of the primaryPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryPhone() {
        return primaryPhone;
    }

    /**
     * Sets the value of the primaryPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryPhone(String value) {
        this.primaryPhone = value;
    }

    /**
     * Gets the value of the cause1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCause1() {
        return cause1;
    }

    /**
     * Sets the value of the cause1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCause1(String value) {
        this.cause1 = value;
    }

    /**
     * Gets the value of the cause2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCause2() {
        return cause2;
    }

    /**
     * Sets the value of the cause2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCause2(String value) {
        this.cause2 = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the statusCallback property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCallback() {
        return statusCallback;
    }

    /**
     * Sets the value of the statusCallback property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCallback(String value) {
        this.statusCallback = value;
    }

    /**
     * Gets the value of the restorationCallback property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRestorationCallback() {
        return restorationCallback;
    }

    /**
     * Sets the value of the restorationCallback property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRestorationCallback(String value) {
        this.restorationCallback = value;
    }

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestamp(String value) {
        this.timestamp = value;
    }

    /**
     * Gets the value of the etorPlayedFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEtorPlayedFlag() {
        return etorPlayedFlag;
    }

    /**
     * Sets the value of the etorPlayedFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEtorPlayedFlag(String value) {
        this.etorPlayedFlag = value;
    }

}
