
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1response.PaymentAccountListRetrieveV1ResponseType;


/**
 * <p>Java class for retrievePaymentAccountListResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrievePaymentAccountListResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Response}PaymentAccountListRetrieveV1Response" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrievePaymentAccountListResponse", propOrder = {
    "paymentAccountListRetrieveV1Response"
})
public class RetrievePaymentAccountListResponse {

    @XmlElement(name = "PaymentAccountListRetrieveV1Response", namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Response")
    protected PaymentAccountListRetrieveV1ResponseType paymentAccountListRetrieveV1Response;

    /**
     * Gets the value of the paymentAccountListRetrieveV1Response property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentAccountListRetrieveV1ResponseType }
     *     
     */
    public PaymentAccountListRetrieveV1ResponseType getPaymentAccountListRetrieveV1Response() {
        return paymentAccountListRetrieveV1Response;
    }

    /**
     * Sets the value of the paymentAccountListRetrieveV1Response property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentAccountListRetrieveV1ResponseType }
     *     
     */
    public void setPaymentAccountListRetrieveV1Response(PaymentAccountListRetrieveV1ResponseType value) {
        this.paymentAccountListRetrieveV1Response = value;
    }

}
