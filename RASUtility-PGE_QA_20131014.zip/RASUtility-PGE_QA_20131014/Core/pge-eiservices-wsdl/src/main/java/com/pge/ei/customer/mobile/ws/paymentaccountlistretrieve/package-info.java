@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieve")
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrieve;
