
package com.pge.customerservice.ws.outagenotificationcreate;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.customerservice.ws.outagenotificationcreate package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreateOutageNotification_QNAME = new QName("com/pge/customerservice/ws/OutageNotificationCreate", "createOutageNotification");
    private final static QName _CreateOutageNotificationResponse_QNAME = new QName("com/pge/customerservice/ws/OutageNotificationCreate", "createOutageNotificationResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.customerservice.ws.outagenotificationcreate
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OutageNotificationCreateV1Request }
     * 
     */
    public OutageNotificationCreateV1Request createOutageNotificationCreateV1Request() {
        return new OutageNotificationCreateV1Request();
    }

    /**
     * Create an instance of {@link Fault }
     * 
     */
    public Fault createFault() {
        return new Fault();
    }

    /**
     * Create an instance of {@link CreateOutageNotificationResponse }
     * 
     */
    public CreateOutageNotificationResponse createCreateOutageNotificationResponse() {
        return new CreateOutageNotificationResponse();
    }

    /**
     * Create an instance of {@link CreateOutageNotification }
     * 
     */
    public CreateOutageNotification createCreateOutageNotification() {
        return new CreateOutageNotification();
    }

    /**
     * Create an instance of {@link OutageNotificationCreateV1Response }
     * 
     */
    public OutageNotificationCreateV1Response createOutageNotificationCreateV1Response() {
        return new OutageNotificationCreateV1Response();
    }

    /**
     * Create an instance of {@link com.pge.customerservice.ws.outagenotificationcreate.Notification }
     * 
     */
    public com.pge.customerservice.ws.outagenotificationcreate.Notification createNotification() {
        return new com.pge.customerservice.ws.outagenotificationcreate.Notification();
    }

    /**
     * Create an instance of {@link OutageNotificationCreateV1Request.Notification }
     * 
     */
    public OutageNotificationCreateV1Request.Notification createOutageNotificationCreateV1RequestNotification() {
        return new OutageNotificationCreateV1Request.Notification();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateOutageNotification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/customerservice/ws/OutageNotificationCreate", name = "createOutageNotification")
    public JAXBElement<CreateOutageNotification> createCreateOutageNotification(CreateOutageNotification value) {
        return new JAXBElement<CreateOutageNotification>(_CreateOutageNotification_QNAME, CreateOutageNotification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateOutageNotificationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/customerservice/ws/OutageNotificationCreate", name = "createOutageNotificationResponse")
    public JAXBElement<CreateOutageNotificationResponse> createCreateOutageNotificationResponse(CreateOutageNotificationResponse value) {
        return new JAXBElement<CreateOutageNotificationResponse>(_CreateOutageNotificationResponse_QNAME, CreateOutageNotificationResponse.class, null, value);
    }

}
