@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/customerservice/ws/OutageNotificationCreateV1Request")
package com.pge.customerservice.ws.outagenotificationcreatev1request;
