
package com.pge.mobile.ws.outagereport;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.reportoutagev1request.ReportOutageV1RequestType;


/**
 * <p>Java class for reportOutage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="reportOutage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/ReportOutageV1RequestType}reportOutageV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reportOutage", propOrder = {
    "reportOutageV1RequestType"
})
public class ReportOutage {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/ReportOutageV1RequestType")
    protected ReportOutageV1RequestType reportOutageV1RequestType;

    /**
     * Gets the value of the reportOutageV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link ReportOutageV1RequestType }
     *     
     */
    public ReportOutageV1RequestType getReportOutageV1RequestType() {
        return reportOutageV1RequestType;
    }

    /**
     * Sets the value of the reportOutageV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReportOutageV1RequestType }
     *     
     */
    public void setReportOutageV1RequestType(ReportOutageV1RequestType value) {
        this.reportOutageV1RequestType = value;
    }

}
