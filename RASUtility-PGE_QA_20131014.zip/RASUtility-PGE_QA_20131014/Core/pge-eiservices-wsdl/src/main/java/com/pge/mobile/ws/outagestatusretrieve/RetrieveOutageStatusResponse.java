
package com.pge.mobile.ws.outagestatusretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.retrieveoutagestatusv1response.RetrieveOutageStatusV1ResponseType;


/**
 * <p>Java class for retrieveOutageStatusResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveOutageStatusResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/RetrieveOutageStatusV1Response}retrieveOutageStatusV1ResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveOutageStatusResponse", propOrder = {
    "retrieveOutageStatusV1ResponseType"
})
public class RetrieveOutageStatusResponse {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/RetrieveOutageStatusV1Response")
    protected RetrieveOutageStatusV1ResponseType retrieveOutageStatusV1ResponseType;

    /**
     * Gets the value of the retrieveOutageStatusV1ResponseType property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveOutageStatusV1ResponseType }
     *     
     */
    public RetrieveOutageStatusV1ResponseType getRetrieveOutageStatusV1ResponseType() {
        return retrieveOutageStatusV1ResponseType;
    }

    /**
     * Sets the value of the retrieveOutageStatusV1ResponseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveOutageStatusV1ResponseType }
     *     
     */
    public void setRetrieveOutageStatusV1ResponseType(RetrieveOutageStatusV1ResponseType value) {
        this.retrieveOutageStatusV1ResponseType = value;
    }

}
