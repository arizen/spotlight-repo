
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1response;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentAccountType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PaymentAccountType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="None"/>
 *     &lt;enumeration value="Recurring"/>
 *     &lt;enumeration value="SMS"/>
 *     &lt;enumeration value="SMS_Recurring"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PaymentAccountType")
@XmlEnum
public enum PaymentAccountType {

    @XmlEnumValue("None")
    NONE("None"),
    @XmlEnumValue("Recurring")
    RECURRING("Recurring"),
    SMS("SMS"),
    @XmlEnumValue("SMS_Recurring")
    SMS_RECURRING("SMS_Recurring");
    private final String value;

    PaymentAccountType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PaymentAccountType fromValue(String v) {
        for (PaymentAccountType c: PaymentAccountType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
