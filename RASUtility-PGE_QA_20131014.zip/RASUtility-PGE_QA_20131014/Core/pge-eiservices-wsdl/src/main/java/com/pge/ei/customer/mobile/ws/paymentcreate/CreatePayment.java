
package com.pge.ei.customer.mobile.ws.paymentcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.createpaymentv1request.CreatePaymentV1RequestType;


/**
 * <p>Java class for createPayment complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createPayment">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/CreatePaymentV1Request}createPaymentV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createPayment", propOrder = {
    "createPaymentV1RequestType"
})
public class CreatePayment {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Request")
    protected CreatePaymentV1RequestType createPaymentV1RequestType;

    /**
     * Gets the value of the createPaymentV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link CreatePaymentV1RequestType }
     *     
     */
    public CreatePaymentV1RequestType getCreatePaymentV1RequestType() {
        return createPaymentV1RequestType;
    }

    /**
     * Sets the value of the createPaymentV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreatePaymentV1RequestType }
     *     
     */
    public void setCreatePaymentV1RequestType(CreatePaymentV1RequestType value) {
        this.createPaymentV1RequestType = value;
    }

}
