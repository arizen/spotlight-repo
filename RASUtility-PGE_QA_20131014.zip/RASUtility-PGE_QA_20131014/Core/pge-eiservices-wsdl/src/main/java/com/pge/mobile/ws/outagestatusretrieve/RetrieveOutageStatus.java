
package com.pge.mobile.ws.outagestatusretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.retrieveoutagestatusv1request.RetrieveOutageStatusV1RequestType;


/**
 * <p>Java class for retrieveOutageStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveOutageStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/RetrieveOutageStatusV1RequestType}retrieveOutageStatusV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveOutageStatus", propOrder = {
    "retrieveOutageStatusV1RequestType"
})
public class RetrieveOutageStatus {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/RetrieveOutageStatusV1RequestType")
    protected RetrieveOutageStatusV1RequestType retrieveOutageStatusV1RequestType;

    /**
     * Gets the value of the retrieveOutageStatusV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveOutageStatusV1RequestType }
     *     
     */
    public RetrieveOutageStatusV1RequestType getRetrieveOutageStatusV1RequestType() {
        return retrieveOutageStatusV1RequestType;
    }

    /**
     * Sets the value of the retrieveOutageStatusV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveOutageStatusV1RequestType }
     *     
     */
    public void setRetrieveOutageStatusV1RequestType(RetrieveOutageStatusV1RequestType value) {
        this.retrieveOutageStatusV1RequestType = value;
    }

}
