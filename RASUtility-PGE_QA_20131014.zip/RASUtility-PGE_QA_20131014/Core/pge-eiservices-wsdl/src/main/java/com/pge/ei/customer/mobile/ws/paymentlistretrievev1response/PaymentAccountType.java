
package com.pge.ei.customer.mobile.ws.paymentlistretrievev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentAccountType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentAccountType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fundingId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="fundingAcct" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fundingType" type="{com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Response}FundingAccountType"/>
 *         &lt;element name="nickName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentAccountType", propOrder = {
    "fundingId",
    "fundingAcct",
    "fundingType",
    "nickName"
})
public class PaymentAccountType {

    protected int fundingId;
    @XmlElement(required = true, nillable = true)
    protected String fundingAcct;
    @XmlElement(required = true)
    protected FundingAccountType fundingType;
    @XmlElement(required = true, nillable = true)
    protected String nickName;

    /**
     * Gets the value of the fundingId property.
     * 
     */
    public int getFundingId() {
        return fundingId;
    }

    /**
     * Sets the value of the fundingId property.
     * 
     */
    public void setFundingId(int value) {
        this.fundingId = value;
    }

    /**
     * Gets the value of the fundingAcct property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundingAcct() {
        return fundingAcct;
    }

    /**
     * Sets the value of the fundingAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundingAcct(String value) {
        this.fundingAcct = value;
    }

    /**
     * Gets the value of the fundingType property.
     * 
     * @return
     *     possible object is
     *     {@link FundingAccountType }
     *     
     */
    public FundingAccountType getFundingType() {
        return fundingType;
    }

    /**
     * Sets the value of the fundingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link FundingAccountType }
     *     
     */
    public void setFundingType(FundingAccountType value) {
        this.fundingType = value;
    }

    /**
     * Gets the value of the nickName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * Sets the value of the nickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNickName(String value) {
        this.nickName = value;
    }

}
