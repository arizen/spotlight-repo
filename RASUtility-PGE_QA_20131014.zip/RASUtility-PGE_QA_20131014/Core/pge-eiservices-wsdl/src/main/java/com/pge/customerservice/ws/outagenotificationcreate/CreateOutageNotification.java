
package com.pge.customerservice.ws.outagenotificationcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.customerservice.ws.outagenotificationcreatev1request.OutageNotificationCreateV1Request;


/**
 * <p>Java class for createOutageNotification complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createOutageNotification">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/customerservice/ws/OutageNotificationCreateV1Request}OutageNotificationCreateV1Request" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createOutageNotification", propOrder = {
    "outageNotificationCreateV1Request"
})
public class CreateOutageNotification {

    @XmlElement(name = "OutageNotificationCreateV1Request", namespace = "com/pge/customerservice/ws/OutageNotificationCreateV1Request")
    protected OutageNotificationCreateV1Request outageNotificationCreateV1Request;

    /**
     * Gets the value of the outageNotificationCreateV1Request property.
     * 
     * @return
     *     possible object is
     *     {@link OutageNotificationCreateV1Request }
     *     
     */
    public OutageNotificationCreateV1Request getOutageNotificationCreateV1Request() {
        return outageNotificationCreateV1Request;
    }

    /**
     * Sets the value of the outageNotificationCreateV1Request property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutageNotificationCreateV1Request }
     *     
     */
    public void setOutageNotificationCreateV1Request(OutageNotificationCreateV1Request value) {
        this.outageNotificationCreateV1Request = value;
    }

}
