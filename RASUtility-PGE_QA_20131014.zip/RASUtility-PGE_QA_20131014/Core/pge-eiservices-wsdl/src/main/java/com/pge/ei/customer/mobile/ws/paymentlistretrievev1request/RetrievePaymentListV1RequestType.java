
package com.pge.ei.customer.mobile.ws.paymentlistretrievev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RetrievePaymentListV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RetrievePaymentListV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userAccount" type="{com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Request}UserAccountType"/>
 *         &lt;element name="retrievePayment" type="{com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Request}RetrievePaymentListType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrievePaymentListV1RequestType", propOrder = {
    "userAccount",
    "retrievePayment"
})
public class RetrievePaymentListV1RequestType {

    @XmlElement(required = true)
    protected UserAccountType userAccount;
    protected RetrievePaymentListType retrievePayment;

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountType }
     *     
     */
    public UserAccountType getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountType }
     *     
     */
    public void setUserAccount(UserAccountType value) {
        this.userAccount = value;
    }

    /**
     * Gets the value of the retrievePayment property.
     * 
     * @return
     *     possible object is
     *     {@link RetrievePaymentListType }
     *     
     */
    public RetrievePaymentListType getRetrievePayment() {
        return retrievePayment;
    }

    /**
     * Sets the value of the retrievePayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrievePaymentListType }
     *     
     */
    public void setRetrievePayment(RetrievePaymentListType value) {
        this.retrievePayment = value;
    }

}
