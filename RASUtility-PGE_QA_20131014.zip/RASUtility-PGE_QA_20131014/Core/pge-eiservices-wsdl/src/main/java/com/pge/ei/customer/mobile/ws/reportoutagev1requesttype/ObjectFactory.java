
package com.pge.ei.customer.mobile.ws.reportoutagev1requesttype;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.pge.ei.customer.mobile.ws.reportoutagev1request.ReportOutageV1RequestType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.ei.customer.mobile.ws.reportoutagev1requesttype package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ReportOutageV1RequestType_QNAME = new QName("com/pge/ei/customer/mobile/ws/ReportOutageV1RequestType", "reportOutageV1RequestType");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.ei.customer.mobile.ws.reportoutagev1requesttype
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReportOutageV1RequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/ReportOutageV1RequestType", name = "reportOutageV1RequestType")
    public JAXBElement<ReportOutageV1RequestType> createReportOutageV1RequestType(ReportOutageV1RequestType value) {
        return new JAXBElement<ReportOutageV1RequestType>(_ReportOutageV1RequestType_QNAME, ReportOutageV1RequestType.class, null, value);
    }

}
