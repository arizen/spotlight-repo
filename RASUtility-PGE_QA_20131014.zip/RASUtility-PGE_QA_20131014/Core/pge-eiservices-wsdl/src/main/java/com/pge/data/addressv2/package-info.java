@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/data/AddressV2", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.data.addressv2;
