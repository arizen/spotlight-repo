
package com.pge.ei.customer.mobile.ws.paymentlistretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.paymentlistretrievev1request.RetrievePaymentListV1RequestType;


/**
 * <p>Java class for retrievePaymentList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrievePaymentList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Request}retrievePaymentListV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrievePaymentList", propOrder = {
    "retrievePaymentListV1RequestType"
})
public class RetrievePaymentList {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Request")
    protected RetrievePaymentListV1RequestType retrievePaymentListV1RequestType;

    /**
     * Gets the value of the retrievePaymentListV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link RetrievePaymentListV1RequestType }
     *     
     */
    public RetrievePaymentListV1RequestType getRetrievePaymentListV1RequestType() {
        return retrievePaymentListV1RequestType;
    }

    /**
     * Sets the value of the retrievePaymentListV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrievePaymentListV1RequestType }
     *     
     */
    public void setRetrievePaymentListV1RequestType(RetrievePaymentListV1RequestType value) {
        this.retrievePaymentListV1RequestType = value;
    }

}
