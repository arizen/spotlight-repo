
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.data.addressv2.AddressType;


/**
 * <p>Java class for AccountDetailType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountDetailType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/data/CustomerAccountV1}accountID"/>
 *         &lt;element name="accountType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accountBillSummaryType" type="{com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Response}AccountBillSummaryType"/>
 *         &lt;element name="accountAddress" type="{com/pge/data/AddressV2}AddressType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountDetailType", propOrder = {
    "accountID",
    "accountType",
    "accountBillSummaryType",
    "accountAddress"
})
public class AccountDetailType {

    @XmlElement(namespace = "com/pge/data/CustomerAccountV1", required = true)
    protected String accountID;
    @XmlElement(required = true)
    protected String accountType;
    @XmlElement(required = true)
    protected AccountBillSummaryType accountBillSummaryType;
    @XmlElement(required = true)
    protected AddressType accountAddress;

    /**
     * Gets the value of the accountID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountID() {
        return accountID;
    }

    /**
     * Sets the value of the accountID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountID(String value) {
        this.accountID = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Sets the value of the accountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountType(String value) {
        this.accountType = value;
    }

    /**
     * Gets the value of the accountBillSummaryType property.
     * 
     * @return
     *     possible object is
     *     {@link AccountBillSummaryType }
     *     
     */
    public AccountBillSummaryType getAccountBillSummaryType() {
        return accountBillSummaryType;
    }

    /**
     * Sets the value of the accountBillSummaryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountBillSummaryType }
     *     
     */
    public void setAccountBillSummaryType(AccountBillSummaryType value) {
        this.accountBillSummaryType = value;
    }

    /**
     * Gets the value of the accountAddress property.
     * 
     * @return
     *     possible object is
     *     {@link AddressType }
     *     
     */
    public AddressType getAccountAddress() {
        return accountAddress;
    }

    /**
     * Sets the value of the accountAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressType }
     *     
     */
    public void setAccountAddress(AddressType value) {
        this.accountAddress = value;
    }

}
