@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/mobile/ws/OutageStatusRetrieve")
package com.pge.mobile.ws.outagestatusretrieve;
