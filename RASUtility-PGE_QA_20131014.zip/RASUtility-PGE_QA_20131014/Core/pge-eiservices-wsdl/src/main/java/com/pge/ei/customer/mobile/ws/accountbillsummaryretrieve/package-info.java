@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieve")
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrieve;
