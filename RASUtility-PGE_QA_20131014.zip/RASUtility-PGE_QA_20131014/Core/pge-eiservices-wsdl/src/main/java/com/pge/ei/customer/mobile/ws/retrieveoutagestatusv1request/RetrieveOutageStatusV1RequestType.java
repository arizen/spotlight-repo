
package com.pge.ei.customer.mobile.ws.retrieveoutagestatusv1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.data.customeroutagev1.InterfaceNameType;


/**
 * <p>Java class for RetrieveOutageStatusV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RetrieveOutageStatusV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="messageID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element ref="{com/pge/data/CustomerOutageV1}interfaceName"/>
 *         &lt;element name="PremisesID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrieveOutageStatusV1RequestType", propOrder = {
    "messageID",
    "interfaceName",
    "premisesID",
    "userID"
})
public class RetrieveOutageStatusV1RequestType {

    @XmlElement(required = true)
    protected String messageID;
    @XmlElement(namespace = "com/pge/data/CustomerOutageV1", required = true)
    protected InterfaceNameType interfaceName;
    @XmlElement(name = "PremisesID", required = true)
    protected String premisesID;
    @XmlElement(required = true)
    protected String userID;

    /**
     * Gets the value of the messageID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageID() {
        return messageID;
    }

    /**
     * Sets the value of the messageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageID(String value) {
        this.messageID = value;
    }

    /**
     * Gets the value of the interfaceName property.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceNameType }
     *     
     */
    public InterfaceNameType getInterfaceName() {
        return interfaceName;
    }

    /**
     * Sets the value of the interfaceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceNameType }
     *     
     */
    public void setInterfaceName(InterfaceNameType value) {
        this.interfaceName = value;
    }

    /**
     * Gets the value of the premisesID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremisesID() {
        return premisesID;
    }

    /**
     * Sets the value of the premisesID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremisesID(String value) {
        this.premisesID = value;
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

}
