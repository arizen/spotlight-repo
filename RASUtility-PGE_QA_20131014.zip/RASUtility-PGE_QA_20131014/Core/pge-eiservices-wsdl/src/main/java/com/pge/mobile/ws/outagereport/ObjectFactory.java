
package com.pge.mobile.ws.outagereport;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.mobile.ws.outagereport package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ReportOutage_QNAME = new QName("com/pge/mobile/ws/OutageReport", "reportOutage");
    private final static QName _ReportOutageResponse_QNAME = new QName("com/pge/mobile/ws/OutageReport", "reportOutageResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.mobile.ws.outagereport
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ReportOutageResponse }
     * 
     */
    public ReportOutageResponse createReportOutageResponse() {
        return new ReportOutageResponse();
    }

    /**
     * Create an instance of {@link ReportOutage }
     * 
     */
    public ReportOutage createReportOutage() {
        return new ReportOutage();
    }

    /**
     * Create an instance of {@link Fault }
     * 
     */
    public Fault createFault() {
        return new Fault();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReportOutage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/mobile/ws/OutageReport", name = "reportOutage")
    public JAXBElement<ReportOutage> createReportOutage(ReportOutage value) {
        return new JAXBElement<ReportOutage>(_ReportOutage_QNAME, ReportOutage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReportOutageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/mobile/ws/OutageReport", name = "reportOutageResponse")
    public JAXBElement<ReportOutageResponse> createReportOutageResponse(ReportOutageResponse value) {
        return new JAXBElement<ReportOutageResponse>(_ReportOutageResponse_QNAME, ReportOutageResponse.class, null, value);
    }

}
