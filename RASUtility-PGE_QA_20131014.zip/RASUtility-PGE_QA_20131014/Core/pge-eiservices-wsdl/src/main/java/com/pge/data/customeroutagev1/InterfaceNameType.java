
package com.pge.data.customeroutagev1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InterfaceNameType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="InterfaceNameType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SUBOUTAGE"/>
 *     &lt;enumeration value="RPTOUTAGE"/>
 *     &lt;enumeration value="RTVOUTAGE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "InterfaceNameType", namespace = "com/pge/data/CustomerOutageV1")
@XmlEnum
public enum InterfaceNameType {

    SUBOUTAGE,
    RPTOUTAGE,
    RTVOUTAGE;

    public String value() {
        return name();
    }

    public static InterfaceNameType fromValue(String v) {
        return valueOf(v);
    }

}
