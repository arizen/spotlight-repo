
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentAccountListRetrieveV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentAccountListRetrieveV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userAccount" type="{com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Request}UserAccountType"/>
 *         &lt;element name="auditLogRetrieval" type="{com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Request}AuditLogRetrievalType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentAccountListRetrieveV1RequestType", propOrder = {
    "userAccount",
    "auditLogRetrieval"
})
public class PaymentAccountListRetrieveV1RequestType {

    @XmlElement(required = true)
    protected UserAccountType userAccount;
    @XmlElement(required = true)
    protected AuditLogRetrievalType auditLogRetrieval;

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountType }
     *     
     */
    public UserAccountType getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountType }
     *     
     */
    public void setUserAccount(UserAccountType value) {
        this.userAccount = value;
    }

    /**
     * Gets the value of the auditLogRetrieval property.
     * 
     * @return
     *     possible object is
     *     {@link AuditLogRetrievalType }
     *     
     */
    public AuditLogRetrievalType getAuditLogRetrieval() {
        return auditLogRetrieval;
    }

    /**
     * Sets the value of the auditLogRetrieval property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuditLogRetrievalType }
     *     
     */
    public void setAuditLogRetrieval(AuditLogRetrievalType value) {
        this.auditLogRetrieval = value;
    }

}
