@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/PaymentListRetrieve")
package com.pge.ei.customer.mobile.ws.paymentlistretrieve;
