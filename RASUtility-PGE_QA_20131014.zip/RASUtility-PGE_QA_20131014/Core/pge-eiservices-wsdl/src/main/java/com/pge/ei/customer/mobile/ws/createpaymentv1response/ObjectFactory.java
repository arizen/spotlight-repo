
package com.pge.ei.customer.mobile.ws.createpaymentv1response;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.ei.customer.mobile.ws.createpaymentv1response package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Comment_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "comment");
    private final static QName _CreatePaymentV1Response_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "createPaymentV1Response");
    private final static QName _PaymentState_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "paymentState");
    private final static QName _AccountNumber_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "accountNumber");
    private final static QName _PaymentId_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "paymentId");
    private final static QName _CreatePaymentV1ResponseType_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "CreatePaymentV1ResponseType");
    private final static QName _ConfirmationNumber_QNAME = new QName("com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", "confirmationNumber");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.ei.customer.mobile.ws.createpaymentv1response
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CreatePaymentV1ResponseType }
     * 
     */
    public CreatePaymentV1ResponseType createCreatePaymentV1ResponseType() {
        return new CreatePaymentV1ResponseType();
    }

    /**
     * Create an instance of {@link PaymentConfirmationType }
     * 
     */
    public PaymentConfirmationType createPaymentConfirmationType() {
        return new PaymentConfirmationType();
    }

    /**
     * Create an instance of {@link PaymentConfirmationListType }
     * 
     */
    public PaymentConfirmationListType createPaymentConfirmationListType() {
        return new PaymentConfirmationListType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "comment")
    public JAXBElement<String> createComment(String value) {
        return new JAXBElement<String>(_Comment_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreatePaymentV1ResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "createPaymentV1Response")
    public JAXBElement<CreatePaymentV1ResponseType> createCreatePaymentV1Response(CreatePaymentV1ResponseType value) {
        return new JAXBElement<CreatePaymentV1ResponseType>(_CreatePaymentV1Response_QNAME, CreatePaymentV1ResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PaymentStateType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "paymentState")
    public JAXBElement<PaymentStateType> createPaymentState(PaymentStateType value) {
        return new JAXBElement<PaymentStateType>(_PaymentState_QNAME, PaymentStateType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "accountNumber")
    public JAXBElement<String> createAccountNumber(String value) {
        return new JAXBElement<String>(_AccountNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "paymentId")
    public JAXBElement<String> createPaymentId(String value) {
        return new JAXBElement<String>(_PaymentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreatePaymentV1ResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "CreatePaymentV1ResponseType")
    public JAXBElement<CreatePaymentV1ResponseType> createCreatePaymentV1ResponseType(CreatePaymentV1ResponseType value) {
        return new JAXBElement<CreatePaymentV1ResponseType>(_CreatePaymentV1ResponseType_QNAME, CreatePaymentV1ResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "confirmationNumber")
    public JAXBElement<String> createConfirmationNumber(String value) {
        return new JAXBElement<String>(_ConfirmationNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response", name = "comment", scope = PaymentConfirmationType.class)
    public JAXBElement<String> createPaymentConfirmationTypeComment(String value) {
        return new JAXBElement<String>(_Comment_QNAME, String.class, PaymentConfirmationType.class, value);
    }

}
