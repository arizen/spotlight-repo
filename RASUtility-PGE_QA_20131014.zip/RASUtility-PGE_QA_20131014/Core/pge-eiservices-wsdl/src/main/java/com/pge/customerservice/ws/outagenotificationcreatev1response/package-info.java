@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/customerservice/ws/OutageNotificationCreateV1Response")
package com.pge.customerservice.ws.outagenotificationcreatev1response;
