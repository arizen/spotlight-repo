
package com.pge.ei.customer.mobile.ws.accountprofileretrieve;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.ei.customer.mobile.ws.accountprofileretrieve package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveAccountProfileResponse_QNAME = new QName("com/pge/ei/customer/mobile/ws/AccountProfileRetrieve", "retrieveAccountProfileResponse");
    private final static QName _RetrieveAccountProfile_QNAME = new QName("com/pge/ei/customer/mobile/ws/AccountProfileRetrieve", "retrieveAccountProfile");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.ei.customer.mobile.ws.accountprofileretrieve
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RetrieveAccountProfileResponse }
     * 
     */
    public RetrieveAccountProfileResponse createRetrieveAccountProfileResponse() {
        return new RetrieveAccountProfileResponse();
    }

    /**
     * Create an instance of {@link RetrieveAccountProfile }
     * 
     */
    public RetrieveAccountProfile createRetrieveAccountProfile() {
        return new RetrieveAccountProfile();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveAccountProfileResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/AccountProfileRetrieve", name = "retrieveAccountProfileResponse")
    public JAXBElement<RetrieveAccountProfileResponse> createRetrieveAccountProfileResponse(RetrieveAccountProfileResponse value) {
        return new JAXBElement<RetrieveAccountProfileResponse>(_RetrieveAccountProfileResponse_QNAME, RetrieveAccountProfileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveAccountProfile }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/AccountProfileRetrieve", name = "retrieveAccountProfile")
    public JAXBElement<RetrieveAccountProfile> createRetrieveAccountProfile(RetrieveAccountProfile value) {
        return new JAXBElement<RetrieveAccountProfile>(_RetrieveAccountProfile_QNAME, RetrieveAccountProfile.class, null, value);
    }

}
