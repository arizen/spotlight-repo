
package com.pge.ei.customer.mobile.ws.paymentcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.createpaymentv1response.CreatePaymentV1ResponseType;


/**
 * <p>Java class for createPaymentResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createPaymentResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/CreatePaymentV1Response}CreatePaymentV1ResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createPaymentResponse", propOrder = {
    "createPaymentV1ResponseType"
})
public class CreatePaymentResponse {

    @XmlElement(name = "CreatePaymentV1ResponseType", namespace = "com/pge/ei/customer/mobile/ws/CreatePaymentV1Response")
    protected CreatePaymentV1ResponseType createPaymentV1ResponseType;

    /**
     * Gets the value of the createPaymentV1ResponseType property.
     * 
     * @return
     *     possible object is
     *     {@link CreatePaymentV1ResponseType }
     *     
     */
    public CreatePaymentV1ResponseType getCreatePaymentV1ResponseType() {
        return createPaymentV1ResponseType;
    }

    /**
     * Sets the value of the createPaymentV1ResponseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreatePaymentV1ResponseType }
     *     
     */
    public void setCreatePaymentV1ResponseType(CreatePaymentV1ResponseType value) {
        this.createPaymentV1ResponseType = value;
    }

}
