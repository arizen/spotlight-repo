@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountListRetrieveV1Request", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.ei.customer.mobile.ws.paymentaccountlistretrievev1request;
