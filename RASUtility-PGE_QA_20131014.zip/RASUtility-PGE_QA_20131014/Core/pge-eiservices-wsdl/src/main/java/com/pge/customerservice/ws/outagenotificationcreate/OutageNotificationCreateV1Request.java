
package com.pge.customerservice.ws.outagenotificationcreate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="outageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="outageNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="servicePointID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="letterID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="serviceAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="statusCallback" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="restorationCallback" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="notification" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="channelType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="channelValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="channelValueExt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="notifyAction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="notifyAfterHours" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="notifyFutureOutages" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "outageType",
    "outageNumber",
    "servicePointID",
    "letterID",
    "serviceAddress",
    "city",
    "statusCallback",
    "restorationCallback",
    "notification",
    "notifyAfterHours",
    "notifyFutureOutages"
})
@XmlRootElement(name = "OutageNotificationCreateV1Request")
public class OutageNotificationCreateV1Request {

    @XmlElement(required = true, defaultValue = "")
    protected String outageType;
    @XmlElement(defaultValue = "")
    protected String outageNumber;
    @XmlElement(defaultValue = "")
    protected String servicePointID;
    @XmlElement(defaultValue = "")
    protected String letterID;
    @XmlElement(defaultValue = "")
    protected String serviceAddress;
    @XmlElement(defaultValue = "")
    protected String city;
    @XmlElement(defaultValue = "false")
    protected Boolean statusCallback;
    @XmlElement(defaultValue = "false")
    protected Boolean restorationCallback;
    @XmlElement(required = true)
    protected List<OutageNotificationCreateV1Request.Notification> notification;
    @XmlElement(defaultValue = "false")
    protected Boolean notifyAfterHours;
    @XmlElement(defaultValue = "false")
    protected Boolean notifyFutureOutages;

    /**
     * Gets the value of the outageType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutageType() {
        return outageType;
    }

    /**
     * Sets the value of the outageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutageType(String value) {
        this.outageType = value;
    }

    /**
     * Gets the value of the outageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutageNumber() {
        return outageNumber;
    }

    /**
     * Sets the value of the outageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutageNumber(String value) {
        this.outageNumber = value;
    }

    /**
     * Gets the value of the servicePointID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicePointID() {
        return servicePointID;
    }

    /**
     * Sets the value of the servicePointID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicePointID(String value) {
        this.servicePointID = value;
    }

    /**
     * Gets the value of the letterID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLetterID() {
        return letterID;
    }

    /**
     * Sets the value of the letterID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLetterID(String value) {
        this.letterID = value;
    }

    /**
     * Gets the value of the serviceAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceAddress() {
        return serviceAddress;
    }

    /**
     * Sets the value of the serviceAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceAddress(String value) {
        this.serviceAddress = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the statusCallback property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStatusCallback() {
        return statusCallback;
    }

    /**
     * Sets the value of the statusCallback property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStatusCallback(Boolean value) {
        this.statusCallback = value;
    }

    /**
     * Gets the value of the restorationCallback property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRestorationCallback() {
        return restorationCallback;
    }

    /**
     * Sets the value of the restorationCallback property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRestorationCallback(Boolean value) {
        this.restorationCallback = value;
    }

    /**
     * Gets the value of the notification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the notification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNotification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OutageNotificationCreateV1Request.Notification }
     * 
     * 
     */
    public List<OutageNotificationCreateV1Request.Notification> getNotification() {
        if (notification == null) {
            notification = new ArrayList<OutageNotificationCreateV1Request.Notification>();
        }
        return this.notification;
    }

    /**
     * Gets the value of the notifyAfterHours property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNotifyAfterHours() {
        return notifyAfterHours;
    }

    /**
     * Sets the value of the notifyAfterHours property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNotifyAfterHours(Boolean value) {
        this.notifyAfterHours = value;
    }

    /**
     * Gets the value of the notifyFutureOutages property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNotifyFutureOutages() {
        return notifyFutureOutages;
    }

    /**
     * Sets the value of the notifyFutureOutages property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNotifyFutureOutages(Boolean value) {
        this.notifyFutureOutages = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="channelType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="channelValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="channelValueExt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="notifyAction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "channelType",
        "channelValue",
        "channelValueExt",
        "notifyAction"
    })
    public static class Notification {

        @XmlElement(required = true)
        protected String channelType;
        @XmlElement(required = true)
        protected String channelValue;
        @XmlElement(defaultValue = "")
        protected String channelValueExt;
        @XmlElement(defaultValue = " ")
        protected String notifyAction;

        /**
         * Gets the value of the channelType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getChannelType() {
            return channelType;
        }

        /**
         * Sets the value of the channelType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setChannelType(String value) {
            this.channelType = value;
        }

        /**
         * Gets the value of the channelValue property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getChannelValue() {
            return channelValue;
        }

        /**
         * Sets the value of the channelValue property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setChannelValue(String value) {
            this.channelValue = value;
        }

        /**
         * Gets the value of the channelValueExt property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getChannelValueExt() {
            return channelValueExt;
        }

        /**
         * Sets the value of the channelValueExt property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setChannelValueExt(String value) {
            this.channelValueExt = value;
        }

        /**
         * Gets the value of the notifyAction property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNotifyAction() {
            return notifyAction;
        }

        /**
         * Sets the value of the notifyAction property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNotifyAction(String value) {
            this.notifyAction = value;
        }

    }

}
