
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1response;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.pge.data.financialtransactionv2.TransactionTypeType;


/**
 * <p>Java class for FinancialTransactionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialTransactionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/data/FinancialTransactionV2}transactionType"/>
 *         &lt;element ref="{com/pge/data/FinancialTransactionV2}transactionDate" minOccurs="0"/>
 *         &lt;element ref="{com/pge/data/FinancialInformationV1}currentAmount" minOccurs="0"/>
 *         &lt;element ref="{com/pge/data/FinancialInformationV1}pastDueAmount" minOccurs="0"/>
 *         &lt;element ref="{com/pge/data/FinancialInformationV1}totalAmount"/>
 *         &lt;element ref="{com/pge/data/FinancialTransactionV2}note" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialTransactionType", propOrder = {
    "transactionType",
    "transactionDate",
    "currentAmount",
    "pastDueAmount",
    "totalAmount",
    "note"
})
public class FinancialTransactionType {

    @XmlElement(namespace = "com/pge/data/FinancialTransactionV2", required = true)
    protected TransactionTypeType transactionType;
    @XmlElement(namespace = "com/pge/data/FinancialTransactionV2")
    @XmlSchemaType(name = "anySimpleType")
    protected Object transactionDate;
    @XmlElement(namespace = "com/pge/data/FinancialInformationV1")
    protected BigDecimal currentAmount;
    @XmlElement(namespace = "com/pge/data/FinancialInformationV1")
    protected BigDecimal pastDueAmount;
    @XmlElement(namespace = "com/pge/data/FinancialInformationV1", required = true)
    protected BigDecimal totalAmount;
    @XmlElement(namespace = "com/pge/data/FinancialTransactionV2")
    protected String note;

    /**
     * Gets the value of the transactionType property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionTypeType }
     *     
     */
    public TransactionTypeType getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionTypeType }
     *     
     */
    public void setTransactionType(TransactionTypeType value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the transactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the value of the transactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setTransactionDate(Object value) {
        this.transactionDate = value;
    }

    /**
     * Gets the value of the currentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCurrentAmount() {
        return currentAmount;
    }

    /**
     * Sets the value of the currentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentAmount(BigDecimal value) {
        this.currentAmount = value;
    }

    /**
     * Gets the value of the pastDueAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPastDueAmount() {
        return pastDueAmount;
    }

    /**
     * Sets the value of the pastDueAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPastDueAmount(BigDecimal value) {
        this.pastDueAmount = value;
    }

    /**
     * Gets the value of the totalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    /**
     * Sets the value of the totalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAmount(BigDecimal value) {
        this.totalAmount = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNote(String value) {
        this.note = value;
    }

}
