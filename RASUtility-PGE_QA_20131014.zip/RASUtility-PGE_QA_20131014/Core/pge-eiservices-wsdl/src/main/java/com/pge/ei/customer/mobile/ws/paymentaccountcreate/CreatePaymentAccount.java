
package com.pge.ei.customer.mobile.ws.paymentaccountcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.paymentaccountcreatev1request.CreatePaymentAccountV1RequestType;


/**
 * <p>Java class for createPaymentAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createPaymentAccount">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/PaymentAccountCreateV1Request}createPaymentAccountV1RequestType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createPaymentAccount", propOrder = {
    "createPaymentAccountV1RequestType"
})
public class CreatePaymentAccount {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountCreateV1Request")
    protected CreatePaymentAccountV1RequestType createPaymentAccountV1RequestType;

    /**
     * Gets the value of the createPaymentAccountV1RequestType property.
     * 
     * @return
     *     possible object is
     *     {@link CreatePaymentAccountV1RequestType }
     *     
     */
    public CreatePaymentAccountV1RequestType getCreatePaymentAccountV1RequestType() {
        return createPaymentAccountV1RequestType;
    }

    /**
     * Sets the value of the createPaymentAccountV1RequestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreatePaymentAccountV1RequestType }
     *     
     */
    public void setCreatePaymentAccountV1RequestType(CreatePaymentAccountV1RequestType value) {
        this.createPaymentAccountV1RequestType = value;
    }

}
