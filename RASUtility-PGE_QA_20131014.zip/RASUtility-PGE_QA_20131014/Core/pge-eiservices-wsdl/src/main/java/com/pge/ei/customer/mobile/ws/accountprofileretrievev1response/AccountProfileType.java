
package com.pge.ei.customer.mobile.ws.accountprofileretrievev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for AccountProfileType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountProfileType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="paymentActivityList" type="{com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Response}PaymentActivityListType" minOccurs="0"/>
 *         &lt;element name="currentStatementID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentStatementDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountProfileType", propOrder = {
    "accountNumber",
    "paymentActivityList",
    "currentStatementID",
    "currentStatementDate"
})
public class AccountProfileType {

    @XmlElement(required = true)
    protected String accountNumber;
    protected PaymentActivityListType paymentActivityList;
    @XmlElement(required = true)
    protected String currentStatementID;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar currentStatementDate;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the paymentActivityList property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentActivityListType }
     *     
     */
    public PaymentActivityListType getPaymentActivityList() {
        return paymentActivityList;
    }

    /**
     * Sets the value of the paymentActivityList property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentActivityListType }
     *     
     */
    public void setPaymentActivityList(PaymentActivityListType value) {
        this.paymentActivityList = value;
    }

    /**
     * Gets the value of the currentStatementID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentStatementID() {
        return currentStatementID;
    }

    /**
     * Sets the value of the currentStatementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentStatementID(String value) {
        this.currentStatementID = value;
    }

    /**
     * Gets the value of the currentStatementDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCurrentStatementDate() {
        return currentStatementDate;
    }

    /**
     * Sets the value of the currentStatementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCurrentStatementDate(XMLGregorianCalendar value) {
        this.currentStatementDate = value;
    }

}
