
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1request;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1request package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AccountBillSummaryRetrieveV1RequestType_QNAME = new QName("com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Request", "accountBillSummaryRetrieveV1RequestType");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1request
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AccountBillSummaryRetrieveV1RequestType }
     * 
     */
    public AccountBillSummaryRetrieveV1RequestType createAccountBillSummaryRetrieveV1RequestType() {
        return new AccountBillSummaryRetrieveV1RequestType();
    }

    /**
     * Create an instance of {@link AccountIDListType }
     * 
     */
    public AccountIDListType createAccountIDListType() {
        return new AccountIDListType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountBillSummaryRetrieveV1RequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Request", name = "accountBillSummaryRetrieveV1RequestType")
    public JAXBElement<AccountBillSummaryRetrieveV1RequestType> createAccountBillSummaryRetrieveV1RequestType(AccountBillSummaryRetrieveV1RequestType value) {
        return new JAXBElement<AccountBillSummaryRetrieveV1RequestType>(_AccountBillSummaryRetrieveV1RequestType_QNAME, AccountBillSummaryRetrieveV1RequestType.class, null, value);
    }

}
