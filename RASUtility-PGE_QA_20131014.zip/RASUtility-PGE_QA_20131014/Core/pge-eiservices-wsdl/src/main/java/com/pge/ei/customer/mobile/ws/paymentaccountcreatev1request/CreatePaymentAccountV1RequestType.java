
package com.pge.ei.customer.mobile.ws.paymentaccountcreatev1request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreatePaymentAccountV1RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreatePaymentAccountV1RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userAccount" type="{com/pge/ei/customer/mobile/ws/PaymentAccountCreateV1Request}UserAccountType"/>
 *         &lt;element name="createPaymentAcct" type="{com/pge/ei/customer/mobile/ws/PaymentAccountCreateV1Request}CreatePaymentAccountType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreatePaymentAccountV1RequestType", propOrder = {
    "userAccount",
    "createPaymentAcct"
})
public class CreatePaymentAccountV1RequestType {

    @XmlElement(required = true)
    protected UserAccountType userAccount;
    protected CreatePaymentAccountType createPaymentAcct;

    /**
     * Gets the value of the userAccount property.
     * 
     * @return
     *     possible object is
     *     {@link UserAccountType }
     *     
     */
    public UserAccountType getUserAccount() {
        return userAccount;
    }

    /**
     * Sets the value of the userAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserAccountType }
     *     
     */
    public void setUserAccount(UserAccountType value) {
        this.userAccount = value;
    }

    /**
     * Gets the value of the createPaymentAcct property.
     * 
     * @return
     *     possible object is
     *     {@link CreatePaymentAccountType }
     *     
     */
    public CreatePaymentAccountType getCreatePaymentAcct() {
        return createPaymentAcct;
    }

    /**
     * Sets the value of the createPaymentAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreatePaymentAccountType }
     *     
     */
    public void setCreatePaymentAcct(CreatePaymentAccountType value) {
        this.createPaymentAcct = value;
    }

}
