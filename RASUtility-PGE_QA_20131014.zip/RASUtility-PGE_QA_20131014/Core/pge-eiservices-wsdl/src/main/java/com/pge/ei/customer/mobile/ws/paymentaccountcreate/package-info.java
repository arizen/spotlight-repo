@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountCreate")
package com.pge.ei.customer.mobile.ws.paymentaccountcreate;
