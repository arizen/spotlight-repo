
package com.pge.ei.customer.mobile.ws.paymentlistretrievev1response;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for paymentStateType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="paymentStateType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Unknown"/>
 *     &lt;enumeration value="SCHEDULED"/>
 *     &lt;enumeration value="AUTHORIZED"/>
 *     &lt;enumeration value="PROCESSING"/>
 *     &lt;enumeration value="PENDING"/>
 *     &lt;enumeration value="APPROVED"/>
 *     &lt;enumeration value="CANCELLED"/>
 *     &lt;enumeration value="ABORTED"/>
 *     &lt;enumeration value="REJECTED"/>
 *     &lt;enumeration value="RETURNED"/>
 *     &lt;enumeration value="REFUND"/>
 *     &lt;enumeration value="REFUNDED"/>
 *     &lt;enumeration value="REMIT"/>
 *     &lt;enumeration value="NOTREADY"/>
 *     &lt;enumeration value="EDITED"/>
 *     &lt;enumeration value="NOTPROCESSED"/>
 *     &lt;enumeration value="DUPLICATE"/>
 *     &lt;enumeration value="FAILED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "paymentStateType")
@XmlEnum
public enum PaymentStateType {

    @XmlEnumValue("Unknown")
    UNKNOWN("Unknown"),
    SCHEDULED("SCHEDULED"),
    AUTHORIZED("AUTHORIZED"),
    PROCESSING("PROCESSING"),
    PENDING("PENDING"),
    APPROVED("APPROVED"),
    CANCELLED("CANCELLED"),
    ABORTED("ABORTED"),
    REJECTED("REJECTED"),
    RETURNED("RETURNED"),
    REFUND("REFUND"),
    REFUNDED("REFUNDED"),
    REMIT("REMIT"),
    NOTREADY("NOTREADY"),
    EDITED("EDITED"),
    NOTPROCESSED("NOTPROCESSED"),
    DUPLICATE("DUPLICATE"),
    FAILED("FAILED");
    private final String value;

    PaymentStateType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PaymentStateType fromValue(String v) {
        for (PaymentStateType c: PaymentStateType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
