
package com.pge.ei.customer.mobile.ws.reportoutagev1response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReportOutageV1ResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReportOutageV1ResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="statusHeader" type="{com/pge/ei/customer/mobile/ws/ReportOutageV1Response}StatusHeaderType"/>
 *         &lt;element name="messageBody" type="{com/pge/ei/customer/mobile/ws/ReportOutageV1Response}MessageBodyType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReportOutageV1ResponseType", propOrder = {
    "statusHeader",
    "messageBody"
})
public class ReportOutageV1ResponseType {

    @XmlElement(required = true)
    protected StatusHeaderType statusHeader;
    @XmlElement(required = true)
    protected MessageBodyType messageBody;

    /**
     * Gets the value of the statusHeader property.
     * 
     * @return
     *     possible object is
     *     {@link StatusHeaderType }
     *     
     */
    public StatusHeaderType getStatusHeader() {
        return statusHeader;
    }

    /**
     * Sets the value of the statusHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusHeaderType }
     *     
     */
    public void setStatusHeader(StatusHeaderType value) {
        this.statusHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link MessageBodyType }
     *     
     */
    public MessageBodyType getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageBodyType }
     *     
     */
    public void setMessageBody(MessageBodyType value) {
        this.messageBody = value;
    }

}
