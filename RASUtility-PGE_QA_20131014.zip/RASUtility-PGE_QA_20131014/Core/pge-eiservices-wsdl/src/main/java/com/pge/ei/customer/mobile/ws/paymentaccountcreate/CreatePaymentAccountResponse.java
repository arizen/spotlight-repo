
package com.pge.ei.customer.mobile.ws.paymentaccountcreate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.paymentaccountcreatev1response.CreatePaymentAccountV1ResponseType;


/**
 * <p>Java class for createPaymentAccountResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createPaymentAccountResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/PaymentAccountCreateV1Response}createPaymentAccountV1ResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createPaymentAccountResponse", propOrder = {
    "createPaymentAccountV1ResponseType"
})
public class CreatePaymentAccountResponse {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/PaymentAccountCreateV1Response")
    protected CreatePaymentAccountV1ResponseType createPaymentAccountV1ResponseType;

    /**
     * Gets the value of the createPaymentAccountV1ResponseType property.
     * 
     * @return
     *     possible object is
     *     {@link CreatePaymentAccountV1ResponseType }
     *     
     */
    public CreatePaymentAccountV1ResponseType getCreatePaymentAccountV1ResponseType() {
        return createPaymentAccountV1ResponseType;
    }

    /**
     * Sets the value of the createPaymentAccountV1ResponseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreatePaymentAccountV1ResponseType }
     *     
     */
    public void setCreatePaymentAccountV1ResponseType(CreatePaymentAccountV1ResponseType value) {
        this.createPaymentAccountV1ResponseType = value;
    }

}
