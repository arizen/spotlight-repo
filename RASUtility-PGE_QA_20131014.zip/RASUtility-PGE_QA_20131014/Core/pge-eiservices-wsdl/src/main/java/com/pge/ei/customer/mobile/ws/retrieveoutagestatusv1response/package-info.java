@javax.xml.bind.annotation.XmlSchema(namespace = "com/pge/ei/customer/mobile/ws/RetrieveOutageStatusV1Response", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.pge.ei.customer.mobile.ws.retrieveoutagestatusv1response;
