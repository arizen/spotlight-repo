
package com.pge.ei.customer.mobile.ws.paymentlistretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.paymentlistretrievev1response.RetrievePaymentListV1ResponseType;


/**
 * <p>Java class for retrievePaymentListResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrievePaymentListResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Response}retrievePaymentListV1ResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrievePaymentListResponse", propOrder = {
    "retrievePaymentListV1ResponseType"
})
public class RetrievePaymentListResponse {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/PaymentListRetrieveV1Response")
    protected RetrievePaymentListV1ResponseType retrievePaymentListV1ResponseType;

    /**
     * Gets the value of the retrievePaymentListV1ResponseType property.
     * 
     * @return
     *     possible object is
     *     {@link RetrievePaymentListV1ResponseType }
     *     
     */
    public RetrievePaymentListV1ResponseType getRetrievePaymentListV1ResponseType() {
        return retrievePaymentListV1ResponseType;
    }

    /**
     * Sets the value of the retrievePaymentListV1ResponseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrievePaymentListV1ResponseType }
     *     
     */
    public void setRetrievePaymentListV1ResponseType(RetrievePaymentListV1ResponseType value) {
        this.retrievePaymentListV1ResponseType = value;
    }

}
