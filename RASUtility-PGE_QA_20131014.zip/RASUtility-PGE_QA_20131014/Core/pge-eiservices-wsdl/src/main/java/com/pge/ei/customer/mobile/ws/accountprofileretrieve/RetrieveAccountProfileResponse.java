
package com.pge.ei.customer.mobile.ws.accountprofileretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.accountprofileretrievev1response.AccountProfileRetrieveV1ResponseType;


/**
 * <p>Java class for retrieveAccountProfileResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveAccountProfileResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Response}AccountProfileRetrieveV1ResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveAccountProfileResponse", propOrder = {
    "accountProfileRetrieveV1ResponseType"
})
public class RetrieveAccountProfileResponse {

    @XmlElement(name = "AccountProfileRetrieveV1ResponseType", namespace = "com/pge/ei/customer/mobile/ws/AccountProfileRetrieveV1Response")
    protected AccountProfileRetrieveV1ResponseType accountProfileRetrieveV1ResponseType;

    /**
     * Gets the value of the accountProfileRetrieveV1ResponseType property.
     * 
     * @return
     *     possible object is
     *     {@link AccountProfileRetrieveV1ResponseType }
     *     
     */
    public AccountProfileRetrieveV1ResponseType getAccountProfileRetrieveV1ResponseType() {
        return accountProfileRetrieveV1ResponseType;
    }

    /**
     * Sets the value of the accountProfileRetrieveV1ResponseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountProfileRetrieveV1ResponseType }
     *     
     */
    public void setAccountProfileRetrieveV1ResponseType(AccountProfileRetrieveV1ResponseType value) {
        this.accountProfileRetrieveV1ResponseType = value;
    }

}
