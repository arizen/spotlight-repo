
package com.pge.ei.customer.mobile.ws.accountbillsummaryretrieve;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.accountbillsummaryretrievev1response.AccountBillSummaryRetrieveV1ResponseType;


/**
 * <p>Java class for retrieveAccountBillSummaryResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveAccountBillSummaryResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Response}AccountBillSummaryRetrieveV1Response" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveAccountBillSummaryResponse", propOrder = {
    "accountBillSummaryRetrieveV1Response"
})
public class RetrieveAccountBillSummaryResponse {

    @XmlElement(name = "AccountBillSummaryRetrieveV1Response", namespace = "com/pge/ei/customer/mobile/ws/AccountBillSummaryRetrieveV1Response")
    protected AccountBillSummaryRetrieveV1ResponseType accountBillSummaryRetrieveV1Response;

    /**
     * Gets the value of the accountBillSummaryRetrieveV1Response property.
     * 
     * @return
     *     possible object is
     *     {@link AccountBillSummaryRetrieveV1ResponseType }
     *     
     */
    public AccountBillSummaryRetrieveV1ResponseType getAccountBillSummaryRetrieveV1Response() {
        return accountBillSummaryRetrieveV1Response;
    }

    /**
     * Sets the value of the accountBillSummaryRetrieveV1Response property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountBillSummaryRetrieveV1ResponseType }
     *     
     */
    public void setAccountBillSummaryRetrieveV1Response(AccountBillSummaryRetrieveV1ResponseType value) {
        this.accountBillSummaryRetrieveV1Response = value;
    }

}
