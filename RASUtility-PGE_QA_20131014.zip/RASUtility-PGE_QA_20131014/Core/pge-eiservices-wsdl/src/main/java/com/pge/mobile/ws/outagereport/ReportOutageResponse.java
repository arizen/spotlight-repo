
package com.pge.mobile.ws.outagereport;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.pge.ei.customer.mobile.ws.reportoutagev1response.ReportOutageV1ResponseType;


/**
 * <p>Java class for reportOutageResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="reportOutageResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{com/pge/ei/customer/mobile/ws/ReportOutageV1Response}reportOutageV1ResponseType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reportOutageResponse", propOrder = {
    "reportOutageV1ResponseType"
})
public class ReportOutageResponse {

    @XmlElement(namespace = "com/pge/ei/customer/mobile/ws/ReportOutageV1Response")
    protected ReportOutageV1ResponseType reportOutageV1ResponseType;

    /**
     * Gets the value of the reportOutageV1ResponseType property.
     * 
     * @return
     *     possible object is
     *     {@link ReportOutageV1ResponseType }
     *     
     */
    public ReportOutageV1ResponseType getReportOutageV1ResponseType() {
        return reportOutageV1ResponseType;
    }

    /**
     * Sets the value of the reportOutageV1ResponseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReportOutageV1ResponseType }
     *     
     */
    public void setReportOutageV1ResponseType(ReportOutageV1ResponseType value) {
        this.reportOutageV1ResponseType = value;
    }

}
