package com.wizni.reportaspot.flow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.Message;

import com.wizni.reportaspot.model.customfields.pojo.IncidentErrorResponse;
import com.wizni.reportaspot.model.jaxb.SearchReportRequest;
import com.wizni.reportaspot.model.support.incident.pojo.SearchIncidentResponse;
import com.wizni.reportaspot.orchestration.dto.SearchIssueDto;

/**
 * This class defines all the methods involved in the processing of the search flow. The
 * wiring logic of these methods will be present in the spring integration xml.
 *  
 * @author WizniDev
 */
public class NewSearchFlow {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(NewSearchFlow.class);
	
	/**
	 * This method searches the system incident.
	 * 
	 * @param message
	 * @return {@link SearchIncidentResponse}
	 */
	public SearchIncidentResponse searchSystemIncident(Message<SearchIssueDto> message) {

		SearchIssueDto searchIssueDto = message.getPayload();

		/**
		 * SearchReportRequest is the request object received from the user for search issue request.
		 * It contains all the user provided information searching an issue.
		 */
		SearchReportRequest searchReportRequest = searchIssueDto.getSearchReport();


		/**
		 * Code to search system incident.
		 */
		logger.info("Searching system incident for category "+searchReportRequest.getCategory());
		boolean isSuccess = true;


		
		if(isSuccess) {
			
			/**
			 * Success response
			 */
			message.getPayload().getSearchIncidentResponse().setIsSuccess(true);
			
			/**
			 * Use the below code of line to add the list of fields for searched incident using key-value pair.
			 */
			message.getPayload().getSearchIncidentResponse().addToCustomFields("-key-", "-value-");
			
		} else {

			/**
			 * Error response
			 */
			message.getPayload().getSearchIncidentResponse().setIsSuccess(false);

			IncidentErrorResponse incidentErrorResponse = new IncidentErrorResponse();
			incidentErrorResponse.setErrorKey("-error Key-");
			incidentErrorResponse.setErrorKey("-error Message-");
			message.getPayload().getSearchIncidentResponse().setError(incidentErrorResponse);
		}

		return message.getPayload().getSearchIncidentResponse();
	}
}
