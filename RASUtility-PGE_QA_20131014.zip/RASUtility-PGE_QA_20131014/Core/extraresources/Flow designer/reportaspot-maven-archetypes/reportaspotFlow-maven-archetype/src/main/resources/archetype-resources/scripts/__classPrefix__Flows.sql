/**
 * create flow insert script
 */ 
INSERT INTO `ras_workflows` (`description`, `name`, `interface_name`, `customer_id`, `workflow_type`, `is_asynchronous`) 
	VALUES ('${classPrefix}CreateFlow description', '${classPrefix} Create Flow', '${classPrefix}CreateFlowGateway', 1, 'CREATE', 0);


/**
 * search flow insert script
 */ 
INSERT INTO `ras_workflows` (`description`, `name`, `interface_name`, `customer_id`, `workflow_type`, `is_asynchronous`) 
	VALUES ('${classPrefix}SearchFlow description', '${classPrefix} Search Flow', '${classPrefix}SearchFlowGateway', 1, 'SEARCH', 0);

	
/**
 * update flow insert script
 */ 
INSERT INTO `ras_workflows` (`description`, `name`, `interface_name`, `customer_id`, `workflow_type`, `is_asynchronous`) 
	VALUES ('${classPrefix}UpdateFlow description', '${classPrefix} Update Flow', '${classPrefix}UpdateFlowGateway', 1, 'UPDATE', 0);