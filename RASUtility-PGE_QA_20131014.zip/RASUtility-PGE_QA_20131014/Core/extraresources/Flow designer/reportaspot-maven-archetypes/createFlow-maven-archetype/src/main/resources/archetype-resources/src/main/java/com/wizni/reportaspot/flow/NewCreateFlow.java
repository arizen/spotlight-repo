package com.wizni.reportaspot.flow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.Message;

import com.wizni.reportaspot.model.customfields.pojo.IncidentErrorResponse;
import com.wizni.reportaspot.model.jaxb.ServiceIssue;
import com.wizni.reportaspot.model.support.incident.pojo.CreateIncidentReponse;
import com.wizni.reportaspot.orchestration.dto.CreateIssueDto;

/**
 * This class defines all the methods involved in the processing of the create flow. The
 * wiring logic of these methods will be present in the spring integration xml.
 *  
 * @author WizniDev
 */
public class NewCreateFlow {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(NewCreateFlow.class);
	
	/**
	 * This method creates the system incident.
	 * 
	 * @param message
	 * @return {@link CreateIncidentReponse}
	 */
    public CreateIncidentReponse createSystemIncident(Message<CreateIssueDto> message) {

    	CreateIssueDto createIssueDto = message.getPayload();
    	
    	/**
    	 * Service issue is the request object received from the user for create issue request.
    	 * It contains all the user provided information for creating an issue.
    	 */
    	ServiceIssue serviceIssue = createIssueDto.getServiceIssue();
    	
    	
    	/**
    	 * Code to create system incident.
    	 */
    	logger.info("Creating system incident for category "+serviceIssue.getCategory());
    	boolean isSuccess = true;
    	
    	
    	/**
    	 * Set the response based on isSuccess
    	 */
    	if(isSuccess) {
    		/**
    		 * Success response
    		 */
    		message.getPayload().getCreateIncidentReponse().setSuccess(true);
    		message.getPayload().getCreateIncidentReponse().setResponseId("-system incident id generated-");
    		
    	} else {
    		
    		/**
    		 * Error response
    		 */
    		message.getPayload().getCreateIncidentReponse().setSuccess(false);
    		
    		IncidentErrorResponse incidentErrorResponse = new IncidentErrorResponse();
    		incidentErrorResponse.setErrorKey("-error Key-");
    		incidentErrorResponse.setErrorKey("-error Message-");
    		message.getPayload().getCreateIncidentReponse().setError(incidentErrorResponse);
    	}
    	
    	return message.getPayload().getCreateIncidentReponse();
    }
}
