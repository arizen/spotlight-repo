package com.wizni.reportaspot.wizards.wizards;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.apache.maven.archetype.catalog.Archetype;
import org.apache.maven.model.Model;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.m2e.core.MavenPlugin;
import org.eclipse.m2e.core.internal.IMavenConstants;
import org.eclipse.m2e.core.internal.MavenPluginActivator;
import org.eclipse.m2e.core.internal.archetype.ArchetypeCatalogFactory;
import org.eclipse.m2e.core.internal.archetype.ArchetypeManager;
import org.eclipse.m2e.core.ui.internal.wizards.AbstactCreateMavenProjectJob;
import org.eclipse.m2e.core.ui.internal.wizards.AbstractMavenProjectWizard;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;


@SuppressWarnings("restriction")
public class NewFlowBuilderProjectWizard extends AbstractMavenProjectWizard implements INewWizard{

	NewFlowBuilderProjectPage flowBuilderProjectPage;

	public NewFlowBuilderProjectWizard() {
		super();
		setWindowTitle("New Flow Builder Project");
	}
	
	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		super.init(workbench, selection);
	}

	@Override
	public void addPages() {
		flowBuilderProjectPage = new NewFlowBuilderProjectPage("New Flow Builder Project");
		addPage(flowBuilderProjectPage);
	}

	@Override
	public void createPageControls(Composite pageContainer) {
		super.createPageControls(pageContainer);
		
		flowBuilderProjectPage.addProjectNameListener(new ModifyListener() {
	      public void modifyText(ModifyEvent e) {
	        getContainer().updateButtons();
	      }
	    });
	}

	@Override
	public boolean performFinish() {

		final Model model = getModel();
		final String projectName = importConfiguration.getProjectName(model);
		IStatus nameStatus = importConfiguration.validateProjectName(model);
		if(!nameStatus.isOK()) {
			MessageDialog.openError(getShell(), NLS.bind("Failed to create project \"{0}\"", projectName), nameStatus.getMessage()); 
			return false;
		}

		IWorkspace workspace = ResourcesPlugin.getWorkspace();

		final IPath location = null;
		final IWorkspaceRoot root = workspace.getRoot();
		final IProject project = importConfiguration.getProject(root, model);

		boolean pomExists = (root.getLocation().append(project.getName())).append(IMavenConstants.POM_FILE_NAME).toFile().exists();
		if ( pomExists ) {
			MessageDialog.openError(getShell(), NLS.bind("Failed to create project \"{0}\"", projectName),
					"A pom.xml file already exists in the destination folder.");
			return false;
		}

		final Job job;


		final List<Archetype> archetypes = getAllArchetypes();
		Archetype artype = null;
		//String flowType = flowBuilderProjectPage.getFlowType();
		for (Archetype arctype : archetypes) {
			if(arctype.getGroupId().equalsIgnoreCase("reportaspot")) {
				if(arctype.getArtifactId().equalsIgnoreCase("reportaspotFlow-maven-archetype")) {
					artype = arctype;
					break;
				}
				/*if(flowType.equalsIgnoreCase("Create") && arctype.getArtifactId().equalsIgnoreCase("createFlow-maven-archetype")) {
					artype = arctype;
					break;
				} else if(flowType.equalsIgnoreCase("Search") && arctype.getArtifactId().equalsIgnoreCase("searchFlow-maven-archetype")) {
					artype = arctype;
					break;
				}*/
			}
		}

		final Archetype archetype = artype;

		final String groupId = flowBuilderProjectPage.getProjectName();
		final String artifactId = flowBuilderProjectPage.getProjectName();
		final String version = "1.0.0";
		final String javaPackage = flowBuilderProjectPage.getProjectName()+"."+flowBuilderProjectPage.getProjectName();
		final Properties properties = new Properties();
		/*properties.setProperty("classPrefix", flowBuilderProjectPage.getProjectName());*/
		System.out.println(archetype.getArtifactId());
		job = new AbstactCreateMavenProjectJob(NLS.bind("Creating project \"{0}\"", archetype.getArtifactId()), workingSets) { 
			@Override
			protected List<IProject> doCreateMavenProjects(IProgressMonitor monitor) throws CoreException {
				MavenPlugin.getProjectConfigurationManager().createArchetypeProject(project, location, archetype, //
						groupId, artifactId, version, javaPackage, properties, importConfiguration, monitor);
				return Arrays.asList(project);
			}
		};


		job.addJobChangeListener(new JobChangeAdapter() {
			public void done(IJobChangeEvent event) {
				final IStatus result = event.getResult();
				if(!result.isOK()) {
					Display.getDefault().asyncExec(new Runnable() {
						public void run() {
							MessageDialog.openError(getShell(), //
									NLS.bind("Failed to create project \"{0}\"", projectName), result.getMessage()); 
						}
					});
				}
			}
		});


		job.setRule(MavenPlugin.getProjectConfigurationManager().getRule());
		job.schedule();

		return true;
	}

	public Model getModel() {
		Model model = new Model();

		model.setModelVersion("4.0.0"); //$NON-NLS-1$
		model.setGroupId(flowBuilderProjectPage.getProjectName());
		model.setArtifactId(flowBuilderProjectPage.getProjectName());
		model.setVersion("1.0.0");

		return model;
	}
	
	@SuppressWarnings("unchecked")
	  private List<Archetype> getAllArchetypes() {
	    ArchetypeManager manager = MavenPluginActivator.getDefault().getArchetypeManager();
	    Collection<ArchetypeCatalogFactory> archetypeCatalogs = manager.getArchetypeCatalogs();
	    ArrayList<Archetype> list = new ArrayList<Archetype>();

	    for(ArchetypeCatalogFactory catalog : archetypeCatalogs) {
	      try {
	        //temporary hack to get around 'Test Remote Catalog' blowing up on download
	        //described in https://issues.sonatype.org/browse/MNGECLIPSE-1792
	        if(catalog.getDescription().startsWith("Test")) { //$NON-NLS-1$
	          continue;
	        }
	        @SuppressWarnings("rawtypes")
	        List arcs = catalog.getArchetypeCatalog().getArchetypes();
	        if(arcs != null) {
	          list.addAll(arcs);
	        }
	      } catch(Exception ce) {
	    	  
	      }
	    }
	    return list;
	  }
}
