package com.wizni.reportaspot.wizards.wizards;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class NewFlowBuilderProjectPage extends WizardPage{

	Text projectNameText;
	
	Combo flowTypeCombo;
	
	public NewFlowBuilderProjectPage(String pageName) {
		super(pageName);
		setTitle("New Flow Builder Project");
		setDescription("New Flow Builder Project Wizard");
		setPageComplete(true);
	}

	@Override
	public void createControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NULL);
		GridLayout gridLayout = new GridLayout(3, false);
		gridLayout.verticalSpacing = 20;
		composite.setLayout(gridLayout);

		Label projectNameLabel = new Label(composite, SWT.NONE);
		projectNameLabel.setText("Project Name"); 

		projectNameText = new Text(composite, SWT.BORDER);
		projectNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		// flow type drop down
		/*Label flowTypeLabel = new Label(composite, SWT.NONE);
		flowTypeLabel.setText("Flow Type");
		
		flowTypeCombo = new Combo(composite, SWT.READ_ONLY);
		flowTypeCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		flowTypeCombo.setItems(new String[]{"Create", "Search"});
		flowTypeCombo.select(0);*/
		
		setControl(composite);
	}
	
	public String getProjectName() {
		return (projectNameText != null)?projectNameText.getText():null;
	}
	
	public String getFlowType() {
		return (flowTypeCombo != null)?flowTypeCombo.getText():null;
	}
	
	public void addProjectNameListener(ModifyListener modifyListener) {
		projectNameText.addModifyListener(modifyListener);
	}
}
