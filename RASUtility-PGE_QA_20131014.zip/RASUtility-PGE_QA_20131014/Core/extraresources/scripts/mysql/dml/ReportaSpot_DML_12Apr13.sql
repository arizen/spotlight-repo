INSERT INTO issue_category_group (`id`, `group_name`, `group_description`, `customer_id`) VALUES (1, 'Outages', NULL, 1);
INSERT INTO issue_category_group (`id`, `group_name`, `group_description`, `customer_id`) VALUES (2, 'Problems', NULL, 1);

update issue_category_ms set issue_category_group_id = 1 where category_type in ('Partial Outage','Complete Outage','Street Light Problem');
update issue_category_ms set issue_category_group_id = 2 where category_type in ('Energy Theft','Safety Concern','Graffiti');
