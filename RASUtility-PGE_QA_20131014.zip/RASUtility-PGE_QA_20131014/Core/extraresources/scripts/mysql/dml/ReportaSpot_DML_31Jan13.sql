INSERT INTO ras_workflows (id, description, name, interface_name, customer_id, workflow_type) VALUES (3, 'Search Outage workflow', 'Search Outage Workflow', 'outageSearchWorkflow', 1, 'SEARCH');

update issue_category_ms set search_issue_workflow = 3 where category_type in ('Complete Outage', 'Partial Outage');
