update issue_category_ms set issue_category_ms.custom_fields_configured = 1, issue_category_ms.version='1.0' where issue_category_ms.category_type in ('Complete Outage', 'Partial Outage', 'Street Light Problem');

update customer_category_custom_field set customer_category_custom_field.version='1.0';

update issue set is_request_complete =1;