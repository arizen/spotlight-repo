INSERT INTO ras_workflows (id, description, name, interface_name, customer_id) VALUES (1, 'Outage workflow', 'Create Outage Workflow', 'outageWorkflow', 1);
INSERT INTO ras_workflows (id, description, name, interface_name, customer_id) VALUES (2, 'Email Workflow', 'Email Workflow', 'emailWorkflow', 1);

update issue_category_ms set create_issue_workflow = 1 where category_type in ('Complete Outage', 'Partial Outage');
update issue_category_ms set create_issue_workflow = 2 where category_type in ('Street Light Problem', 'Safety Concern', 'Energy Theft');
