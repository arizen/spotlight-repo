CREATE TABLE issue_category_group
(
  id Bigint NOT NULL AUTO_INCREMENT,
  group_name Varchar(255) NOT NULL,
  group_description Varchar(255),
  customer_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This table stores the issue category groups configured for the customer.'
;

CREATE INDEX issCatGrp_custid USING BTREE ON issue_category_group (customer_id)
;

ALTER TABLE issue_category_group ADD CONSTRAINT fk_issCatGrp_custid FOREIGN KEY (customer_id) REFERENCES customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE issue_category_ms ADD COLUMN issue_category_group_id BIGINT NULL;

CREATE INDEX isscatms_idx_issCatGrpId USING BTREE ON issue_category_ms (issue_category_group_id)
;

ALTER TABLE issue_category_ms ADD CONSTRAINT fk_isscatms_issCatGrpId FOREIGN KEY (issue_category_group_id) REFERENCES issue_category_group (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;