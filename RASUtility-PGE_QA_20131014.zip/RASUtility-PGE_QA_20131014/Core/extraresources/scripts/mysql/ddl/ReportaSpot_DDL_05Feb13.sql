ALTER TABLE `issue_category_ms`
	ADD COLUMN `cache_service_bean` VARCHAR(50) NULL AFTER `update_issue_workflow`;
	
ALTER TABLE `ras_workflows`
	ADD COLUMN `is_asynchronous` BIT NOT NULL;