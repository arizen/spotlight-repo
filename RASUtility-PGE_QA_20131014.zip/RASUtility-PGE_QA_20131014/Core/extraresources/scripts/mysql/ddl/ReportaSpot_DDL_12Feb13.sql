ALTER TABLE `issue_category_ms`
	ADD COLUMN `custom_fields_configured` BIT(1) NULL;

ALTER TABLE `issue_category_ms`
	ADD COLUMN `version` VARCHAR(20) NULL;

ALTER TABLE `customer_category_custom_field`
	ADD COLUMN `version` VARCHAR(20) NULL;

ALTER TABLE `issue`
	ADD COLUMN `error_key` VARCHAR(255) NULL AFTER `is_archived`;

ALTER TABLE `issue`
	ADD COLUMN `error_msg` VARCHAR(255) NULL AFTER `error_key`;

ALTER TABLE `issue`
	ADD COLUMN `is_request_complete` BIT(1) NULL AFTER `error_msg`;


