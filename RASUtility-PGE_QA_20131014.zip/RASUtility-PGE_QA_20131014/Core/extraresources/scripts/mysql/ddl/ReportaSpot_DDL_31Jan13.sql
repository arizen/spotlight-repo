ALTER TABLE reportaspotdev.ras_workflows ADD COLUMN workflow_type ENUM('CREATE','SEARCH','UPDATE') NOT NULL;

ALTER TABLE reportaspotdev.issue_category_ms ADD COLUMN search_issue_workflow BIGINT NULL;

ALTER TABLE reportaspotdev.issue_category_ms ADD COLUMN update_issue_workflow BIGINT NULL;

CREATE INDEX isscatms_idx_searchisswrkflw USING BTREE ON reportaspotdev.issue_category_ms (search_issue_workflow)
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_searchisswrkflw FOREIGN KEY (search_issue_workflow) REFERENCES reportaspotdev.ras_workflows (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

CREATE INDEX isscatms_idx_updateisswrkflw USING BTREE ON reportaspotdev.issue_category_ms (update_issue_workflow)
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_updateisswrkflw FOREIGN KEY (update_issue_workflow) REFERENCES reportaspotdev.ras_workflows (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;