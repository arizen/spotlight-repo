CREATE TABLE issue_address
(
  id Bigint NOT NULL AUTO_INCREMENT,
  city Varchar(255) NOT NULL,
  country_code Varchar(255),
  house_number Varchar(255) NOT NULL,
  state Varchar(255) NOT NULL,
  street Varchar(255),
  zip_code Varchar(255) NOT NULL,
  issue_id Bigint NOT NULL,
  address_label Varchar(255),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the addresses for users. A user may have multple addresses and report incidents for multiple address at the same point in time'
;