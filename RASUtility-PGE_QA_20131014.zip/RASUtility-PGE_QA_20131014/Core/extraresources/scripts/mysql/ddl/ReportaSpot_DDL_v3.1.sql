/*
Created: 1/18/2013
Modified: 1/18/2013
Model: ReportaSpot_Physical
Company: Wizni, Inc.
Author: ReportaSpot Development Team
Version: 2.1
Database: MySQL 5.5
*/

-- Create tables section -------------------------------------------------

-- Table reportaspotdev.customer_type

CREATE TABLE reportaspotdev.customer_type
(
  id Bigint NOT NULL AUTO_INCREMENT,
  type Varchar(120) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of types of customer types (e.g., Energy, Retail etc.)'
;

-- Table reportaspotdev.city

CREATE TABLE reportaspotdev.city
(
  id Bigint NOT NULL AUTO_INCREMENT,
  name Varchar(120) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of cities'
;

-- Table reportaspotdev.customer

CREATE TABLE reportaspotdev.customer
(
  id Bigint NOT NULL AUTO_INCREMENT,
  name Varchar(120) NOT NULL,
  city_id Bigint NOT NULL,
  customer_type_id Bigint NOT NULL,
  web_url Varchar(255) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of tenants'
;

CREATE INDEX cust_idx_custtype_id USING BTREE ON reportaspotdev.customer (customer_type_id)
;

CREATE INDEX cust_idx_cityid USING BTREE ON reportaspotdev.customer (city_id)
;

-- Table reportaspotdev.user

CREATE TABLE reportaspotdev.user
(
  email_id Varchar(30) NOT NULL,
  first_name Varchar(30),
  last_name Varchar(30),
  phone_number Varchar(30),
  user_type Int,
  apns_key Varchar(255),
  customer_account_id Varchar(50)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the users information such as name, email, phone etc in order to identify themselves as the reported of the issue'
;

ALTER TABLE reportaspotdev.user ADD PRIMARY KEY (email_id)
;

-- Table reportaspotdev.user_role

CREATE TABLE reportaspotdev.user_role
(
  id Bigint NOT NULL AUTO_INCREMENT,
  name Varchar(120) NOT NULL,
  customer_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the user roles'
;

CREATE INDEX usrrole_idx_custid USING BTREE ON reportaspotdev.user_role (customer_id)
;

-- Table reportaspotdev.admin

CREATE TABLE reportaspotdev.admin
(
  login_id Varchar(30) NOT NULL,
  password Longtext,
  user_id Varchar(30) NOT NULL,
  user_role_id Bigint,
  customer_id Bigint NOT NULL,
  forgot_password_token Longtext,
  access_role Enum('ROLE_ADMIN','ROLE_SUPERADMIN','ROLE_USER') NOT NULL
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of admin users and their details'
;

ALTER TABLE reportaspotdev.admin ADD PRIMARY KEY (login_id)
;

CREATE INDEX admin_idx_usrroleid USING BTREE ON reportaspotdev.admin (user_role_id)
;

CREATE INDEX admin_idx_userid USING BTREE ON reportaspotdev.admin (user_id)
;

CREATE INDEX admin_idx_customerid USING BTREE ON reportaspotdev.admin (customer_id)
;

-- Table reportaspotdev.issue_category_ms

CREATE TABLE reportaspotdev.issue_category_ms
(
  id Bigint NOT NULL AUTO_INCREMENT,
  category_type Varchar(255) NOT NULL,
  twitter_shortcode_hash Varchar(255),
  default_assignee Bigint,
  priority Varchar(30) NOT NULL DEFAULT "MED",
  is_active Bit(1),
  should_post_to_twitter Bit(1),
  create_issue_workflow Bigint,
  search_issue_workflow Bigint,
  update_issue_workflow Bigint,
  customer_id Bigint NOT NULL,
  custom_fields_configured Bit(1),
  allow_annonymous_report Varchar(20),
  version Bit(1),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the master list of issue categories supported by the system'
;

CREATE INDEX isscatms_idx_custid USING BTREE ON reportaspotdev.issue_category_ms (customer_id)
;

CREATE UNIQUE INDEX isscatms_idx_cattype USING BTREE ON reportaspotdev.issue_category_ms (category_type)
;

CREATE UNIQUE INDEX isscatms_idx_twthash USING BTREE ON reportaspotdev.issue_category_ms (twitter_shortcode_hash)
;

CREATE INDEX isscatms_idx_defass USING BTREE ON reportaspotdev.issue_category_ms (default_assignee)
;

CREATE INDEX isscatms_idx_createisswrkflw USING BTREE ON reportaspotdev.issue_category_ms (create_issue_workflow)
;

CREATE INDEX isscatms_idx_searchisswrkflw USING BTREE ON reportaspotdev.issue_category_ms (search_issue_workflow)
;

CREATE INDEX isscatms_idx_updateisswrkflw USING BTREE ON reportaspotdev.issue_category_ms (update_issue_workflow)
;

-- Table reportaspotdev.admin_alert

CREATE TABLE reportaspotdev.admin_alert
(
  id Bigint NOT NULL AUTO_INCREMENT,
  period_cycle Enum('HOURLY','DAILY','WEEKLY') NOT NULL,
  alert_count_condition Enum('GTE','LTE') NOT NULL,
  alert_name Varchar(255) NOT NULL,
  alert_text_script Longtext,
  creation_date Datetime NOT NULL,
  is_email Bit(1) NOT NULL,
  is_repeatable Bit(1) NOT NULL,
  is_sent Bit(1) NOT NULL,
  is_sms Bit(1) NOT NULL,
  issue_count Bigint NOT NULL,
  issue_status Enum('OPEN','CLOSED','PENDING'),
  last_alert_send_time Datetime,
  period_number Int NOT NULL,
  admin_id Varchar(30) NOT NULL,
  issue_category_id Bigint,
  is_enabled Bit(1) NOT NULL ,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of alert setup for admins to get notifications'
;

CREATE INDEX admalrt_idx_isscatid USING BTREE ON reportaspotdev.admin_alert (issue_category_id)
;

CREATE INDEX admalrt_idx_admid USING BTREE ON reportaspotdev.admin_alert (admin_id)
;

-- Table reportaspotdev.admin_alerts_audit

CREATE TABLE reportaspotdev.admin_alerts_audit
(
  id Bigint NOT NULL AUTO_INCREMENT,
  alert_body Longtext NOT NULL,
  creation_date Datetime NOT NULL,
  admin__login_id Varchar(255) NOT NULL,
  alert_name Varchar(255) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the audit details. Logs all admin alerts send to admins'
;

-- Table reportaspotdev.api_key_management

CREATE TABLE reportaspotdev.api_key_management
(
  access_key Varchar(255) NOT NULL,
  secret_key Varchar(255) NOT NULL,
  creation_date Datetime NOT NULL,
  last_modifed_date Datetime NOT NULL,
  valid_from Datetime NOT NULL,
  valid_till Datetime NOT NULL,
  customer_id Bigint NOT NULL
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the configuration for API keys'
;

ALTER TABLE reportaspotdev.api_key_management ADD PRIMARY KEY (access_key)
;

CREATE UNIQUE INDEX access_key USING BTREE ON reportaspotdev.api_key_management (access_key)
;

CREATE INDEX apikeymgmt_idx_custid USING BTREE ON reportaspotdev.api_key_management (customer_id)
;

-- Table reportaspotdev.customer_category_custom_field

CREATE TABLE reportaspotdev.customer_category_custom_field
(
  id Bigint NOT NULL AUTO_INCREMENT,
  column_type Enum('VARCHAR','LONG','DATE','DOUBLE','BOOLEAN','MULTISELECT') NOT NULL,
  custom_field_name Varchar(255) NOT NULL,
  is_mandatory Bit(1) NOT NULL,
  title Varchar(255) NOT NULL,
  xml_tag_name Varchar(255) NOT NULL,
  issue_category_id Bigint NOT NULL,
  is_visible_on_display Bit(1) NOT NULL,
  is_visible_on_form Bit(1) NOT NULL,
  ui_control_type Enum('TEXT_FIELD','CHECK_BOX','RADIO_BUTTON','DROP_DOWN') NOT NULL,
  possible_values Varchar(255),
  version Varchar(20),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables supports the custom form fields related to different categories for various tenants (customers). The table allows customer to define fields for each category type'
;

CREATE INDEX custcatcf_idx_issuecatid USING BTREE ON reportaspotdev.customer_category_custom_field (issue_category_id)
;

-- Table reportaspotdev.global_property_key_value

CREATE TABLE reportaspotdev.global_property_key_value
(
  global_key Varchar(255) NOT NULL,
  global_value Varchar(255) NOT NULL,
  show_on_ui Bit(1) NOT NULL,
  ui_display_name Varchar(255) NOT NULL,
  is_editable_on_ui Bit(1) NOT NULL,
  possible_values Varchar(255),
  ui_control_type Enum('TEXT_FIELD','CHECK_BOX','RADIO_BUTTON','DROP_DOWN'),
  ui_id Varchar(255)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the system configurations required for the application like customer URL etc. The table stores the key and value pair for each property'
;

ALTER TABLE reportaspotdev.global_property_key_value ADD PRIMARY KEY (global_key)
;

-- Table reportaspotdev.region

CREATE TABLE reportaspotdev.region
(
  id Bigint NOT NULL AUTO_INCREMENT,
  geo_points Longtext NOT NULL,
  name Varchar(30) NOT NULL,
  customer_id Bigint NOT NULL,
  PARENT_ID Bigint,
  geo_polygon Polygon,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the service area details'
;

CREATE INDEX region_idx_custid USING BTREE ON reportaspotdev.region (customer_id)
;

CREATE INDEX region_idx_parentid USING BTREE ON reportaspotdev.region (PARENT_ID)
;

-- Table reportaspotdev.lines_of_business

CREATE TABLE reportaspotdev.lines_of_business
(
  id Bigint NOT NULL AUTO_INCREMENT,
  name Varchar(120) NOT NULL,
  customer_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of lines of businesses like Electric, Gas, Marketing, etc. Lines of Businesses are linked to customer type. e.g, Customer of Energy Domain can have multiple lines of businesses like Electric or Gas.
Each Customer of a different domain can configure different lines of businesses for their domain'
;

CREATE INDEX lob_idx_custid USING BTREE ON reportaspotdev.lines_of_business (customer_id)
;

-- Table reportaspotdev.issue

CREATE TABLE reportaspotdev.issue
(
  id Bigint NOT NULL AUTO_INCREMENT,
  address Varchar(255),
  creation_date Datetime NOT NULL,
  description Longtext,
  device Varchar(20),
  is_public Bit(1) NOT NULL,
  last_modified_date Datetime NOT NULL,
  latitude Double NOT NULL,
  longitude Double NOT NULL,
  status Varchar(255) NOT NULL,
  title Varchar(120) NOT NULL,
  issue_category_id Bigint NOT NULL,
  user_id Varchar(30) NOT NULL,
  is_spam Bit(1) NOT NULL,
  customer_id Bigint NOT NULL,
  lob_id Bigint,
  region_id Bigint NOT NULL,
  last_status_change_date Datetime NOT NULL,
  priority Varchar(30) NOT NULL DEFAULT "MED",
  thumbnail_url Longtext,
  assignee_id Varchar(30),
  is_archived Bit(1) NOT NULL,
  error_key VARCHAR(255) NULL,
  error_msg VARCHAR(255) NULL,
  is_request_complete BIT(1) NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the list of issues/problems/incidents reported'
;

CREATE INDEX issue_idx_isscatid USING BTREE ON reportaspotdev.issue (issue_category_id)
;

CREATE INDEX issue_idx_lobid USING BTREE ON reportaspotdev.issue (lob_id)
;

CREATE INDEX issue_idx_assid USING BTREE ON reportaspotdev.issue (assignee_id)
;

CREATE INDEX issue_idx_usrid USING BTREE ON reportaspotdev.issue (user_id)
;

CREATE INDEX issue_idx_rgnid USING BTREE ON reportaspotdev.issue (region_id)
;

CREATE INDEX issue_idx_custid USING BTREE ON reportaspotdev.issue (customer_id)
;

-- Table reportaspotdev.issue_audit

CREATE TABLE reportaspotdev.issue_audit
(
  id Bigint NOT NULL AUTO_INCREMENT,
  creation_date Datetime NOT NULL,
  is_public Bit(1) NOT NULL,
  is_spam Bit(1) NOT NULL,
  priority Varchar(30) NOT NULL DEFAULT "MED",
  status Varchar(255) NOT NULL,
  issue_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables is used as an audit table for the issues/incidents. The table stores an entry for every update to the issue table'
;

CREATE INDEX issadt_idx_issueid USING BTREE ON reportaspotdev.issue_audit (issue_id)
;

-- Table reportaspotdev.issue_comments

CREATE TABLE reportaspotdev.issue_comments
(
  id Bigint NOT NULL AUTO_INCREMENT,
  comment Varchar(255) NOT NULL,
  submitted_date Datetime,
  issue_id Bigint NOT NULL,
  user_id Varchar(30) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the comments on issues'
;

CREATE INDEX isscomm_idx_usrid USING BTREE ON reportaspotdev.issue_comments (user_id)
;

CREATE INDEX isscomm_idx_issueid USING BTREE ON reportaspotdev.issue_comments (issue_id)
;

-- Table reportaspotdev.issue_custom_field_ref

CREATE TABLE reportaspotdev.issue_custom_field_ref
(
  id Bigint NOT NULL AUTO_INCREMENT,
  date_field Datetime,
  long_field Bigint,
  string_field Varchar(255),
  custom_field_id Bigint NOT NULL,
  issue_id Bigint NOT NULL,
  boolean_field Tinyint(1) NOT NULL,
  double_field Double,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables serves as an extension of the issue table. The table stores the custom field values associated with an issue/incident'
;

CREATE INDEX isscfref_idx_cfid USING BTREE ON reportaspotdev.issue_custom_field_ref (custom_field_id)
;

CREATE INDEX isscfref_idx_issueid USING BTREE ON reportaspotdev.issue_custom_field_ref (issue_id)
;

-- Table reportaspotdev.issue_images

CREATE TABLE reportaspotdev.issue_images
(
  id Bigint NOT NULL AUTO_INCREMENT,
  image_name Varchar(100),
  issue_id Bigint NOT NULL,
  image_url Longtext,
  thumbnail_url Longtext,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the image details for issues'
;

CREATE INDEX issimg_idx_issueid USING BTREE ON reportaspotdev.issue_images (issue_id)
;

-- Table reportaspotdev.issue_user_notification_ref

CREATE TABLE reportaspotdev.issue_user_notification_ref
(
  id Bigint NOT NULL AUTO_INCREMENT,
  is_device Tinyint(1),
  is_email Tinyint(1),
  is_sms Tinyint(1),
  issue_id Bigint NOT NULL,
  user_id Varchar(30) NOT NULL,
  is_push_notification Tinyint(1),
  notify_option_type Int NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the notification settings for a user and an issue'
;

CREATE INDEX issusrnotref_idx_usrid USING BTREE ON reportaspotdev.issue_user_notification_ref (user_id)
;

CREATE INDEX issusrnotref_idx_issueid USING BTREE ON reportaspotdev.issue_user_notification_ref (issue_id)
;

-- Table reportaspotdev.issue_user_spam

CREATE TABLE reportaspotdev.issue_user_spam
(
  id Bigint NOT NULL AUTO_INCREMENT,
  creation_date Datetime NOT NULL,
  issue_id Bigint NOT NULL,
  user_id Varchar(30) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the information about the user who marks the issue as spam'
;

CREATE INDEX issusrspam_idx_usrid USING BTREE ON reportaspotdev.issue_user_spam (user_id)
;

CREATE INDEX issusrspam_idx_issueid USING BTREE ON reportaspotdev.issue_user_spam (issue_id)
;

-- Table reportaspotdev.issue_user_support

CREATE TABLE reportaspotdev.issue_user_support
(
  id Bigint NOT NULL AUTO_INCREMENT,
  creation_date Datetime NOT NULL,
  issue_id Bigint NOT NULL,
  user_id Varchar(30) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the information about the user who supports or endorse (likes) the issue/incident'
;

CREATE INDEX issusrsupp_idx_usrid USING BTREE ON reportaspotdev.issue_user_support (user_id)
;

CREATE INDEX issusrsupp_idx_issueid USING BTREE ON reportaspotdev.issue_user_support (issue_id)
;

-- Table reportaspotdev.lob_issue_category_ref

CREATE TABLE reportaspotdev.lob_issue_category_ref
(
  id Bigint NOT NULL AUTO_INCREMENT,
  issue_catgory_id Bigint NOT NULL,
  lob_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the relationship between line of business and issue categories. Each line of business can be associated to multiple categories using this table'
;

CREATE INDEX lobisscatref_idx_isscatid USING BTREE ON reportaspotdev.lob_issue_category_ref (issue_catgory_id)
;

CREATE INDEX lobisscatref_idx_lobid USING BTREE ON reportaspotdev.lob_issue_category_ref (lob_id)
;

-- Table reportaspotdev.message_text

CREATE TABLE reportaspotdev.message_text
(
  msg_key Varchar(255) NOT NULL,
  msg_value Varchar(255) NOT NULL
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the key value pairs for various messages configured in the system. These messages are the ones displayed on client applications. The messages contain placeholders for dynamic values and message text'
;

ALTER TABLE reportaspotdev.message_text ADD PRIMARY KEY (msg_key)
;

-- Table reportaspotdev.notification

CREATE TABLE reportaspotdev.notification
(
  id Bigint NOT NULL AUTO_INCREMENT,
  content Longtext NOT NULL,
  creation_date Datetime NOT NULL,
  issue_id Bigint NOT NULL,
  from_Status Varchar(255),
  type Int NOT NULL,
  to_Status Varchar(255),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the notifications associated with an issue. e.g., updating the status, marked as spam. The table is utilized to send notifications for users registered for the same'
;

CREATE INDEX not_idx_issueid USING BTREE ON reportaspotdev.notification (issue_id)
;

-- Table reportaspotdev.outage_notification

CREATE TABLE reportaspotdev.outage_notification
(
  id Bigint NOT NULL AUTO_INCREMENT,
  content Longtext NOT NULL,
  creation_date Datetime NOT NULL,
  outage_number Varchar(255) NOT NULL,
  type Int NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the outage notifications that are not created using ReportASpot framework. This table stores the notification or update provided by tenant application'
;

-- Table reportaspotdev.outage_user_notification_ref

CREATE TABLE reportaspotdev.outage_user_notification_ref
(
  id Bigint NOT NULL AUTO_INCREMENT,
  is_device Tinyint(1),
  is_email Tinyint(1),
  is_push_notification Tinyint(1),
  is_sms Tinyint(1),
  outageNumber Varchar(255),
  user_id Varchar(30) NOT NULL,
  notify_option_type Int NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the information of the users who are registered to receive notifications for issues. '
;

CREATE INDEX outusrnotref_idx_usrid USING BTREE ON reportaspotdev.outage_user_notification_ref (user_id)
;

-- Table reportaspotdev.ras_workflows
CREATE TABLE reportaspotdev.ras_workflows
(
  id Bigint NOT NULL AUTO_INCREMENT,
  description Varchar(1000),
  name Varchar(100),
  interface_name Varchar(100),
  customer_id Bigint NOT NULL,
  workflow_type Enum('CREATE','SEARCH','UPDATE') NOT NULL,
  is_asynchronous Bit(1),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the information of the workflows configured for the customer.'
;

CREATE INDEX raswrkflws_custid USING BTREE ON reportaspotdev.ras_workflows (customer_id)
;

-- Table reportaspotdev.request_track

CREATE TABLE reportaspotdev.request_track
(
  id Bigint NOT NULL AUTO_INCREMENT,
  creation_date Datetime NOT NULL,
  error_code Varchar(255),
  last_modified_time Datetime,
  link_id Bigint,
  request_status Varchar(255) NOT NULL,
  request_type Varchar(255) NOT NULL,
  thread_name Varchar(255),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the ...'
;

-- Table reportaspotdev.async_process_track

CREATE TABLE reportaspotdev.async_process_track
(
  id Bigint NOT NULL AUTO_INCREMENT,
  creation_date Datetime NOT NULL,
  error_code Varchar(255),
  last_modified_time Datetime,
  link_id Bigint,
  process_status Varchar(255) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the ...'
;

-- Table reportaspotdev.user_address

CREATE TABLE reportaspotdev.user_address
(
  id Bigint NOT NULL AUTO_INCREMENT,
  city Varchar(255) NOT NULL,
  country_code Varchar(255),
  house_number Varchar(255) NOT NULL,
  state Varchar(255) NOT NULL,
  street Varchar(255),
  zip_code Varchar(255) NOT NULL,
  user_id Varchar(30) NOT NULL,
  address_label Varchar(255),
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the addresses for users. A user may have multple addresses and report incidents for multiple address at the same point in time'
;

CREATE INDEX usradd_idx_usrid USING BTREE ON reportaspotdev.user_address (user_id)
;

-- Table reportaspotdev.user_roles_lob_ref

CREATE TABLE reportaspotdev.user_roles_lob_ref
(
  id Bigint NOT NULL AUTO_INCREMENT,
  lob_id Bigint NOT NULL,
  user_role_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the relationship between user and lines of businesses. Each user role will have access to issues associated with certain lines of businesses and its information is stored in this table'
;

CREATE INDEX usrrollobref_idx_usrrolid USING BTREE ON reportaspotdev.user_roles_lob_ref (user_role_id)
;

CREATE INDEX usrrollobref_idx_lobid USING BTREE ON reportaspotdev.user_roles_lob_ref (lob_id)
;

-- Table reportaspotdev.user_roles_region_ref

CREATE TABLE reportaspotdev.user_roles_region_ref
(
  id Bigint NOT NULL AUTO_INCREMENT,
  region_id Bigint NOT NULL,
  user_role_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the relationship between user roles and regions. Each user role may have access to certain service areas '
;

CREATE INDEX usrolregref_idx_usrrolid USING BTREE ON reportaspotdev.user_roles_region_ref (user_role_id)
;

CREATE INDEX usrolregref_idx_regid USING BTREE ON reportaspotdev.user_roles_region_ref (region_id)
;

-- Create relationships section -------------------------------------------------

ALTER TABLE reportaspotdev.admin ADD CONSTRAINT fk_admin_customerid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.admin ADD CONSTRAINT fk_admin_userid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.admin ADD CONSTRAINT fk_admin_usrroleid FOREIGN KEY (user_role_id) REFERENCES reportaspotdev.user_role (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.admin_alert ADD CONSTRAINT fk_admalrt_admid FOREIGN KEY (admin_id) REFERENCES reportaspotdev.admin (login_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.admin_alert ADD CONSTRAINT fk_admalrt_isscatid FOREIGN KEY (issue_category_id) REFERENCES reportaspotdev.issue_category_ms (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.api_key_management ADD CONSTRAINT fk_apikeymgmt_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.customer ADD CONSTRAINT fk_cust_cityid FOREIGN KEY (city_id) REFERENCES reportaspotdev.city (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.customer ADD CONSTRAINT fk_cust_custtype_id FOREIGN KEY (customer_type_id) REFERENCES reportaspotdev.customer_type (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.customer_category_custom_field ADD CONSTRAINT fk_custcatcf_issuecatid FOREIGN KEY (issue_category_id) REFERENCES reportaspotdev.issue_category_ms (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue ADD CONSTRAINT fk_issue_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue ADD CONSTRAINT fk_issue_assid FOREIGN KEY (assignee_id) REFERENCES reportaspotdev.admin (login_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue ADD CONSTRAINT fk_issue_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue ADD CONSTRAINT fk_issue_isscatid FOREIGN KEY (issue_category_id) REFERENCES reportaspotdev.issue_category_ms (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue ADD CONSTRAINT fk_issue_rgnid FOREIGN KEY (region_id) REFERENCES reportaspotdev.region (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue ADD CONSTRAINT fk_issue_lobid FOREIGN KEY (lob_id) REFERENCES reportaspotdev.lines_of_business (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_audit ADD CONSTRAINT fk_issadt_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_defass FOREIGN KEY (default_assignee) REFERENCES reportaspotdev.user_role (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_createisswrkflw FOREIGN KEY (create_issue_workflow) REFERENCES reportaspotdev.ras_workflows (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_searchisswrkflw FOREIGN KEY (search_issue_workflow) REFERENCES reportaspotdev.ras_workflows (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_updateisswrkflw FOREIGN KEY (update_issue_workflow) REFERENCES reportaspotdev.ras_workflows (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_comments ADD CONSTRAINT fk_isscomm_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_comments ADD CONSTRAINT fk_isscomm_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_custom_field_ref ADD CONSTRAINT fk_isscfref_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_custom_field_ref ADD CONSTRAINT fk_isscfref_cfid FOREIGN KEY (custom_field_id) REFERENCES reportaspotdev.customer_category_custom_field (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_images ADD CONSTRAINT fk_issimg_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_user_notification_ref ADD CONSTRAINT fk_issusrnotref_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_user_notification_ref ADD CONSTRAINT fk_issusrnotref_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_user_spam ADD CONSTRAINT fk_issusrspam_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_user_spam ADD CONSTRAINT fk_issusrspam_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_user_support ADD CONSTRAINT fk_issusrsupp_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_user_support ADD CONSTRAINT fk_issusrsupp_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.lines_of_business ADD CONSTRAINT fk_lob_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.lob_issue_category_ref ADD CONSTRAINT fk_lobisscatref_lobid FOREIGN KEY (lob_id) REFERENCES reportaspotdev.lines_of_business (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.lob_issue_category_ref ADD CONSTRAINT fk_lobisscatref_isscatid FOREIGN KEY (issue_catgory_id) REFERENCES reportaspotdev.issue_category_ms (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.notification ADD CONSTRAINT fk_notf_issueid FOREIGN KEY (issue_id) REFERENCES reportaspotdev.issue (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.outage_user_notification_ref ADD CONSTRAINT fk_outusrnotref_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.ras_workflows ADD CONSTRAINT fk_raswrkflws_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.region ADD CONSTRAINT fk_region_parentid FOREIGN KEY (PARENT_ID) REFERENCES reportaspotdev.region (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.region ADD CONSTRAINT fk_region_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.user_address ADD CONSTRAINT fk_usradd_usrid FOREIGN KEY (user_id) REFERENCES reportaspotdev.user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.user_role ADD CONSTRAINT fk_usrrole_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.user_roles_lob_ref ADD CONSTRAINT fk_usrrollobref_lobid FOREIGN KEY (lob_id) REFERENCES reportaspotdev.lines_of_business (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.user_roles_lob_ref ADD CONSTRAINT fk_usrrollobref_usrrolid FOREIGN KEY (user_role_id) REFERENCES reportaspotdev.user_role (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.user_roles_region_ref ADD CONSTRAINT fk_usrolregref_regid FOREIGN KEY (region_id) REFERENCES reportaspotdev.region (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.user_roles_region_ref ADD CONSTRAINT fk_usrolregref_usrrolid FOREIGN KEY (user_role_id) REFERENCES reportaspotdev.user_role (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;


