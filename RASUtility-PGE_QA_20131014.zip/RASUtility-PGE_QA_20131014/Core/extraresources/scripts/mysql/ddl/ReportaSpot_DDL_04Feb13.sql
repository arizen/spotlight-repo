ALTER TABLE reportaspotdev.customer_category_custom_field DROP FOREIGN KEY custcatcf_idx_custcatid;

ALTER TABLE reportaspotdev.customer_category_custom_field DROP COLUMN customer_category_id;

ALTER TABLE reportaspotdev.customer_category_custom_field ADD COLUMN issue_category_id BIGINT NOT NULL;

CREATE INDEX custcatcf_idx_issuecatid USING BTREE ON reportaspotdev.customer_category_custom_field (issue_category_id)
;

drop table customer_issue_category_ref;

ALTER TABLE reportaspotdev.issue_category_ms ADD COLUMN customer_id BIGINT NOT NULL;

CREATE INDEX isscatms_idx_custid USING BTREE ON reportaspotdev.issue_category_ms (customer_id)
;

ALTER TABLE reportaspotdev.customer_category_custom_field ADD CONSTRAINT fk_custcatcf_issuecatid FOREIGN KEY (issue_category_id) REFERENCES reportaspotdev.issue_category_ms (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;