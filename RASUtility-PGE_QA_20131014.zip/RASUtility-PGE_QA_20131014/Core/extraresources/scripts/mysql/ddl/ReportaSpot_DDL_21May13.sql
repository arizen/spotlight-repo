ALTER TABLE ras_user ADD COLUMN ras_user_name VARCHAR(50) NULL AFTER customer_account_id;

ALTER TABLE ras_user ADD COLUMN ras_password VARCHAR(500) NULL AFTER ras_user_name;

CREATE TABLE user_account
(
  account_number Varchar(50) NOT NULL,
  account_name Varchar(50),
  account_address Varchar(500),
  account_type Varchar(20),
  user_id Varchar(30) NOT NULL,
 PRIMARY KEY (account_number)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the information about the user who marks the issue as spam'
;

CREATE INDEX user_account_idx_usrid USING BTREE ON user_account (user_id)
;
ALTER TABLE user_account ADD CONSTRAINT fk_user_account_usrid FOREIGN KEY (user_id) REFERENCES ras_user (email_id) ON DELETE RESTRICT ON UPDATE RESTRICT
;