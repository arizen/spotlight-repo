CREATE TABLE reportaspotdev.async_process_track
(
  id Bigint NOT NULL AUTO_INCREMENT,
  creation_date Datetime NOT NULL,
  error_code Varchar(255),
  last_modified_time Datetime,
  link_id Bigint,
  process_status Varchar(255) NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the ...'
;