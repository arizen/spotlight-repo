ALTER TABLE `issue_category_ms`
	ADD COLUMN `allow_annonymous_report` BIT(1) NULL AFTER `customer_id`;
	
UPDATE `customer_category_custom_field` SET `xml_tag_name`='trId' WHERE  `xml_tag_name`='outageNumber';

UPDATE `customer_category_custom_field` SET `xml_tag_name`='appointmentId' WHERE  `xml_tag_name`='fieldOrderID';