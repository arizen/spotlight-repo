DROP TABLE reportaspotdev.ras_groovy_files;

CREATE TABLE reportaspotdev.ras_workflows
(
  id Bigint NOT NULL AUTO_INCREMENT,
  description Varchar(1000),
  name Varchar(100),
  interface_name Varchar(100),
  customer_id Bigint NOT NULL,
 PRIMARY KEY (id)
) ENGINE = InnoDB
  ROW_FORMAT = Compact
  COMMENT = 'ReportaSpot: This tables stores the information of the workflows configured for the customer.'
;

CREATE INDEX raswrkflws_custid USING BTREE ON reportaspotdev.ras_workflows (customer_id)
;

ALTER TABLE reportaspotdev.ras_workflows ADD CONSTRAINT fk_raswrkflws_custid FOREIGN KEY (customer_id) REFERENCES reportaspotdev.customer (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;

ALTER TABLE reportaspotdev.issue_category_ms ADD COLUMN create_issue_workflow BIGINT NULL;

CREATE INDEX isscatms_idx_createisswrkflw USING BTREE ON reportaspotdev.issue_category_ms (create_issue_workflow)
;

ALTER TABLE reportaspotdev.issue_category_ms ADD CONSTRAINT fk_isscatms_createisswrkflw FOREIGN KEY (create_issue_workflow) REFERENCES reportaspotdev.ras_workflows (id) ON DELETE RESTRICT ON UPDATE RESTRICT
;