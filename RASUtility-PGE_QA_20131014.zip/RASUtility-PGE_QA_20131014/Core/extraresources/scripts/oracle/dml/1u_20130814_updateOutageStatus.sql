INSERT INTO SPOTLIGHT_MESSAGE_TEXT (msg_key, msg_value) VALUES	('search.report.outagestatus.outageConfirmed', 'Known Area Outage');


delete from OMS_OUTAGE_STATUS;
-- Insert into Outage Status--
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Awaiting Trouble Man','PG'||'&'||'E has assigned a crew to assess the outage.','0');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Trouble Man enroute','PG'||'&'||'E assessment crew is en route to the outage location.','1');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Trouble man on site','PG'||'&'||'E is assessing the cause at the outage location.','2');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Awaiting repair crew','PG'||'&'||'E is sending a repair crew to the outage location.','3');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Crew enroute','PG'||'&'||'E repair crew is en route to the outage location.','4');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Crew on site','PG'||'&'||'E repair crew is on-site working to restore power.','5');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('No Access','PG'||'&'||'E is unable to access the affected equipment at this time.','7');

--Insert into Outage Cause
delete from OMS_OUTAGE_CAUSE;
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('UNKNOWN','Unknown - PG'||'&'||'E will be assessing the cause.','0');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('BRKN POLE EQUIPMNT','Found damaged equipment on a power pole in your area  ','1');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('CB/LR OPN','Equipment damage causing widespread outage.','2');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FU BLWN BRKN','Equipment damage causing widespread outage.','3');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('TREE CONTACT','Trees are in contact with electrical equipment.','4');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('BRKN POLE','Found a broken pole in your area','5');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('CAR POLE','A vehicle has hit a power pole.','6');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FIRE','Fire in the area.','7');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('REPAIR WIRE DWN','Field personnel have found a downed power line.','9');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('REPLCE TXFMR','There is a problem with the transformer.','10');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('BRKN UG EQUIPMNT','Found damage to underground equipment.','11');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('TRNSMISSN OR SUBSTN','Main transmission line or substation problem causing widespread outage.','12');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('NG CONNECTION','Field personnel have found a connection in need of repair.','13');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('PATROLLING','Unknown - PG'||'&'||'E is investigating the cause.','14');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('PLANND SHTDWN','Planned maintenance in the area.','15');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('STORM WIND RAIN','Severe weather in the area.','16');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('REPLCE SRVC','Field personnel have found damage on the service line.','17');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('ROTATING BLOCK','Temporary electric service interruption due to rolling blackouts.','18');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FOREIGN OBJ','A foreign object caused the outage.','19');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('NOT AN OUTAGE','This is a test of our outage system.','20');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('POLE FIRE','Found a damaged power pole in the area.','21');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('OVRLD TXFMR','There is a transformer overload.','22');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('THRD PARTY','Found damaged equipment.','23');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FLOOD','Unable to safely assess damage due to flooding.','24');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('LGHTNING','Lightning in the area.','25');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('SNOW','Severe winter weather in the area.','26');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('EMERG REPAIRS','Unplanned emergency repairs.','27');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('STORM HEAT','Heat related conditions in the area.','28');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('STORM SNOW','Unable to safely assess damage due to snow.','29');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('DAMGE UG CABLE','Found damage to an underground power cable.','30');

commit;