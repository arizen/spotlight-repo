INSERT INTO global_property_key_value (global_key, global_value, show_on_ui, ui_display_name, is_editable_on_ui, possible_values, ui_control_type, ui_id) VALUES	('ras.create.issue.geofencing.enabled', '1', 1, 'Geofencing Enabled(0/1)', 1, NULL, NULL, NULL);
INSERT INTO global_property_key_value (global_key, global_value, show_on_ui, ui_display_name, is_editable_on_ui, possible_values, ui_control_type, ui_id) VALUES	('ras.create.issue.checkdigit.enabled', '1', 1, 'Enables/Disables Check digit check(0/1)', 1, NULL, NULL, NULL);

commit;