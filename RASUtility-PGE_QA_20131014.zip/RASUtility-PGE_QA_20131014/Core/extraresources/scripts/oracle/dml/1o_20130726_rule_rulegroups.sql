--SPOTLIGHT_RULE_GROUP
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('GLOBAL','user.accounts.custom.all.retrieve.rules.globalrulefailed');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('INELIGIBLE_TO_PAY','user.accounts.custom.all.retrieve.rules.ineligibletopay');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('SONP','user.accounts.custom.all.retrieve.rules.sonp');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('NO_STATEMENTS','user.accounts.custom.all.retrieve.rules.nostatements');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('PAYMENTS_PENDING','user.accounts.custom.all.retrieve.rules.pendingpayments');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('RECURRING_PAYMENT_APS','user.accounts.custom.all.retrieve.rules.recurringpaymentsAPS');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,MESSAGE_KEY) values ('OTHERS','user.accounts.custom.all.retrieve.rules.others');


-- SPOTLIGHT_USER_ACCOUNT_RULE
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('100','Password account','GLOBAL');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('124','Fraud','GLOBAL');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('104','Closed account with no balance','INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('106','RTM in the last 30 days','INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('135','2 RTMs in last 365 days','INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('152','Bankruptcy','INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('118','Automatic Payment Setup (APS)','RECURRING_PAYMENT_APS');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('103','SONP','SONP');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('186','Large Customer','OTHERS');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('Pending','Pending Payments','PAYMENTS_PENDING');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('Recurring','Recurring Payments','RECURRING_PAYMENT_APS');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('NO_STATEMENTS','No Statements','NO_STATEMENTS');
commit;