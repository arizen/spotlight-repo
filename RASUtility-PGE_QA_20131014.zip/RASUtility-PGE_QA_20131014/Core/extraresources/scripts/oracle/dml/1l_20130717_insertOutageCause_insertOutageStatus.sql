--Insert into Global Property for new generic workflow for user accounts.
INSERT INTO global_property_key_value (global_key, global_value, show_on_ui, ui_display_name, is_editable_on_ui, possible_values, ui_control_type, ui_id) VALUES	('ras.workflows.custom.user.accounts.details.all', 'accountBillSummaryGenericWorkFlowGateway', 1, 'Custom User Account Details Workflow', 0, NULL, NULL, NULL);

delete from OMS_OUTAGE_STATUS;
-- Insert into Outage Status--
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Awaiting Trouble Man','We received your outage notification and are assessing it.','0');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Trouble Man enroute','We received your outage notification and are assessing it.','1');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Trouble man on site','We are on-site determining the cause of the outage','2');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Awaiting repair crew','We are on-site determining the cause and time to restore power','3');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Crew enroute','Our crew is en route to repair the outage and restore power','4');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('Crew on site','Our crew is onsite working to restore power','5');
Insert into OMS_OUTAGE_STATUS (STATUS_KEY,STATUS_MSG,OIS_STATUS_KEY) values ('No Access','We are unable to access the affected equipment. Please call us at 1-800-743-5002 to gain access','7');

--Insert into Outage Cause
delete from OMS_OUTAGE_CAUSE;
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('UNKNOWN','PG'||'&'||'E will be assessing the cause of your outage','0');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('PATROLLING','PG'||'&'||'E is investigating the cause of your outage','14');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('CB/LR OPN','There is a widespread outage in your area and PG'||'&'||'E is investigating ','2');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FU BLWN BRKN','There is a widespread outage in your area and PG'||'&'||'E is investigating','3');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('REPAIR WIRE DWN','Field personnel have found a power line down','9');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('TREE CONTACT','Trees are causing outages in your area  ','4');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('BRKN POLE EQUIPMNT','Found damaged equipment on a power pole in your area  ','1');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('BRKN POLE','Found a broken pole in your area ','5');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('REPLCE TXFMR','A transformer needs to be replaced','10');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('DAMGE UG CABLE','Found damage to an underground power cable','30');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('BRKN UG EQUIPMNT','Found damage to underground equipment in your area  ','11');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FOREIGN OBJ','A foreign object has been identified as the cause of your outage  ','19');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('NG CONNECTION','Field personnel have found a connection that needs to be repaired','13');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('REPLCE SRVC','Field personnel have found damage on the service line to your premise(s)','17');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('CAR POLE','A vehicle has hit a power pole in your vicinity  ','6');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FIRE','Fire in area, causing outages','7');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('POLE FIRE','Found damage to a pole in your area  ','21');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('OVRLD TXFMR','Your outage has been caused by a problem with a transformer ','22');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('THRD PARTY','Damage to PG'||'&'||'E equipment has caused an outage in your area ','23');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('PLANND SHTDWN','Your outage is due to planned maintenance work that we are performing in your area ','15');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('TRNSMISSN OR SUBSTN','Interruption to a main transmission lines or substations causing widespread outage','12');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('FLOOD','Flooding is limiting our ability to safely assess damage and restore power','24');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('LGHTNING','Lightning caused outages','25');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('SNOW','Your outage has been caused by snow conditions  ','26');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('EMERG REPAIRS','Unplanned, necessary emergency work is being performed','27');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('STORM HEAT','Heat related conditions are causing outages in your area','28');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('STORM WIND RAIN','The current storm or emergency procedures are causing multiple outages in your area  ','16');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('STORM SNOW','Snow conditions are limiting our ability to safely assess damage and restore power','29');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('ROTATING BLOCK','During this emergency, electric service is being temporarily interrupted to your area.','18');
Insert into OMS_OUTAGE_CAUSE (CAUSE_KEY,CAUSE_MSG,OIS_CAUSE_NO) values ('NOT AN OUTAGE','This outage was caused by a test or is an erroneous outage.','20');
commit;
