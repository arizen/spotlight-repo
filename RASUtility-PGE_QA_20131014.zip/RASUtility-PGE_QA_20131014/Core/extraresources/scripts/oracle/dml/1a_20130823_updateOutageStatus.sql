
UPDATE OMS_OUTAGE_CAUSE SET  CAUSE_MSG = 'Found damaged equipment on a power pole.' WHERE CAUSE_KEY = 'BRKN POLE EQUIPMNT';
UPDATE OMS_OUTAGE_CAUSE SET  CAUSE_MSG = 'Found a broken power pole in the area.' WHERE CAUSE_KEY = 'BRKN POLE';
commit;