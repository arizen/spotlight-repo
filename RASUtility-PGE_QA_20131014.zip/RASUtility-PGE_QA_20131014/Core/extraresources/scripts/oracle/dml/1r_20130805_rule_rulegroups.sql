insert into spotlight_rule_group(group_name, message_key) values ('LARGE_CUSTOMER','user.accounts.custom.all.retrieve.rules.largecustomer');
update spotlight_user_account_rule set user_account_rule_group = 'LARGE_CUSTOMER' where rule_key = '186';


INSERT INTO global_property_key_value (global_key, global_value, show_on_ui, ui_display_name, is_editable_on_ui, possible_values, ui_control_type, ui_id) VALUES	('ras.workflows.custom.user.accounts.payments.create', 'pge.kubra.createPaymentGenericWorkFlowGateway', 1, 'Create payments Bean Workflow', 0, NULL, NULL, NULL);
commit;