INSERT INTO ISSUE_CATEGORY_CUSTFIELD (id, column_type, custom_field_name, is_mandatory, is_visible_on_display, is_visible_on_form, possible_values, title, ui_control_type, xml_tag_name, issue_category_id, version, service_type) VALUES (103, 'BOOLEAN', 'REPORT OUTAGE-NOTIFY AFTER HOURS',0,1,1, '1;0', 'REPORT OUTAGE-NOTIFY AFTER HOURS', 'DROP_DOWN', 'rptOutNotifyAfterHrs', 8, '1.0', 'CREATE_REQ');
update ISSUE_CATEGORY_CUSTFIELD set is_mandatory = 0 where id =80;
update ISSUE_CATEGORY_CUSTFIELD set is_mandatory = 0 where id =81;
commit;