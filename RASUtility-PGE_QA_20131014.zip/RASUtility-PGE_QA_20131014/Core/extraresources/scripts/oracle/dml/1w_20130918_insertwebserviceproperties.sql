Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('OutageNotificationCreate','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',40000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('OutageStatusRetrieve','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',40000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('OutageReport','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',40000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('PaymentAccountCreate','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',60000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('PaymentCreate','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',40000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('AccountBillSummaryRetrieve','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',180000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('PaymentListRetrieve','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',60000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('AccountProfileRetrieve','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',180000);
Insert into SPOTLIGHT_WEBSERVICE_PROPS (NAME,URL,HTTP_TIMEOUT) values ('PaymentAccountListRetrieve','https://itapposbqa01.comp.pge.com:8006/ei.customer.mobile/CustomerServiceMobile',180000);

commit;


