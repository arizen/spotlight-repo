CREATE TABLE "SPOTLIGHT_CITY_ZIP_MAP" 
   (
    zip VARCHAR2(20 BYTE), 
	type VARCHAR2(50 BYTE),
	primary_city VARCHAR2(50 BYTE), 
	county VARCHAR2(50 BYTE), 
	latitude FLOAT(126), 
	longitude FLOAT(126),
	estimated_population NUMBER(24,0), 
	notes VARCHAR2(100 BYTE)
);
