create or replace sequence OMS_OUTAGE_DEVICE_UID_SEQUENCE 
start with 1000 
increment by 1 
nomaxvalue; 

CREATE OR REPLACE trigger OMS_OUT_DEV_INS_TRIGGER
before insert on OMS_OUTAGE_DEVICE
for each row
begin
select OMS_OUTAGE_DEVICE_UID_SEQUENCE.nextval into :new.ID from dual;
end;
