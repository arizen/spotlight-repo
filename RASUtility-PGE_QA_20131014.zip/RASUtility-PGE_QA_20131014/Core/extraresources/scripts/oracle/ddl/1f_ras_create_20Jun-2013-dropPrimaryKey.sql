-----------------------------------------------------------------------
-- Dropping primary key contraint on device id from OMS_OUTAGE_DEVICE
--------------------------------------------------------------------------

  DELETE from "OMS_OUTAGE_DEVICE";
  
  COMMIT;
  
  ------------------------
  -- Drop primary key manually using below query. Replace constraint name by name in your database. ----- 
  
  ----ALTER TABLE "OMS_OUTAGE_DEVICE" drop CONSTRAINT <constraint-name>;---
  -----------------------------
  
  ALTER TABLE "OMS_OUTAGE_DEVICE" add ID NUMBER;
  
  ALTER TABLE "OMS_OUTAGE_DEVICE" ADD CONSTRAINT "OUTAGE_DEVICE_PK" PRIMARY KEY ("ID")
  
  ALTER TABLE "OMS_OUTAGE_DEVICE" MODIFY ("ID" NOT NULL ENABLE);
  
  commit;