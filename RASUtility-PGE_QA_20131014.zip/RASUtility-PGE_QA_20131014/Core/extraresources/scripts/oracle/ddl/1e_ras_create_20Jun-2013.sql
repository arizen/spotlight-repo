--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_CAUSE
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_CAUSE" 
   (	
   	"CAUSE_KEY" VARCHAR2(100 BYTE),
   	"CAUSE_MSG" VARCHAR2(255 BYTE)
   ) 
;
  
--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_STATUS
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_STATUS" 
   (	
   	"STATUS_KEY" VARCHAR2(100 BYTE),
   	"STATUS_MSG" VARCHAR2(255 BYTE)
   ) 
;

--------------------------------------------------------
--  DDL for Index OMS_OUTAGE_CAUSE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "OMS_OUTAGE_CAUSE_PK" ON "OMS_OUTAGE_CAUSE" ("CAUSE_KEY") 
;
  
--------------------------------------------------------
--  DDL for Index OMS_OUTAGE_STATUS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "OMS_OUTAGE_STATUS_PK" ON "OMS_OUTAGE_STATUS" ("STATUS_KEY") 
;
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_CAUSE
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_CAUSE" ADD PRIMARY KEY ("CAUSE_KEY")
  ALTER TABLE "OMS_OUTAGE_CAUSE" MODIFY ("CAUSE_KEY" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_CAUSE" MODIFY ("CAUSE_MSG" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_STATUS
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_STATUS" ADD PRIMARY KEY ("STATUS_KEY")
  ALTER TABLE "OMS_OUTAGE_STATUS" MODIFY ("SNABLE);
  ALTER TABLE "OMS_OUTAGE_STATUS" MODIFY ("STATUS_MSG" NOT NULL ENABLE);