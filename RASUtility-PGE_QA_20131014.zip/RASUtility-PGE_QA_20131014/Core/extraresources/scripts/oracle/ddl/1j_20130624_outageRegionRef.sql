-- Rename gis_outages_region table to gis_regions --
ALTER TABLE gis_outages_region RENAME TO gis_regions;

--------------------------------------------------------
--  DDL for Table OMS_OUTAGES_REGIONS
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGES_REGIONS" 
   (	"ID" NUMBER(24,0), 
	"OUTAGE_ID" NUMBER(24,0), 
	"OUTAGE_REGION_ID" NUMBER(24,0)
   ) 
;
  
--------------------------------------------------------
--  DDL for Index OMS_OUT_REGION_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OMS_OUT_REGION_PK_IDX" ON "OMS_OUTAGES_REGIONS" ("ID") 
;
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGES_REGIONS
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGES_REGIONS" ADD CONSTRAINT "OMS_OUT_REGION_PK" PRIMARY KEY ("ID")
 
  ALTER TABLE" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "OMS_OUTAGES_REGIONS" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "OMS_OUTAGES_REGIONS" MODIFY ("OUTAGE_REGION_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table OMS_OUTAGES_REGIONS
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGES_REGIONS" ADD CONSTRAINT "OMS_OUT_REGION_GIS_REG_FK" FOREIGN KEY ("OUTAGE_REGION_ID")
	  REFERENCES "GIS_REGIONS" ("ID") ENABLE;
  ALTER TABLE "OMS_OUTAGES_REGIONS" ADD CONSTRAINT "OMS_OUT_REGION_OUTAGE_FK" FOREIGN KEY ("OUTAGE_ID")
	  REFERENCES "OMS_CURRENT_OUTAGES" ("OUTAGE_ID") ENABLE;

-- Dropping column city, zip, county from OMS_CURRENT_OUTAGES --
	  ALTER TABLE OMS_CURRENT_OUTAGES DROP (city, zip, county);

commit;