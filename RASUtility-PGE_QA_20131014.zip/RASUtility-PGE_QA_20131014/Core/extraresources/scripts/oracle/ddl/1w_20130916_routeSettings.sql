CREATE TABLE spotlight_route_settings
   (
    ID NUMBER(24,0) NOT NULL, 
    event_type VARCHAR2(256 BYTE),
    name VARCHAR2(50 BYTE),
    throttling NUMBER,
    throttle_rate NUMBER,
    throttle_period NUMBER,
    is_asynchronous INTEGER,
    CONSTRAINT "SPOTLIGHT_ROUTE_SETTINGS_PK" PRIMARY KEY ("ID")
);


commit;