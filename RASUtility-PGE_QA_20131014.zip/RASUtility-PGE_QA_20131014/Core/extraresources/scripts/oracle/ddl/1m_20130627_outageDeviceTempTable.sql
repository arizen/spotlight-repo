--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_DEVICE_TMP
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_DEVICE_TMP" 
   ( "ID" NUMBER,	
   "DEVICE_ID" VARCHAR2(100 BYTE), 
	"DEVICE_NAME" VARCHAR2(100 BYTE),
	"LATITUDE" FLOAT(126), 
	"LONGITUDE" FLOAT(126),
	"CIRCUIT_ID" VARCHAR2(100 BYTE),
	"OUTAGE_ID" NUMBER(10,0),
	"DEVICE_TYPE_ID" NUMBER(10,0)
   ) 
 ;
   
--------------------------------------------------------
--  DDL for Index OUTAGE_DEVICE__TMP_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OUTAGE_DEVICE__TMP_PK_IDX" ON "OMS_OUTAGE_DEVICE_TMP" ("ID") 
;

--------------------------------------------------------
--  DDL for Index OUT_DEV__TMP_IDX_DEVTYPE_ID
--------------------------------------------------------

  CREATE INDEX "OUT_DEV__TMP_IDX_DEVTYPE_ID" ON "OMS_OUTAGE_DEVICE_TMP" ("DEVICE_TYPE_ID") 
;
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_DEVICE_TMP
--------------------------------------------------------

   ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" ADD CONSTRAINT "OUTAGE_DEVICE_TMP_PK" PRIMARY KEY ("ID")
  ALTER TABLE "" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("DEVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("DEVICE_TYPE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table OMS_OUTAGE_DEVICE_TMP
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" ADD CONSTRAINT "FK_OUTDEV_TMP_DEVTYPEID" FOREIGN KEY ("DEVICE_TYPE_ID")
	  REFERENCES "OMS_DEVICE_TYPE" ("ID") ENABLE;


