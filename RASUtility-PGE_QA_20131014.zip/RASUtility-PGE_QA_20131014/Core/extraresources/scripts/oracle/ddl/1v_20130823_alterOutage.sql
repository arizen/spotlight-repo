alter table OMS_CURRENT_OUTAGES add (IS_REMOTE NUMBER(*,0) default 0 not null);
commit;