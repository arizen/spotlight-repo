var com = {
    wizni : {
        ras : {
            setGlobalVars : function(url, userKey, apiKey, deviceId) {
                
                if(url == null || $.trim(url) == '' ){
                    console.err("URL is not provided or is empty");
                    return;
                }
                
                if(userKey == null || $.trim(userKey) == ''){
                    console.err("UserKey is not provided or is empty");
                    return;
                }
                
                if(apiKey == null || $.trim(apiKey) == ''){
                    console.err("APIkey is not provided or is empty");
                    return;
                }
                
                if(deviceId == null || $.trim(deviceId) == ''){
                    console.err("DeviceId is not provided or is empty");
                    return;
                }
                
                window.reportASpotUrl = url;
                window.reportASpotUserKey = userKey;
                window.reportASpotApiKey = apiKey;
                window.reportASpotdeviceId = deviceId;
            },
            constants : {
                SEARCH_BY_PHONE : '0',
                SEARCH_BY_ACCOUNT : '1',
                SEARCH_BY_ADDRESS : '2',
                NOTIFY_OPTION_TYPE : {
                    ALL_ISSUE_UPDATE : '0',
                    ISSUE_CLOSED : '1',
                    ALL_EXCEPT_CLOSED : '2'
                }
            },
            ServiceIssue : function(category, latitude, longitude, device, customerId, reporter) {
                this.reportId = null;
                this.category = category;
                this.latitude = latitude;
                this.longitude = longitude;
                this.address = null;
                this.description = null;
                this.status = "Open";
                var seconds = parseInt(new Date().getTime() / 1000);
                this.creationDate = seconds;
                this.lastModifiedDate = seconds;
                this.isPublic = "1";
                this.device = device;
                this.customerId = customerId;
                this.reporter = reporter;
                this.customFieldList = null;
                this.detailedAddress = new com.wizni.ras.Address();
                this.images = new Array();
                this.notification = null;
            },
            
            Image : function() {
                this.imageName = null;
                this.imageData = null;
            },
            
            CustomFieldList : function() {
                this.customFields = new Array();
            },
            
            CustomField : function(tagName, value) {
                this.tagName = tagName;
                if (value instanceof Array) {
                    this.value = value.join(";");
                } else {
                    this.value = value;
                }
            },
            
            /**
             * creating a Reporter class
             */
            Reporter : function(emailId) {
                this.emailId = emailId;
                this.firstName = null;
                this.lastName = null;
                this.phoneNumber = null;
                this.apnsKey = null;
                this.account = null;
            },
            
            SearchIssue : function(searchBy, accountNumber, phoneNumber, address, customerId) {
                
                this.category = "Outage";
                this.searchBy = searchBy;
                this.account = accountNumber;
                this.phone = phoneNumber;
                this.address = address;
                this.customerId = customerId;
            },
            
            Address : function(city, zipcode, houseNumber, street, state, countryCode, addressLabel) {
                this.city = city;
                this.zipcode = zipcode;
                this.houseNo = houseNumber;
                this.street = street;
                this.state = state;
                this.countryCode = countryCode;
                this.addressLabel = addressLabel;
            },
            
            Notification : function() {
                this.notificationId = null;
                this.sms = null;
                this.email = null;
                this.localNotification = null;
                this.pushNotification = null;
                this.notificationTime = null;
                this.text = null;
                this.reportId = null;
                this.notificationType = null;
                this.fromStatus = null;
                this.toStatus = null;
                this.issueTitle = null;
                this.notifyOption = null;
            },
            
            RegisterUserRequest : function() {
                this.reporter = new com.wizni.ras.Reporter();
            },
            
            SupportIssueRequest : function() {
                this.reportId = null;
                this.emailAddress = null;
                this.isSupport = null;
            },
            
            SpamIssueRequest : function() {
                this.reportId = null;
                this.emailAddress = null;
            },
            
            AddCommentRequest : function() {
                this.reportId = null;
                this.userId = null;
                this.comment = new com.wizni.ras.Comment();
            },
            
            Comment : function() {
                this.text = null;
                this.date = null;
                this.userId = null;
            },
            
            SubmitIssue : function(report, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/saveIssue?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/saveIssue",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(report),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            searchIssue : function(searchReport, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/searchReport?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/searchReport",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(searchReport),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            uploadImage : function(report, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/addImage?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/addImage",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(report),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            registerNotification : function(report, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/registerNotification?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/registerNotification",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(report),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            unregisterNotification : function(report, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/unregisterNotification?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/unregisterNotification",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(report),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            getMyNotifications : function(emailId, date, customerId, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                
                var strURL = window.reportASpotUrl + "/mobile/services/getMyNotifications?emailId=" + emailId + "&date=" + date
                + "&customerId=" + customerId +"&ts=" + timeStamp;
                $.ajax({
                       type : "GET",
                       url : strURL,
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            getMyIssues : function(emailId, customerId, date, issueId, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                
                var strURL = window.reportASpotUrl + "/mobile/services/getMyIssues?emailId=" + emailId + "&customerId=" + customerId +"&ts=" + timeStamp;
                if (date != null) {
                    strURL = strURL + "&date=" + date;
                }
                if (issueId != null) {
                    strURL = strURL + "&issueId=" + issueId;
                }
                $.ajax({
                       type : "GET",
                       url : strURL,
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            getRecentIssues : function(isAdmin, customerId, date, issueId, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                
                var strURL = window.reportASpotUrl + "/mobile/services/getRecentIssues?customerId=" + customerId +"&ts=" + timeStamp;
                if (isAdmin != null) {
                    strURL = strURL + "&isAdmin=" + isAdmin;
                }
                if (date != null) {
                    strURL = strURL + "&date=" + date;
                }
                if (issueId != null) {
                    strURL = strURL + "&issueId=" + issueId;
                }
                $.ajax({
                       type : "GET",
                       url : strURL,
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            getMyWatchlist : function(emailId, customerId, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                
                var strURL = window.reportASpotUrl + "/mobile/services/getMyWatchlist?customerId=" + customerId + "&emailId=" + emailId +"&ts=" + timeStamp;
                
                $.ajax({
                       type : "GET",
                       url : strURL,
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            registerUser : function(registerUserRequest, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/registerUser?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,// window.reportASpotUrl + "/mobile/services/registerUser",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(registerUserRequest),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            supportIssue : function(supportIssueRequest, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/supportIssue?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/supportIssue",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(registerUserRequest),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            spamIssue : function(spamIssueRequest, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/spamIssue?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/spamIssue",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(registerUserRequest),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            addReportComment : function(addCommentRequest, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                var strURL = window.reportASpotUrl + "/mobile/services/addReportComment?ts="+timeStamp;
                $.ajax({
                       type : "POST",
                       url : strURL,//window.reportASpotUrl + "/mobile/services/addReportComment",
                       contentType : 'application/json',
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       data : JSON.stringify(registerUserRequest),
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                       });
            },
            
            getReport : function(issueId, customerId, successCallbackFunction, errorCallbackFunction) {
                
                if (window.reportASpotUrl == undefined || window.reportASpotUrl == null) {
                    console.error("Please provide a reportaspot URL.");
                    return;
                }
                
                var timeStamp = Math.round(new Date().getTime() / 1000);
                var strToCalculateHash = window.reportASpotApiKey + window.reportASpotdeviceId + timeStamp;
                var finalHash = CryptoJS.SHA512(strToCalculateHash).toString(CryptoJS.enc.Hex);
                
                var strURL = window.reportASpotUrl + "/mobile/services/getReport?customerId=" + customerId + "&issueId=" + issueId +"&ts=" + timeStamp;
                
                $.ajax({
                       type : "GET",
                       url : strURL,
                       crossDomain : true,
                       cache:false,
                       headers : {
                       "SECAPIKEY" : finalHash + ";" + window.reportASpotdeviceId + ";" + timeStamp,
                       "X-RAS-API-USERKEY" : window.reportASpotUserKey,
                       "X-RAS-API-PASSKEY" : window.reportASpotApiKey
                       },
                       datatype : 'json',
                       success : function(data) {
                       successCallbackFunction(data);
                       },
                       error : function(err, textstatus, errorThrown) {
                       errorCallbackFunction(err, textstatus, errorThrown);
                       }
                });
            }
        }
    }
};