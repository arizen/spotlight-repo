delete from issue_comments where issue_comments.issue_id =?;
delete from issue_images where issue_images.issue_id =?;
delete from issue_user_notification_ref where issue_user_notification_ref.issue_id=?;
delete from notification where notification.issue_id =?;
delete from issue_custom_field_ref where issue_custom_field_ref.issue_id=?;
delete from issue where issue.id=?