Spotlight Code Setup Guide.
1) Spotlight Code can be downloaded from https://github.com/wizspark/RASUtility . The branch for Oracle is workingtree.
2) Spotlight needs Java to run. The minimum version supported is 1.6 . Java 1.7 is also supported.
3) Spotlight Development Team use SpringToolSuite(Spring Tool Suite 3.2.0.RELEASE - based on Eclipse Juno 4.2.2) as our default IDE. The download link is http://www.springsource.org/spring-tool-suite-download
   This download includes Maven which is used for building Spotlight Application.
4) Import the Code using SpringToolSuite File > Import > Maven > Existing Maven Projects. Provide the directory where Spotlight code was checked out.
5) Select all projects to be imported.
6)  