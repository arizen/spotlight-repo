QuickStart folder contains all the scripts required for setting the database schema for the first time


Scripts need to be run in a following order.

a.) go to oracle/ddl folder

    - run 1_ras_create.sql
    - run 2_ras_create2_extract.sql
    - run 3_ras_create_3.sql


b.) go to oracle/dml folder

    - run 1_ras_insert.sql
    - run 2_region_insert.sql
    - run 3_region_insert2.sql
    - run 4_ras_insert.sql
    - run 5_ras_insert_global_properties.sql
    - run 7_ras_insert_route_settings.sql
    - run outage_insert.sql

  c.) go to oracle/ddl folder
    - run 4_storedProcedure.sql

  d.) go to oracle/dml/environment folder 
      
      go to specific environment folder (QA/DEV/TEST/PROD)

    - run 6_ras_insert_webservice_properties.sql






