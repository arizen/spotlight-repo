-- GISRegion object type --
CREATE OR REPLACE TYPE GISRegion FORCE as object(
   region_type_id   NUMBER,
      region_name VARCHAR2(100),
      num_outages NUMBER(10, 0),
      customers_effected NUMBER(10, 0),
      gis_latitude FLOAT(126),
      gis_longitude FLOAT(126)
);
/

-- GISRegionsTable table type --
create or replace TYPE GISRegionsTable is table of GISRegion;
/

-- OMS_OUTAGE object type --
CREATE OR REPLACE TYPE OMS_OUTAGE FORCE as object(
   "OUTAGE_ID" NUMBER(10,0), 
    "OUTAGE_EXTENT" VARCHAR2(20), 
    "OUTAGE_DEVICE_ID" VARCHAR2(100), 
    "OUTAGE_DEVICE_NAME" VARCHAR2(100), 
    "OUTAGE_CIRCUIT_ID" VARCHAR2(100), 
    "OUTAGE_START" TIMESTAMP (6), 
    "CREW_ETA" TIMESTAMP (6), 
    "CREW_CURRENT_STATUS" VARCHAR2(100), 
    "AUTO_ETOR" TIMESTAMP (6), 
    "CURRENT_ETOR" TIMESTAMP (6), 
    "OUTAGE_CAUSE" VARCHAR2(100), 
    "EST_CUSTOMERS" NUMBER, 
    "LAST_UPDATE" TIMESTAMP (6), 
    "HAZARD_FLAG" NUMBER, 
    "OUTAGE_LATITUDE" FLOAT(126), 
    "OUTAGE_LONGITUDE" FLOAT(126),
    "CITY" VARCHAR2(100),
    "COUNTY" VARCHAR2(100),
    "ZIP" VARCHAR2(100)
);
/

-- OMS_OUTAGE_TABLE table type --
create or replace TYPE OMS_OUTAGE_TABLE is table of OMS_OUTAGE;
/

-- OMS_OUTAGE_DEVICE object type --
CREATE OR REPLACE TYPE OMS_OUTAGE_DEVICE_TYPE FORCE as object(
   "DEVICE_ID" VARCHAR2(100), 
    "DEVICE_NAME" VARCHAR2(100),
    "LATITUDE" FLOAT(126), 
    "LONGITUDE" FLOAT(126),
    "CIRCUIT_ID" VARCHAR2(100),
    "OUTAGE_ID" NUMBER(10,0),
    "DEVICE_TYPE_ID" NUMBER(10,0)
);
/

-- OMS_OUTAGE_DEVICE_TABLE table type --
create or replace TYPE OMS_OUTAGE_DEVICE_TABLE is table of OMS_OUTAGE_DEVICE_TYPE;
/
-- Stored procedure for refreshing complete outages using temp table for outages in Oracle 11g or above --

create or replace PROCEDURE refresh_Outage_Data_Using_Temp(gis_region_data GISRegionsTable, oms_outage_data OMS_OUTAGE_TABLE, outage_device_data OMS_OUTAGE_DEVICE_TABLE)
AS
    outage_region_id NUMBER(10,0);
BEGIN
    -- deleting references from mapping table --
    delete from OMS_OUTAGES_REGIONS@RAS_CCMO1T;
    commit;
    
    -- deleting regions from gis regions--
    delete from gis_regions@RAS_CCMO1T;
    commit;
    
    -- insert regions in gis regions table --
    for i in 1..gis_region_data.count
    loop
        insert into GIS_REGIONS@RAS_CCMO1T(ID, REGION_NAME, NUM_OUTAGES, CUSTOMERS_EFFECTED, GIS_LATITUDE, GIS_LONGITUDE, REGION_TYPE_ID)
          values(HIBERNATE_SEQUENCE.NEXTVAL@RAS_CCMO1T , gis_region_data(i).region_name, gis_region_data(i).num_outages, gis_region_data(i).customers_effected, 
          gis_region_data(i).gis_latitude, gis_region_data(i).gis_longitude, gis_region_data(i).region_type_id);
     end loop;
    commit;
    
    -- deleting outages from oms_current_outages_tmp --
    delete from oms_current_outages_tmp@RAS_CCMO1T;
    commit;
    
    -- inserting outages in oms_current_outages_tmp --
    for i in 1..oms_outage_data.count
    loop
        insert into OMS_CURRENT_OUTAGES_TMP@RAS_CCMO1T(OUTAGE_ID, OUTAGE_DEVICE_ID, OUTAGE_START, CREW_CURRENT_STATUS, CURRENT_ETOR, OUTAGE_CAUSE, 
            EST_CUSTOMERS, LAST_UPDATE, HAZARD_FLAG, OUTAGE_LATITUDE, OUTAGE_LONGITUDE, OUTAGE_EXTENT, OUTAGE_DEVICE_NAME, OUTAGE_CIRCUIT_ID, CREW_ETA, AUTO_ETOR)
          values(oms_outage_data(i).outage_id, oms_outage_data(i).outage_device_id, oms_outage_data(i).outage_start, 
          oms_outage_data(i).crew_current_status, oms_outage_data(i).current_etor, oms_outage_data(i).outage_cause, oms_outage_data(i).est_customers,
          oms_outage_data(i).last_update, oms_outage_data(i).hazard_flag, oms_outage_data(i).outage_latitude, oms_outage_data(i).outage_longitude,
          oms_outage_data(i).outage_extent, oms_outage_data(i).outage_device_name, oms_outage_data(i).outage_circuit_id, oms_outage_data(i).crew_eta,
          oms_outage_data(i).auto_etor);
     end loop;
    commit;
    
    -- merging temp outages data to oms_current_outages --
    MERGE into oms_current_outages@RAS_CCMO1T d
    USING oms_current_outages_tmp@RAS_CCMO1T dd
    ON (d.outage_id = dd.outage_id)
    WHEN MATCHED
        THEN UPDATE SET d.outage_device_id = dd.outage_device_id, d.outage_start = dd.outage_start, 
          d.crew_current_status = dd.crew_current_status, d.current_etor = dd.current_etor, d.outage_cause = dd.outage_cause, d.est_customers = dd.est_customers,
          d.last_update = dd.last_update, d.hazard_flag = dd.hazard_flag, d.outage_latitude = dd.outage_latitude, d.outage_longitude = dd.outage_longitude,
          d.outage_extent = dd.outage_extent, d.outage_device_name = dd.outage_device_name, d.outage_circuit_id = dd.outage_circuit_id, d.crew_eta = dd.crew_eta,
          d.auto_etor = dd.auto_etor
    WHEN NOT MATCHED THEN
        insert (OUTAGE_ID, OUTAGE_DEVICE_ID, OUTAGE_START, CREW_CURRENT_STATUS, CURRENT_ETOR, OUTAGE_CAUSE, 
            EST_CUSTOMERS, LAST_UPDATE, HAZARD_FLAG, OUTAGE_LATITUDE, OUTAGE_LONGITUDE, OUTAGE_EXTENT, OUTAGE_DEVICE_NAME, OUTAGE_CIRCUIT_ID, CREW_ETA, AUTO_ETOR)
          values(dd.outage_id, dd.outage_device_id, dd.outage_start, 
          dd.crew_current_status, dd.current_etor, dd.outage_cause, dd.est_customers,
          dd.last_update, dd.hazard_flag, dd.outage_latitude, dd.outage_longitude,
          dd.outage_extent, dd.outage_device_name, dd.outage_circuit_id, dd.crew_eta,
          dd.auto_etor);
          
    -- delete records from outages which are not present in temp table --
    delete from oms_current_outages@RAS_CCMO1T where outage_id not in (select outage_id from oms_current_outages_tmp@RAS_CCMO1T);
    commit;
    
    -- inserting reference mapping data --
    for i in 1..oms_outage_data.count
      loop
        IF oms_outage_data(i).city IS NOT NULL THEN
            BEGIN
                select id into outage_region_id from gis_regions@RAS_CCMO1T where region_type_id=1 and region_name=oms_outage_data(i).city;
            
                IF outage_region_id IS NOT NULL THEN
                    insert into oms_outages_regions@RAS_CCMO1T values(HIBERNATE_SEQUENCE.NEXTVAL@RAS_CCMO1T, oms_outage_data(i).outage_id, outage_region_id);
                END IF;
            
                outage_region_id := NULL;
                
                EXCEPTION
                    WHEN no_data_found THEN
                    DBMS_OUTPUT.PUT_LINE('No data found for city - ' || oms_outage_data(i).city);
            END;
        END IF;
        
        IF oms_outage_data(i).county IS NOT NULL THEN
            BEGIN
                select id into outage_region_id from gis_regions@RAS_CCMO1T where region_type_id=2 and region_name=oms_outage_data(i).county;
            
                IF outage_region_id IS NOT NULL THEN
                    insert into oms_outages_regions@RAS_CCMO1T values(HIBERNATE_SEQUENCE.NEXTVAL@RAS_CCMO1T, oms_outage_data(i).outage_id, outage_region_id);
                END IF;
            
                outage_region_id := NULL;
                
                EXCEPTION
                    WHEN no_data_found THEN
                    DBMS_OUTPUT.PUT_LINE('No data found for county - ' || oms_outage_data(i).county);
            END;
        END IF;
        
        IF oms_outage_data(i).zip IS NOT NULL THEN
            BEGIN
                select id into outage_region_id from gis_regions@RAS_CCMO1T where region_type_id=3 and region_name=oms_outage_data(i).zip;
            
                IF outage_region_id IS NOT NULL THEN
                    insert into oms_outages_regions@RAS_CCMO1T values(HIBERNATE_SEQUENCE.NEXTVAL@RAS_CCMO1T, oms_outage_data(i).outage_id, outage_region_id);
                END IF;
            
                outage_region_id := NULL;
                
                EXCEPTION
                    WHEN no_data_found THEN
                    DBMS_OUTPUT.PUT_LINE('No data found for zip - ' || oms_outage_data(i).zip);
            END;
        END IF;
        commit;
       end loop;
       
       -- deleting outage devices from oms_outage_device_tmp --
    delete from oms_outage_device_tmp@RAS_CCMO1T;
    commit;
    
    -- inserting outage devices in oms_outage_device_tmp --
    for i in 1..outage_device_data.count
    loop
        insert into OMS_OUTAGE_DEVICE_TMP@RAS_CCMO1T(ID, DEVICE_ID, LATITUDE, LONGITUDE, OUTAGE_ID, DEVICE_TYPE_ID, DEVICE_NAME, CIRCUIT_ID)         
      values(HIBERNATE_SEQUENCE.NEXTVAL@RAS_CCMO1T , outage_device_data(i).device_id, outage_device_data(i).latitude, outage_device_data(i).longitude, 
      outage_device_data(i).outage_id, outage_device_data(i).device_type_id, outage_device_data(i).device_name, outage_device_data(i).circuit_id);
     end loop;
    commit;
    
    -- merging temp outages data to oms_current_outages --
    MERGE into oms_outage_device@RAS_CCMO1T d
    USING oms_outage_device_tmp@RAS_CCMO1T dd
    ON (d.device_id = dd.device_id)
    WHEN MATCHED
        THEN UPDATE SET d.latitude = dd.latitude, d.longitude = dd.longitude, 
          d.outage_id = dd.outage_id, d.device_type_id = dd.device_type_id, d.device_name = dd.device_name, d.circuit_id = dd.circuit_id
    WHEN NOT MATCHED THEN
        insert (ID, DEVICE_ID, LATITUDE, LONGITUDE, OUTAGE_ID, DEVICE_TYPE_ID, DEVICE_NAME, CIRCUIT_ID)
          values(HIBERNATE_SEQUENCE.NEXTVAL@RAS_CCMO1T , dd.device_id, dd.latitude, dd.longitude, 
              dd.outage_id, dd.device_type_id, dd.device_name, dd.circuit_id);
          
    -- delete records from outage devices which are not present in temp table --
    delete from oms_outage_device@RAS_CCMO1T where device_id not in (select device_id from oms_outage_device_tmp@RAS_CCMO1T);
    commit;
END;
