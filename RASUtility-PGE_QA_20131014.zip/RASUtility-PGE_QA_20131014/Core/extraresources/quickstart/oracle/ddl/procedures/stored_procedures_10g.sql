-- GISRegion object type --
CREATE OR REPLACE TYPE GISRegion as object(
   region_type_id   NUMBER,
      region_name VARCHAR2(100),
      num_outages NUMBER(10, 0),
      customers_effected NUMBER(10, 0),
      gis_latitude FLOAT(126),
      gis_longitude FLOAT(126)
);


-- GISRegionsTable table type --
create or replace TYPE GISRegionsTable is table of GISRegion;

-- Stored procedure for inserting gis regions in Oracle 10g --
create or replace 
PROCEDURE insert_GISRegion(gis_region_data GISRegionsTable)
AS
BEGIN

for i in 1..gis_region_data.count
  loop
    insert into GIS_REGIONS(ID, REGION_NAME, NUM_OUTAGES, CUSTOMERS_EFFECTED, GIS_LATITUDE, GIS_LONGITUDE, REGION_TYPE_ID)         
      values(HIBERNATE_SEQUENCE.NEXTVAL , gis_region_data(i).region_name, gis_region_data(i).num_outages, gis_region_data(i).customers_effected, 
      gis_region_data(i).gis_latitude, gis_region_data(i).gis_longitude, gis_region_data(i).region_type_id);
  end loop;
  commit;
END;

-- OMS_OUTAGE object type --
CREATE OR REPLACE TYPE OMS_OUTAGE as object(
   "OUTAGE_ID" NUMBER(10,0), 
	"OUTAGE_EXTENT" VARCHAR2(20), 
	"OUTAGE_DEVICE_ID" VARCHAR2(100), 
	"OUTAGE_DEVICE_NAME" VARCHAR2(100), 
	"OUTAGE_CIRCUIT_ID" VARCHAR2(100), 
	"OUTAGE_START" TIMESTAMP (6), 
	"CREW_ETA" TIMESTAMP (6), 
	"CREW_CURRENT_STATUS" VARCHAR2(100), 
	"AUTO_ETOR" TIMESTAMP (6), 
	"CURRENT_ETOR" TIMESTAMP (6), 
	"OUTAGE_CAUSE" VARCHAR2(100), 
	"EST_CUSTOMERS" NUMBER, 
	"LAST_UPDATE" TIMESTAMP (6), 
	"HAZARD_FLAG" NUMBER, 
	"OUTAGE_LATITUDE" FLOAT(126), 
	"OUTAGE_LONGITUDE" FLOAT(126),
	"CITY" VARCHAR2(100),
	"COUNTY" VARCHAR2(100),
	"ZIP" VARCHAR2(100)
);

-- OMS_OUTAGE_TABLE table type --
create or replace TYPE OMS_OUTAGE_TABLE is table of OMS_OUTAGE;

-- Stored procedure for inserting outages in Oracle 10g --
create or replace 
PROCEDURE insert_OMS_Outage(oms_outage_data OMS_OUTAGE_TABLE)
AS
	outage_region_id NUMBER(10,0);
BEGIN
  for i in 1..oms_outage_data.count
  loop
    insert into OMS_CURRENT_OUTAGES(OUTAGE_ID, OUTAGE_DEVICE_ID, OUTAGE_START, CREW_CURRENT_STATUS, CURRENT_ETOR, OUTAGE_CAUSE, 
    	EST_CUSTOMERS, LAST_UPDATE, HAZARD_FLAG, OUTAGE_LATITUDE, OUTAGE_LONGITUDE, OUTAGE_EXTENT, OUTAGE_DEVICE_NAME, OUTAGE_CIRCUIT_ID, CREW_ETA, AUTO_ETOR)
      values(oms_outage_data(i).outage_id, oms_outage_data(i).outage_device_id, oms_outage_data(i).outage_start, 
      oms_outage_data(i).crew_current_status, oms_outage_data(i).current_etor, oms_outage_data(i).outage_cause, oms_outage_data(i).est_customers,
      oms_outage_data(i).last_update, oms_outage_data(i).hazard_flag, oms_outage_data(i).outage_latitude, oms_outage_data(i).outage_longitude,
      oms_outage_data(i).outage_extent, oms_outage_data(i).outage_device_name, oms_outage_data(i).outage_circuit_id, oms_outage_data(i).crew_eta,
      oms_outage_data(i).auto_etor);
    commit;
    
    IF oms_outage_data(i).city IS NOT NULL THEN
    	BEGIN
    		select id into outage_region_id from gis_regions where region_type_id=1 and region_name=oms_outage_data(i).city;
    	
    		IF outage_region_id IS NOT NULL THEN
    			insert into oms_outages_regions values(HIBERNATE_SEQUENCE.NEXTVAL, oms_outage_data(i).outage_id, outage_region_id);
    		END IF;
    	
    		outage_region_id := NULL;
    		
    		EXCEPTION
    			WHEN no_data_found THEN
    			DBMS_OUTPUT.PUT_LINE('No data found for city - ' || oms_outage_data(i).city);
    	END;
    END IF;
    
    IF oms_outage_data(i).county IS NOT NULL THEN
    	BEGIN
    		select id into outage_region_id from gis_regions where region_type_id=2 and region_name=oms_outage_data(i).county;
    	
    		IF outage_region_id IS NOT NULL THEN
    			insert into oms_outages_regions values(HIBERNATE_SEQUENCE.NEXTVAL, oms_outage_data(i).outage_id, outage_region_id);
    		END IF;
    	
    		outage_region_id := NULL;
    		
    		EXCEPTION
    			WHEN no_data_found THEN
    			DBMS_OUTPUT.PUT_LINE('No data found for county - ' || oms_outage_data(i).county);
    	END;
    END IF;
    
    IF oms_outage_data(i).zip IS NOT NULL THEN
    	BEGIN
    		select id into outage_region_id from gis_regions where region_type_id=3 and region_name=oms_outage_data(i).zip;
    	
    		IF outage_region_id IS NOT NULL THEN
    			insert into oms_outages_regions values(HIBERNATE_SEQUENCE.NEXTVAL, oms_outage_data(i).outage_id, outage_region_id);
    		END IF;
    	
    		outage_region_id := NULL;
    		
    		EXCEPTION
    			WHEN no_data_found THEN
    			DBMS_OUTPUT.PUT_LINE('No data found for zip - ' || oms_outage_data(i).zip);
    	END;
    END IF;
    
    commit;
   end loop;
END;

-- OMS_OUTAGE_DEVICE object type --
CREATE OR REPLACE TYPE OMS_OUTAGE_DEVICE_TYPE as object(
   "DEVICE_ID" VARCHAR2(100), 
	"DEVICE_NAME" VARCHAR2(100),
	"LATITUDE" FLOAT(126), 
	"LONGITUDE" FLOAT(126),
	"CIRCUIT_ID" VARCHAR2(100),
	"OUTAGE_ID" NUMBER(10,0),
	"DEVICE_TYPE_ID" NUMBER(10,0)
);

-- OMS_OUTAGE_DEVICE_TABLE table type --
create or replace TYPE OMS_OUTAGE_DEVICE_TABLE is table of OMS_OUTAGE_DEVICE_TYPE;

-- Stored procedure for inserting outage devices in Oracle 10g --
create or replace 
PROCEDURE insert_OMS_Outage_Device(outage_device_data OMS_OUTAGE_DEVICE_TABLE)
AS
BEGIN

for i in 1..outage_device_data.count
  loop
    insert into OMS_OUTAGE_DEVICE(ID, DEVICE_ID, LATITUDE, LONGITUDE, OUTAGE_ID, DEVICE_TYPE_ID, DEVICE_NAME, CIRCUIT_ID)         
      values(HIBERNATE_SEQUENCE.NEXTVAL , outage_device_data(i).device_id, outage_device_data(i).latitude, outage_device_data(i).longitude, 
      outage_device_data(i).outage_id, outage_device_data(i).device_type_id, outage_device_data(i).device_name, outage_device_data(i).circuit_id);
  end loop;
  commit;
END;