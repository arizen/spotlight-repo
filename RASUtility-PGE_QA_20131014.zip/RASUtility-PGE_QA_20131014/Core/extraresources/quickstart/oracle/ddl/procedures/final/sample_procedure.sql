
-- Sample to test refresh_Outage_Data_Using_Temp procedure --
Declare
	gis_data GISREGIONSTABLE := GISREGIONSTABLE(GISREGION(1, 'test_city7', 2, 2, 37.749, -120.436),
                                              GISREGION(1, 'test_city8', 2, 2, 37.749, -120.436));
                                              
	outage_data OMS_OUTAGE_TABLE := OMS_OUTAGE_TABLE(OMS_OUTAGE(851128, NULL, NULL, NULL, NULL, to_timestamp( '06/20/2013 10:47:15 AM', 'MM/DD/YYYY HH:MI:SS AM'), NULL, 'Crew On Site', NULL, 
  														to_timestamp( '06/17/2013 03:30:00 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'PLNND SHUTDOWN', 10, 
  														to_timestamp( '06/17/2013 11:37:48 AM', 'MM/DD/YYYY HH:MI:SS AM'), 0, 35.12564, -120.60291, 'test_city7', NULL, NULL),
                                              OMS_OUTAGE(851130, NULL, NULL, NULL, NULL, to_timestamp( '06/19/2013 10:47:15 AM', 'MM/DD/YYYY HH:MI:SS AM'), NULL, 'Crew On Site', NULL, 
  														to_timestamp( '06/17/2013 03:30:00 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'PLNND SHUTDOWN', 8, 
  														to_timestamp( '06/17/2013 11:37:48 AM', 'MM/DD/YYYY HH:MI:SS AM'), 0, 35.12564, -120.60291, 'test_city8', NULL, NULL),
                                              OMS_OUTAGE(851131, NULL, NULL, NULL, NULL, to_timestamp( '06/17/2013 10:47:15 AM', 'MM/DD/YYYY HH:MI:SS AM'), NULL, 'Crew On Site', NULL, 
  														to_timestamp( '06/17/2013 03:30:00 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'PLNND SHUTDOWN', 6, 
  														to_timestamp( '06/17/2013 11:37:48 AM', 'MM/DD/YYYY HH:MI:SS AM'), 0, 35.12564, -120.60291, 'test_city9', NULL, NULL));
	device_data OMS_OUTAGE_DEVICE_TABLE := OMS_OUTAGE_DEVICE_TABLE(OMS_OUTAGE_DEVICE_TYPE(12313, NULL, 57.749, -20.436, NULL, 851128, 1),
                                              OMS_OUTAGE_DEVICE_TYPE(11367, NULL, 57.749, -110.436, NULL, 851130, 1));
Begin
  refresh_Outage_Data_Using_Temp(gis_data, outage_data, device_data);
end;