-- GISRegion object type --
CREATE OR REPLACE TYPE GISRegion as object(
   region_type_id   NUMBER,
      region_name VARCHAR2(100),
      num_outages NUMBER(10, 0),
      customers_effected NUMBER(10, 0),
      gis_latitude FLOAT(126),
      gis_longitude FLOAT(126)
);


-- GISRegionsTable table type --
create or replace TYPE GISRegionsTable is table of GISRegion;

create or replace 
PROCEDURE insert_GISRegion(gis_region_data GISRegionsTable)
AS
BEGIN

for i in 1..gis_region_data.count
  loop
    insert into GIS_REGIONS@CCMO1T(ID, REGION_NAME, NUM_OUTAGES, CUSTOMERS_EFFECTED, GIS_LATITUDE, GIS_LONGITUDE, REGION_TYPE_ID)         
      values(HIBERNATE_SEQUENCE.NEXTVAL@CCMO1T , gis_region_data(i).region_name, gis_region_data(i).num_outages, gis_region_data(i).customers_effected, 
      gis_region_data(i).gis_latitude, gis_region_data(i).gis_longitude, gis_region_data(i).region_type_id);
  end loop;
END;

-- OMS_OUTAGE object type --
CREATE OR REPLACE TYPE OMS_OUTAGE as object(
   "OUTAGE_ID" NUMBER(10,0), 
	"OUTAGE_EXTENT" VARCHAR2(20), 
	"OUTAGE_DEVICE_ID" VARCHAR2(100), 
	"OUTAGE_DEVICE_NAME" VARCHAR2(100), 
	"OUTAGE_CIRCUIT_ID" VARCHAR2(100), 
	"OUTAGE_START" TIMESTAMP (6), 
	"CREW_ETA" TIMESTAMP (6), 
	"CREW_CURRENT_STATUS" VARCHAR2(100), 
	"AUTO_ETOR" TIMESTAMP (6), 
	"CURRENT_ETOR" TIMESTAMP (6), 
	"OUTAGE_CAUSE" VARCHAR2(100), 
	"EST_CUSTOMERS" NUMBER, 
	"LAST_UPDATE" TIMESTAMP (6), 
	"HAZARD_FLAG" NUMBER, 
	"OUTAGE_LATITUDE" FLOAT(126), 
	"OUTAGE_LONGITUDE" FLOAT(126),
	"CITY" VARCHAR2(100),
	"COUNTY" VARCHAR2(100),
	"ZIP" VARCHAR2(100)
);

-- OMS_OUTAGE_TABLE table type --
create or replace TYPE OMS_OUTAGE_TABLE is table of OMS_OUTAGE;

-- Stored procedure for inserting outages in Oracle 10g --
create or replace 
PROCEDURE insert_OMS_Outage(oms_outage_data OMS_OUTAGE_TABLE)
AS
BEGIN
  for i in 1..oms_outage_data.count
  loop
    insert into OMS_CURRENT_OUTAGES@CCMO1T (OUTAGE_ID, OUTAGE_DEVICE_ID, OUTAGE_START, CREW_CURRENT_STATUS, CURRENT_ETOR, OUTAGE_CAUSE, EST_CUSTOMERS, LAST_UPDATE, HAZARD_FLAG, OUTAGE_LATITUDE, OUTAGE_LONGITUDE)
      values(oms_outage_data(i).outage_id, oms_outage_data(i).outage_device_id, oms_outage_data(i).outage_start, 
      oms_outage_data(i).crew_current_status, oms_outage_data(i).current_etor, oms_outage_data(i).outage_cause, oms_outage_data(i).est_customers,
      oms_outage_data(i).last_update, oms_outage_data(i).hazard_flag, oms_outage_data(i).outage_latitude, oms_outage_data(i).outage_longitude);
    commit;
    insert into oms_outages_regions@CCMO1T  values(HIBERNATE_SEQUENCE.NEXTVAL@CCMO1T, oms_outage_data(i).outage_id, (select id from gis_regions where region_type_id=1 and region_name=oms_outage_data(i).city));
    insert into oms_outages_regions@CCMO1T  values(HIBERNATE_SEQUENCE.NEXTVAL@CCMO1T, oms_outage_data(i).outage_id, (select id from gis_regions where region_type_id=2 and region_name=oms_outage_data(i).county));
    insert into oms_outages_regions@CCMO1T  values(HIBERNATE_SEQUENCE.NEXTVAL@CCMO1T, oms_outage_data(i).outage_id, (select id from gis_regions where region_type_id=3 and region_name=oms_outage_data(i).zip));
    commit;
   end loop;
END;
