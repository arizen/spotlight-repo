create or replace 
PROCEDURE update_mapping_table
AS
    outage_region_id NUMBER(10,0);
    
    CURSOR oms_outage IS
  		SELECT * FROM OMS_CURRENT_OUTAGES;
  		
  	temp_outage oms_outage%ROWTYPE;
BEGIN

  	execute immediate 'truncate table oms_outages_regions';
  		
	OPEN oms_outage;
	
  	LOOP
 
        --fetch cursor 'c_dbuser' into dbuser table type 'temp_dbuser'
		FETCH oms_outage INTO temp_outage;
 
        --exit if no more records
        EXIT WHEN oms_outage%NOTFOUND;
 
        IF temp_outage.city IS NULL AND temp_outage.zip IS NOT NULL THEN
        	BEGIN
            	select primary_city into temp_outage.city from spotlight_city_zip_map where zip=temp_outage.zip;
				update oms_current_outages set city = temp_outage.city where outage_id = temp_outage.outage_id;
            	
		 		EXCEPTION
                	WHEN no_data_found THEN
                    DBMS_OUTPUT.PUT_LINE('No data found for city in city zip map for zip - ' || temp_outage.zip);
	   		END;
        END IF;
        
        IF temp_outage.city IS NOT NULL THEN
	   		BEGIN
            	select id into outage_region_id from gis_regions where region_type_id=1 and region_name=temp_outage.city;
               
               	IF outage_region_id IS NOT NULL THEN
                	insert into oms_outages_regions values(HIBERNATE_SEQUENCE.NEXTVAL, temp_outage.outage_id, outage_region_id);
                END IF;

		 		EXCEPTION
                	WHEN no_data_found THEN
                    DBMS_OUTPUT.PUT_LINE('No data found for city in gis regions - ' || temp_outage.city);
	   		END; 		
        END IF;
        
        IF temp_outage.county IS NULL AND temp_outage.zip IS NOT NULL THEN
        	BEGIN
            	select county into temp_outage.county from spotlight_city_zip_map where zip=temp_outage.zip;
            	update oms_current_outages set county = temp_outage.county where outage_id = temp_outage.outage_id;

		 		EXCEPTION
                	WHEN no_data_found THEN
                    DBMS_OUTPUT.PUT_LINE('No data found for county in county zip map for zip - ' || temp_outage.zip);
	   		END;
        END IF;
        
 		IF temp_outage.county IS NOT NULL THEN
	   		BEGIN
            	select id into outage_region_id from gis_regions where region_type_id=2 and region_name=temp_outage.county;
               
               	IF outage_region_id IS NOT NULL THEN
                	insert into oms_outages_regions values(HIBERNATE_SEQUENCE.NEXTVAL, temp_outage.outage_id, outage_region_id);
                END IF;

		 		EXCEPTION
                	WHEN no_data_found THEN
                	DBMS_OUTPUT.PUT_LINE('No data found for county in gis regions - ' || temp_outage.county);
	   		END;
        END IF;
                
        IF temp_outage.zip IS NOT NULL THEN
	   		BEGIN
            	select id into outage_region_id from gis_regions where region_type_id=3 and region_name=temp_outage.zip;
               
            	IF outage_region_id IS NOT NULL THEN
                	insert into oms_outages_regions values(HIBERNATE_SEQUENCE.NEXTVAL, temp_outage.outage_id, outage_region_id);
                END IF;

				EXCEPTION
                	WHEN no_data_found THEN
                	DBMS_OUTPUT.PUT_LINE('No data found for zip in gis regions - ' || temp_outage.zip);
	   		END;
        END IF;
        
  	END LOOP;
 	commit;
  	CLOSE oms_outage;
END;