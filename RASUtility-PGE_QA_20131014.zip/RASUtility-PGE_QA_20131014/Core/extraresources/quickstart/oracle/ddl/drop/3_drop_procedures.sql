-- drop table type parameters --
drop type GISREGIONSTABLE;
drop type OMS_OUTAGE_TABLE;
drop type OMS_OUTAGE_DEVICE_TABLE;

-- drop object type parameters --
drop type GISRegion;
drop type OMS_OUTAGE;
drop type OMS_OUTAGE_DEVICE_TYPE;

-- drop stored procedure --
drop procedure insert_GISRegion;
drop procedure insert_OMS_Outage;
drop procedure insert_OMS_Outage_Device;
drop procedure refresh_Outage_Data;
drop procedure refresh_Outage_Data_Using_Temp;
