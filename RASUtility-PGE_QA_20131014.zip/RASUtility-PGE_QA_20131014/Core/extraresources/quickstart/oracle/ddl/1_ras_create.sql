--------------------------------------------------------
--  File created - Sunday-June-02-2013   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence HIBERNATE_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HIBERNATE_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;

--------------------------------------------------------
--  DDL for Table ADMIN
--------------------------------------------------------

  CREATE TABLE "ADMIN" 
   (	"LOGIN_ID" VARCHAR2(30 BYTE), 
	"PASSWORD" VARCHAR2(700 BYTE), 
	"USER_ID" VARCHAR2(30 BYTE), 
	"USER_ROLE_ID" NUMBER(24,0), 
	"CUSTOMER_ID" NUMBER(24,0), 
	"FORGOT_PASSWORD_TOKEN" VARCHAR2(800 BYTE), 
	"ACCESS_ROLE" VARCHAR2(50 BYTE)
   )    
;
--------------------------------------------------------
--  DDL for Table ADMIN_ALERT
--------------------------------------------------------

  CREATE TABLE "ADMIN_ALERT" 
   (	"ID" NUMBER(24,0), 
	"PERIOD_CYCLE" VARCHAR2(20 BYTE), 
	"ALERT_COUNT_CONDITION" VARCHAR2(20 BYTE), 
	"ALERT_NAME" VARCHAR2(255 BYTE), 
	"ALERT_TEXT_SCRIPT" VARCHAR2(1000 BYTE), 
	"CREATION_DATE" TIMESTAMP (6), 
	"IS_EMAIL" NUMBER(*,0), 
	"IS_REPEATABLE" NUMBER(*,0), 
	"IS_SENT" NUMBER(*,0), 
	"IS_SMS" NUMBER(*,0), 
	"ISSUE_COUNT" NUMBER(24,0), 
	"ISSUE_STATUS" VARCHAR2(20 BYTE), 
	"LAST_ALERT_SEND_TIME" TIMESTAMP (6), 
	"PERIOD_NUMBER" NUMBER(*,0), 
	"ADMIN_ID" VARCHAR2(30 BYTE), 
	"ISSUE_CATEGORY_ID" NUMBER(24,0), 
	"IS_ENABLED" NUMBER(*,0)
   ) 
;
--------------------------------------------------------
--  DDL for Table ADMIN_ALERTS_AUDIT
--------------------------------------------------------

  CREATE TABLE "ADMIN_ALERTS_AUDIT" 
   (	"ID" NUMBER(24,0), 
	"ALERT_BODY" VARCHAR2(1000 BYTE), 
	"CREATION_DATE" TIMESTAMP (6), 
	"ADMIN__LOGIN_ID" VARCHAR2(255 BYTE), 
	"ALERT_NAME" VARCHAR2(255 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table ADMIN_ROLE
--------------------------------------------------------

  CREATE TABLE "ADMIN_ROLE" 
   (	"ID" NUMBER(24,0), 
	"NAME" VARCHAR2(120 BYTE), 
	"CUSTOMER_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table ADMIN_ROLES_LOB_REF
--------------------------------------------------------

  CREATE TABLE "ADMIN_ROLES_LOB_REF" 
   (	"ID" NUMBER(24,0), 
	"LOB_ID" NUMBER(24,0), 
	"USER_ROLE_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table ADMIN_ROLES_REGION_REF
--------------------------------------------------------

  CREATE TABLE "ADMIN_ROLES_REGION_REF" 
   (	"ID" NUMBER(24,0), 
	"REGION_ID" NUMBER(24,0), 
	"USER_ROLE_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table API_ASYNC_PROCESS_TRACK
--------------------------------------------------------

  CREATE TABLE "API_ASYNC_PROCESS_TRACK" 
   (	"ID" NUMBER(24,0), 
	"CREATION_DATE" TIMESTAMP (6), 
	"ERROR_CODE" VARCHAR2(255 BYTE), 
	"LAST_MODIFIED_TIME" TIMESTAMP (6), 
	"LINK_ID" NUMBER(24,0), 
	"PROCESS_STATUS" VARCHAR2(255 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table API_KEY_MANAGEMENT
--------------------------------------------------------

  CREATE TABLE "API_KEY_MANAGEMENT" 
   (	"ACCESS_KEY" VARCHAR2(255 BYTE), 
	"SECRET_KEY" VARCHAR2(255 BYTE), 
	"CREATION_DATE" TIMESTAMP (6), 
	"LAST_MODIFED_DATE" TIMESTAMP (6), 
	"VALID_FROM" TIMESTAMP (6), 
	"VALID_TILL" TIMESTAMP (6), 
	"CUSTOMER_ID" NUMBER(24,0), 
	"IS_ACTIVE" NUMBER(*,0)
   )  
;
--------------------------------------------------------
--  DDL for Table CUSTOMER_USER
--------------------------------------------------------

  CREATE TABLE "CUSTOMER_USER" 
   (	"EMAIL_ID" VARCHAR2(30 BYTE), 
	"FIRST_NAME" VARCHAR2(30 BYTE), 
	"LAST_NAME" VARCHAR2(30 BYTE), 
	"PHONE_NUMBER" VARCHAR2(30 BYTE), 
	"USER_TYPE" NUMBER(*,0), 
	"APNS_KEY" VARCHAR2(255 BYTE), 
	"CUSTOMER_ACCOUNT_ID" VARCHAR2(50 BYTE), 
	"CUST_USER_NAME" VARCHAR2(50 BYTE), 
	"CUST_PASSWORD" VARCHAR2(500 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table CUSTOMER_USER_ACCOUNT
--------------------------------------------------------

  CREATE TABLE "CUSTOMER_USER_ACCOUNT" 
   (	"ACCOUNT_NUMBER" VARCHAR2(20 BYTE), 
	"ACCOUNT_NAME" VARCHAR2(50 BYTE), 
	"ACCOUNT_TYPE" VARCHAR2(20 BYTE), 
	"USER_ID" VARCHAR2(30 BYTE), 
	"ACCOUNT_BALANCE" FLOAT(5)
   )  
;
--------------------------------------------------------
--  DDL for Table CUST_USER_ACT_ELEC_SVC
--------------------------------------------------------

  CREATE TABLE "CUST_USER_ACT_ELEC_SVC" 
   (	"SERVICE_ID" NUMBER(24,0), 
	"SERVICE_ACCOUNT_ID" VARCHAR2(255 BYTE), 
	"SERVICE_TRANSFORMER" VARCHAR2(255 BYTE), 
	"METER_NUM" VARCHAR2(100 BYTE), 
	"SERVICE_STATUS" VARCHAR2(100 BYTE), 
	"SERVICE_RATE_PLAN_NAME" VARCHAR2(100 BYTE), 
	"SERVICE_PLAN_EFFECTIVE" DATE, 
	"PREMISE_ID" VARCHAR2(20 BYTE),
	"STREET_ADDR1" VARCHAR2(50 BYTE),
	"STREET_ADDR2" VARCHAR2(50 BYTE),
	"CITY" VARCHAR2(50 BYTE),
	"ZIP" VARCHAR2(20 BYTE),
	"STATE" VARCHAR2(50 BYTE),
	"COUNTRY" VARCHAR2(50 BYTE),
	"THOROUGHFARE_ADDRESS" VARCHAR2(255 BYTE),
	"SP_ID" VARCHAR2(20 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table CUST_USER_ACT_GAS_SVC
--------------------------------------------------------

  CREATE TABLE "CUST_USER_ACT_GAS_SVC" 
   (	"SERVICE_ID" NUMBER(24,0), 
	"SERVICE_ACCOUNT_ID" VARCHAR2(255 BYTE), 
	"METER_NUM" VARCHAR2(100 BYTE), 
	"SERVICE_STATUS" VARCHAR2(100 BYTE), 
	"SERVICE_RATE_PLAN_NAME" VARCHAR2(100 BYTE), 
	"SERVICE_PLAN_EFFECTIVE" DATE, 
	"PREMISE_ID" VARCHAR2(20 BYTE),
	"STREET_ADDR1" VARCHAR2(50 BYTE),
	"STREET_ADDR2" VARCHAR2(50 BYTE),
	"CITY" VARCHAR2(50 BYTE),
	"ZIP" VARCHAR2(20 BYTE),
	"STATE" VARCHAR2(50 BYTE),
	"COUNTRY" VARCHAR2(50 BYTE),
	"THOROUGHFARE_ADDRESS" VARCHAR2(255 BYTE),
	"SP_ID" VARCHAR2(20 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table CUST_USER_PHONE_RECORD
--------------------------------------------------------

  CREATE TABLE "CUST_USER_PHONE_RECORD"
   (	"ID" NUMBER(24, 0),
	"CUSTOMER_USER_ID" Varchar2(30 BYTE),
	"PHONE_TYPE_ID" NUMBER(24, 0),
	"PHONE_NUMBER" VARCHAR2(30 BYTE)
   ) 
;

--------------------------------------------------------
--  DDL for Table PHONE_TYPE
--------------------------------------------------------

  CREATE TABLE "PHONE_TYPE"
   (	"ID" NUMBER(24, 0),
	"PHONE_TYPE" VARCHAR2(50)
   ) 
;

--------------------------------------------------------
--  DDL for Table GIS_REGIONS
--------------------------------------------------------

  CREATE TABLE "GIS_REGIONS" 
   ( "ID" NUMBER(24,0),	
   "REGION_NAME" VARCHAR2(100 BYTE), 
	"NUM_OUTAGES" NUMBER(10,0), 
	"CUSTOMERS_EFFECTED" NUMBER(10,0), 
	"GIS_LATITUDE" FLOAT(126), 
	"GIS_LONGITUDE" FLOAT(126), 
	"REGION_TYPE_ID" NUMBER
   ) 
;
--------------------------------------------------------
--  DDL for Table GIS_REGION_TYPE
--------------------------------------------------------

  CREATE TABLE "GIS_REGION_TYPE" 
   (	"REGION_ID" NUMBER, 
	"REGION_TYPE" VARCHAR2(20 BYTE)
   ) 
;

--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_DEVICE
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_DEVICE" 
   ( "ID" NUMBER,	
   "DEVICE_ID" VARCHAR2(100 BYTE), 
	"DEVICE_NAME" VARCHAR2(100 BYTE),
	"LATITUDE" FLOAT(126), 
	"LONGITUDE" FLOAT(126),
	"CIRCUIT_ID" VARCHAR2(100 BYTE),
	"OUTAGE_ID" NUMBER(10,0),
	"DEVICE_TYPE_ID" NUMBER(10,0)
   ) 
;

--------------------------------------------------------
--  DDL for Table OMS_DEVICE_TYPE
--------------------------------------------------------

CREATE TABLE "OMS_DEVICE_TYPE"
(	"ID" NUMBER,
	"DEVICE_TYPE" VARCHAR2(100 BYTE)
) 
 ;
  
--------------------------------------------------------
--  DDL for Table GLOBAL_PROPERTY_KEY_VALUE
--------------------------------------------------------

  CREATE TABLE "GLOBAL_PROPERTY_KEY_VALUE" 
   (	"GLOBAL_KEY" VARCHAR2(255 BYTE), 
	"GLOBAL_VALUE" VARCHAR2(255 BYTE), 
	"SHOW_ON_UI" NUMBER(*,0), 
	"UI_DISPLAY_NAME" VARCHAR2(255 BYTE), 
	"IS_EDITABLE_ON_UI" NUMBER(*,0), 
	"POSSIBLE_VALUES" VARCHAR2(255 BYTE), 
	"UI_CONTROL_TYPE" VARCHAR2(20 BYTE), 
	"UI_ID" VARCHAR2(255 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE
--------------------------------------------------------

  CREATE TABLE "ISSUE" 
   (	"ID" NUMBER(24,0), 
	"ADDRESS" VARCHAR2(255 BYTE), 
	"CREATION_DATE" TIMESTAMP (6), 
	"DESCRIPTION" VARCHAR2(1000 BYTE), 
	"DEVICE" VARCHAR2(20 BYTE), 
	"IS_PUBLIC" NUMBER(*,0), 
	"LAST_MODIFIED_DATE" TIMESTAMP (6), 
	"LATITUDE" FLOAT(126), 
	"LONGITUDE" FLOAT(126), 
	"STATUS" VARCHAR2(255 BYTE), 
	"TITLE" VARCHAR2(120 BYTE), 
	"ISSUE_CATEGORY_ID" NUMBER(24,0), 
	"USER_ID" VARCHAR2(30 BYTE), 
	"IS_SPAM" NUMBER(*,0), 
	"CUSTOMER_ID" NUMBER(24,0), 
	"LOB_ID" NUMBER(24,0), 
	"REGION_ID" NUMBER(24,0), 
	"LAST_STATUS_CHANGE_DATE" TIMESTAMP (6), 
	"PRIORITY" VARCHAR2(30 BYTE), 
	"THUMBNAIL_URL" VARCHAR2(1000 BYTE), 
	"ASSIGNEE_ID" VARCHAR2(30 BYTE), 
	"IS_ARCHIVED" NUMBER(*,0), 
	"IS_REQUEST_COMPLETE" NUMBER(*,0)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_ADDRESS
--------------------------------------------------------

  CREATE TABLE "ISSUE_ADDRESS" 
   (	"ID" NUMBER(24,0), 
	"CITY" VARCHAR2(255 BYTE), 
	"COUNTRY_CODE" VARCHAR2(255 BYTE), 
	"HOUSE_NUMBER" VARCHAR2(255 BYTE), 
	"STATE" VARCHAR2(255 BYTE),
	"STREET_NUM" VARCHAR2(255 BYTE),
	"STREET_NAME" VARCHAR2(255 BYTE), 
	"ZIP_CODE" VARCHAR2(255 BYTE), 
	"ISSUE_ID" NUMBER(24,0), 
	"ADDRESS_LABEL" VARCHAR2(255 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_AUDIT
--------------------------------------------------------

  CREATE TABLE "ISSUE_AUDIT" 
   (	"ID" NUMBER(24,0), 
	"CREATION_DATE" TIMESTAMP (6), 
	"IS_PUBLIC" NUMBER(*,0), 
	"IS_SPAM" NUMBER(*,0), 
	"PRIORITY" VARCHAR2(30 BYTE), 
	"STATUS" VARCHAR2(255 BYTE), 
	"ISSUE_ID" NUMBER(24,0)
   ) 
;
--------------------------------------------------------
--  DDL for Table ISSUE_CATEGORY_CUSTFIELD
--------------------------------------------------------

  CREATE TABLE "ISSUE_CATEGORY_CUSTFIELD" 
   (	"ID" NUMBER(24,0), 
	"COLUMN_TYPE" VARCHAR2(20 BYTE), 
	"CUSTOM_FIELD_NAME" VARCHAR2(255 BYTE), 
	"IS_MANDATORY" NUMBER(*,0), 
	"TITLE" VARCHAR2(255 BYTE), 
	"XML_TAG_NAME" VARCHAR2(255 BYTE), 
	"ISSUE_CATEGORY_ID" NUMBER(24,0), 
	"IS_VISIBLE_ON_DISPLAY" NUMBER(*,0), 
	"IS_VISIBLE_ON_FORM" NUMBER(*,0), 
	"UI_CONTROL_TYPE" VARCHAR2(20 BYTE), 
	"POSSIBLE_VALUES" VARCHAR2(255 BYTE), 
	"VERSION" VARCHAR2(20 BYTE), 
	"SERVICE_TYPE" VARCHAR2(20 BYTE) DEFAULT 'CREATE_REQ'
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_CATEGORY_GROUP
--------------------------------------------------------

  CREATE TABLE "ISSUE_CATEGORY_GROUP" 
   (	"ID" NUMBER(24,0), 
	"GROUP_NAME" VARCHAR2(255 BYTE), 
	"GROUP_DESCRIPTION" VARCHAR2(255 BYTE), 
	"CUSTOMER_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_CATEGORY_MS
--------------------------------------------------------

  CREATE TABLE "ISSUE_CATEGORY_MS" 
   (	"ID" NUMBER(24,0), 
	"CATEGORY_TYPE" VARCHAR2(255 BYTE), 
	"TWITTER_SHORTCODE_HASH" VARCHAR2(255 BYTE), 
	"DEFAULT_ASSIGNEE" NUMBER(24,0), 
	"PRIORITY" VARCHAR2(30 BYTE), 
	"IS_ACTIVE" NUMBER(*,0), 
	"SHOULD_POST_TO_TWITTER" NUMBER(*,0), 
	"CREATE_ISSUE_WORKFLOW" NUMBER(24,0), 
	"SEARCH_ISSUE_WORKFLOW" NUMBER(24,0), 
	"UPDATE_ISSUE_WORKFLOW" NUMBER(24,0), 
	"CUSTOMER_ID" NUMBER(24,0), 
	"CACHE_SERVICE_BEAN" VARCHAR2(50 BYTE), 
	"ALLOW_ANNONYMOUS_REPORT" NUMBER(*,0), 
	"CUSTOM_FIELDS_CONFIGURED" NUMBER(*,0), 
	"VERSION" VARCHAR2(20 BYTE), 
	"ISSUE_CATEGORY_GROUP_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_COMMENTS
--------------------------------------------------------

  CREATE TABLE "ISSUE_COMMENTS" 
   (	"ID" NUMBER(24,0), 
	"TEXT" VARCHAR2(255 BYTE), 
	"SUBMITTED_DATE" TIMESTAMP (6), 
	"ISSUE_ID" NUMBER(24,0), 
	"USER_ID" VARCHAR2(30 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table ISSUE_CUSTOM_FIELD_REF
--------------------------------------------------------

  CREATE TABLE "ISSUE_CUSTOM_FIELD_REF" 
   (	"ID" NUMBER(24,0), 
	"DATE_FIELD" TIMESTAMP (6), 
	"LONG_FIELD" NUMBER(24,0), 
	"STRING_FIELD" VARCHAR2(255 BYTE), 
	"CUSTOM_FIELD_ID" NUMBER(24,0), 
	"ISSUE_ID" NUMBER(24,0), 
	"BOOLEAN_FIELD" NUMBER(*,0), 
	"DOUBLE_FIELD" FLOAT(126)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_IMAGES
--------------------------------------------------------

  CREATE TABLE "ISSUE_IMAGES" 
   (	"ID" NUMBER(24,0), 
	"IMAGE_NAME" VARCHAR2(100 BYTE), 
	"ISSUE_ID" NUMBER(24,0), 
	"IMAGE_URL" VARCHAR2(1000 BYTE), 
	"THUMBNAIL_URL" VARCHAR2(1000 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_NOTIFICATION
--------------------------------------------------------

  CREATE TABLE "ISSUE_NOTIFICATION" 
   (	"ID" NUMBER(24,0), 
	"CONTENT" VARCHAR2(1000 BYTE), 
	"CREATION_DATE" TIMESTAMP (6), 
	"ISSUE_ID" NUMBER(24,0), 
	"FROM_STATUS" VARCHAR2(255 BYTE), 
	"TYPE" NUMBER(*,0), 
	"TO_STATUS" VARCHAR2(255 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table ISSUE_USER_NOTIFICATION_REF
--------------------------------------------------------

  CREATE TABLE "ISSUE_USER_NOTIFICATION_REF" 
   (	"ID" NUMBER(24,0), 
	"IS_DEVICE" NUMBER(*,0), 
	"IS_EMAIL" NUMBER(*,0), 
	"IS_SMS" NUMBER(*,0), 
	"ISSUE_ID" NUMBER(24,0), 
	"USER_ID" VARCHAR2(30 BYTE), 
	"IS_PUSH_NOTIFICATION" NUMBER(*,0), 
	"NOTIFY_OPTION_TYPE" NUMBER(*,0)
   )  
;
--------------------------------------------------------
--  DDL for Table ISSUE_USER_SPAM
--------------------------------------------------------

  CREATE TABLE "ISSUE_USER_SPAM" 
   (	"ID" NUMBER(24,0), 
	"CREATION_DATE" TIMESTAMP (6), 
	"ISSUE_ID" NUMBER(24,0), 
	"USER_ID" VARCHAR2(30 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table ISSUE_USER_SUPPORT
--------------------------------------------------------

  CREATE TABLE "ISSUE_USER_SUPPORT" 
   (	"ID" NUMBER(24,0), 
	"CREATION_DATE" TIMESTAMP (6), 
	"ISSUE_ID" NUMBER(24,0), 
	"USER_ID" VARCHAR2(30 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table LOB_ISSUE_CATEGORY_REF
--------------------------------------------------------

  CREATE TABLE "LOB_ISSUE_CATEGORY_REF" 
   (	"ID" NUMBER(24,0), 
	"ISSUE_CATGORY_ID" NUMBER(24,0), 
	"LOB_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table OMS_CURRENT_OUTAGES
--------------------------------------------------------

  CREATE TABLE "OMS_CURRENT_OUTAGES" 
   (	"OUTAGE_ID" NUMBER(10,0), 
	"OUTAGE_EXTENT" VARCHAR2(20 BYTE), 
	"OUTAGE_DEVICE_ID" VARCHAR2(100 BYTE), 
	"OUTAGE_DEVICE_NAME" VARCHAR2(100 BYTE), 
	"OUTAGE_CIRCUIT_ID" VARCHAR2(100 BYTE), 
	"OUTAGE_START" TIMESTAMP (6), 
	"CREW_ETA" TIMESTAMP (6), 
	"CREW_CURRENT_STATUS" VARCHAR2(100 BYTE), 
	"AUTO_ETOR" TIMESTAMP (6), 
	"CURRENT_ETOR" TIMESTAMP (6), 
	"OUTAGE_CAUSE" VARCHAR2(100 BYTE), 
	"EST_CUSTOMERS" NUMBER, 
	"LAST_UPDATE" TIMESTAMP (6), 
	"HAZARD_FLAG" NUMBER, 
	"OUTAGE_LATITUDE" FLOAT(126), 
	"OUTAGE_LONGITUDE" FLOAT(126),
	"CITY" VARCHAR2(100 BYTE), 
	"COUNTY" VARCHAR2(100 BYTE), 
	"ZIP" VARCHAR2(100 BYTE),
	"IS_REMOTE" NUMBER(*,0)
   ) 
;
  
--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_CAUSE
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_CAUSE" 
   (	
   	"CAUSE_KEY" VARCHAR2(100 BYTE),
   	"CAUSE_MSG" VARCHAR2(255 BYTE),
   	"OIS_CAUSE_NO" VARCHAR2(5 BYTE)
   ) 
;
  
--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_STATUS
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_STATUS" 
   (	
   	"STATUS_KEY" VARCHAR2(100 BYTE),
   	"STATUS_MSG" VARCHAR2(255 BYTE),
   	"OIS_STATUS_KEY" VARCHAR2(255 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table OUTAGE_NOTIFICATION
--------------------------------------------------------

  CREATE TABLE "OUTAGE_NOTIFICATION" 
   (	"ID" NUMBER(24,0), 
	"CONTENT" VARCHAR2(1000 BYTE), 
	"CREATION_DATE" TIMESTAMP (6), 
	"OUTAGE_NUMBER" VARCHAR2(255 BYTE), 
	"TYPE" NUMBER(*,0)
   ) 
;
--------------------------------------------------------
--  DDL for Table OUTAGE_USER_NOTIFICATION
--------------------------------------------------------

  CREATE TABLE "OUTAGE_USER_NOTIFICATION" 
   (	"ID" NUMBER(24,0), 
	"IS_DEVICE" NUMBER(*,0), 
	"IS_EMAIL" NUMBER(*,0), 
	"IS_PUSH_NOTIFICATION" NUMBER(*,0), 
	"IS_SMS" NUMBER(*,0), 
	"OUTAGENUMBER" VARCHAR2(255 BYTE), 
	"USER_ID" VARCHAR2(30 BYTE), 
	"NOTIFY_OPTION_TYPE" NUMBER(*,0)
   ) 
;
  
--------------------------------------------------------
--  DDL for Table OUTAGE_NOTIFICATION_SETTING
--------------------------------------------------------

  CREATE TABLE "OUTAGE_NOTIFICATION_SETTING" 
   (	"ID" NUMBER(24,0), 
	"OUTAGE_ID" NUMBER(24,0), 
	"NOTIFICATION_SETTING_ID" NUMBER(24,0)
   ) 
;
  
--------------------------------------------------------
--  DDL for Table NOTIFICATION_SETTING
--------------------------------------------------------

  CREATE TABLE "NOTIFICATION_SETTING" 
   (	"ID" NUMBER(24,0), 
	"CHANNEL_TYPE" VARCHAR2(50 BYTE), 
	"CHANNEL_VALUE" VARCHAR2(50 BYTE), 
	"NOTIFY_OPTION" VARCHAR2(50 BYTE)
   ) 
;

--------------------------------------------------------
--  DDL for Table SPOTLIGHT_CUSTOMER
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_CUSTOMER" 
   (	"ID" NUMBER(24,0), 
	"NAME" VARCHAR2(120 BYTE), 
	"WEB_URL" VARCHAR2(255 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table SPOTLIGHT_CUST_LOB
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_CUST_LOB" 
   (	"ID" NUMBER(24,0), 
	"NAME" VARCHAR2(120 BYTE), 
	"CUSTOMER_ID" NUMBER(24,0)
   )  
;
--------------------------------------------------------
--  DDL for Table SPOTLIGHT_CUST_REGION
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_CUST_REGION" 
   (	"ID" NUMBER(24,0), 
	"GEO_POINTS" CLOB, 
	"NAME" VARCHAR2(30 BYTE), 
	"CUSTOMER_ID" NUMBER(24,0), 
	"PARENT_ID" NUMBER(24,0), 
	"GEO_POLYGON" "MDSYS"."SDO_GEOMETRY" 
   )  
  ;
--------------------------------------------------------
--  DDL for Table SPOTLIGHT_MESSAGE_TEXT
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_MESSAGE_TEXT" 
   (	"MSG_KEY" VARCHAR2(255 BYTE), 
	"MSG_VALUE" VARCHAR2(255 BYTE)
   )  
;
--------------------------------------------------------
--  DDL for Table SPOTLIGHT_REQUEST_TRACK
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_REQUEST_TRACK" 
   (	"ID" NUMBER(24,0), 
	"CREATION_DATE" TIMESTAMP (6), 
	"ERROR_CODE" VARCHAR2(255 BYTE), 
	"LAST_MODIFIED_TIME" TIMESTAMP (6), 
	"LINK_ID" NUMBER(24,0), 
	"REQUEST_STATUS" VARCHAR2(255 BYTE), 
  "UNIQUE_ID" VARCHAR2(255 BYTE),
  "MACHINE_NAME" VARCHAR2(255 BYTE),
  "RESPONSE" CLOB,
	"REQUEST_TYPE" VARCHAR2(255 BYTE),
  "USER_ID" VARCHAR2(255 BYTE),
  "LAST_UNIQUE_ID" VARCHAR2(255 BYTE),
	"THREAD_NAME" VARCHAR2(255 BYTE),
  "CATEGORY_TYPE" VARCHAR2(255 BYTE),
	"REQUEST_STRING" CLOB
   ) 
;
  
--------------------------------------------------------
--  DDL for Table SPOTLIGHT_FAILED_REQUEST
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_FAILED_REQUEST" 
   (	"ID" NUMBER(24,0), 
	"CREATION_DATE" TIMESTAMP (6),  
	"LAST_MODIFIED_TIME" TIMESTAMP (6), 
	"GENERATED_ID" VARCHAR2(255 BYTE), 
	"REQUEST_STATUS" VARCHAR2(255 BYTE), 
	"REQUEST_TYPE" VARCHAR2(255 BYTE), 
	"RETRY_COUNT" NUMBER(24,0),
	"ERROR_MSG" VARCHAR2(255 BYTE), 
	"ERROR_KEY" VARCHAR2(255 BYTE),
	"VERSION" VARCHAR2(30 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table SPOTLIGHT_WORKFLOWS
--------------------------------------------------------

  CREATE TABLE "SPOTLIGHT_WORKFLOWS" 
   (	"ID" NUMBER(24,0), 
	"DESCRIPTION" VARCHAR2(1000 BYTE), 
	"NAME" VARCHAR2(100 BYTE), 
	"INTERFACE_NAME" VARCHAR2(100 BYTE), 
	"CUSTOMER_ID" NUMBER(24,0), 
	"WORKFLOW_TYPE" VARCHAR2(20 BYTE), 
	"IS_ASYNCHRONOUS" NUMBER(*,0) DEFAULT 1
   )  
;
--------------------------------------------------------
--  DDL for Table USER_ADDRESS
--------------------------------------------------------

  CREATE TABLE "USER_ADDRESS" 
   (	"ID" NUMBER(24,0), 
	"CITY" VARCHAR2(255 BYTE), 
	"COUNTRY_CODE" VARCHAR2(255 BYTE), 
	"HOUSE_NUMBER" VARCHAR2(255 BYTE), 
	"STATE" VARCHAR2(255 BYTE), 
	"STREET_NAME" VARCHAR2(255 BYTE),
	"STREET_NUM" VARCHAR2(255 BYTE), 
	"ZIP_CODE" VARCHAR2(255 BYTE), 
	"USER_ID" VARCHAR2(30 BYTE), 
	"THOROUGHFARE_ADDRESS" VARCHAR2(255 BYTE),
	"ADDRESS_LABEL" VARCHAR2(255 BYTE)
   ) 
;
--------------------------------------------------------
--  DDL for Table OMS_OUTAGES_REGIONS
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGES_REGIONS" 
   (	"ID" NUMBER(24,0), 
	"OUTAGE_ID" NUMBER(24,0), 
	"OUTAGE_REGION_ID" NUMBER(24,0)
   ) 
;

CREATE TABLE "SPOTLIGHT_CITY_ZIP_MAP"
(
  zip VARCHAR2(20 BYTE),
  type VARCHAR2(50 BYTE),
  primary_city VARCHAR2(50 BYTE),
  county VARCHAR2(50 BYTE),
  latitude FLOAT(126),
  longitude FLOAT(126),
  estimated_population NUMBER(24,0),
  notes VARCHAR2(100 BYTE)
);
--------------------------------------------------------
--  DDL for Index OMS_OUT_REGION_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OMS_OUT_REGION_PK_IDX" ON "OMS_OUTAGES_REGIONS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_IDX_USERID
--------------------------------------------------------

  CREATE INDEX "ADMIN_IDX_USERID" ON "ADMIN" ("USER_ID")    
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_CUST_REG_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_CUST_REG_PK_IDX" ON "SPOTLIGHT_CUST_REGION" ("ID") 
;
--------------------------------------------------------
--  DDL for Index LOBISSCATREF_IDX_LOBID
--------------------------------------------------------

  CREATE INDEX "LOBISSCATREF_IDX_LOBID" ON "LOB_ISSUE_CATEGORY_REF" ("LOB_ID") 
;
  
--------------------------------------------------------
--  DDL for Index PHONE_TYPE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PHONE_TYPE_PK_IDX" ON "PHONE_TYPE" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ADMALRT_IDX_ISSCATID
--------------------------------------------------------

  CREATE INDEX "ADMALRT_IDX_ISSCATID" ON "ADMIN_ALERT" ("ISSUE_CATEGORY_ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_IDX_USRROLEID
--------------------------------------------------------

  CREATE INDEX "ADMIN_IDX_USRROLEID" ON "ADMIN" ("USER_ROLE_ID") 
;
--------------------------------------------------------
--  DDL for Index NOTI_SETTING_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "NOTI_SETTING_PK_IDX" ON "NOTIFICATION_SETTING" ("ID") 
;
--------------------------------------------------------
--  DDL for Index API_KEY_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "API_KEY_PK_IDX" ON "API_KEY_MANAGEMENT" ("ACCESS_KEY") 
;
--------------------------------------------------------
--  DDL for Index RASWRKFLWS_CUSTID
--------------------------------------------------------

  CREATE INDEX "RASWRKFLWS_CUSTID" ON "SPOTLIGHT_WORKFLOWS" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index NOT_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "NOT_IDX_ISSUEID" ON "ISSUE_NOTIFICATION" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_REQ_TRK_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_REQ_TRK_PK_IDX" ON "SPOTLIGHT_REQUEST_TRACK" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_ISSCATGRPID
--------------------------------------------------------

  CREATE INDEX "ISSCATMS_IDX_ISSCATGRPID" ON "ISSUE_CATEGORY_MS" ("ISSUE_CATEGORY_GROUP_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUSRSUPP_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "ISSUSRSUPP_IDX_USRID" ON "ISSUE_USER_SUPPORT" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index LOB_ISSUE_CAT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "LOB_ISSUE_CAT_PK_IDX" ON "LOB_ISSUE_CATEGORY_REF" ("ID") 
;
--------------------------------------------------------
--  DDL for Index USER_ACCOUNT_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "USER_ACCOUNT_IDX_USRID" ON "CUSTOMER_USER_ACCOUNT" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index STAGE_CURRENT_OUTAGES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "STAGE_CURRENT_OUTAGES_PK_IDX" ON "OMS_CURRENT_OUTAGES" ("OUTAGE_ID") 
;
  
--------------------------------------------------------
--  DDL for Index OMS_OUTAGE_CAUSE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "OMS_OUTAGE_CAUSE_PK" ON "OMS_OUTAGE_CAUSE" ("CAUSE_KEY") 
;
  
--------------------------------------------------------
--  DDL for Index OMS_OUTAGE_STATUS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "OMS_OUTAGE_STATUS_PK" ON "OMS_OUTAGE_STATUS" ("STATUS_KEY") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_ADDRESS_UNQ_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_ADDRESS_UNQ_IDX" ON "ISSUE_ADDRESS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index OUTAGE_USER_NOTI_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OUTAGE_USER_NOTI_PK_IDX" ON "OUTAGE_USER_NOTIFICATION" ("ID") 
;
  
--------------------------------------------------------
--  DDL for Index CUSTCATCF_IDX_ISSUECATID
--------------------------------------------------------

  CREATE INDEX "CUSTCATCF_IDX_ISSUECATID" ON "ISSUE_CATEGORY_CUSTFIELD" ("ISSUE_CATEGORY_ID") 
;

--------------------------------------------------------
--  DDL for Index CUST_USER_PHONE_RECORD_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "CUST_USER_PHONE_RECORD_PK" ON "CUST_USER_PHONE_RECORD" ("ID") 
;
--------------------------------------------------------
--  DDL for Index OUTUSRNOTREF_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "OUTUSRNOTREF_IDX_USRID" ON "OUTAGE_USER_NOTIFICATION" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_WRKFLWS_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_WRKFLWS_PK_IDX" ON "SPOTLIGHT_WORKFLOWS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSIMG_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSIMG_IDX_ISSUEID" ON "ISSUE_IMAGES" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUSRNOTREF_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "ISSUSRNOTREF_IDX_USRID" ON "ISSUE_USER_NOTIFICATION_REF" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_CAT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_CAT_PK_IDX" ON "ISSUE_CATEGORY_MS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_ROLE_REG_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ADMIN_ROLE_REG_PK_IDX" ON "ADMIN_ROLES_REGION_REF" ("ID") 
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_MSG_TEXT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_MSG_TEXT_PK_IDX" ON "SPOTLIGHT_MESSAGE_TEXT" ("MSG_KEY") 
;
--------------------------------------------------------
--  DDL for Index ADMALRT_IDX_ADMID
--------------------------------------------------------

  CREATE INDEX "ADMALRT_IDX_ADMID" ON "ADMIN_ALERT" ("ADMIN_ID") 
;
--------------------------------------------------------
--  DDL for Index API_ASYNC_PROCESS_TRK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "API_ASYNC_PROCESS_TRK_IDX" ON "API_ASYNC_PROCESS_TRACK" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IMAGE_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_IMAGE_PK_IDX" ON "ISSUE_IMAGES" ("ID") 
;
--------------------------------------------------------
--  DDL for Index REGION_IDX_CUSTID
--------------------------------------------------------

  CREATE INDEX "REGION_IDX_CUSTID" ON "SPOTLIGHT_CUST_REGION" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index USROLREGREF_IDX_USRROLID
--------------------------------------------------------

  CREATE INDEX "USROLREGREF_IDX_USRROLID" ON "ADMIN_ROLES_REGION_REF" ("USER_ROLE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_CATTYPE
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSCATMS_IDX_CATTYPE" ON "ISSUE_CATEGORY_MS" ("CATEGORY_TYPE") 
;
--------------------------------------------------------
--  DDL for Index USER_IDX_ACCOUNT_NUMBER
--------------------------------------------------------

  CREATE UNIQUE INDEX "USER_IDX_ACCOUNT_NUMBER" ON "CUSTOMER_USER_ACCOUNT" ("ACCOUNT_NUMBER") 
;
--------------------------------------------------------
--  DDL for Index ISSCATGRP_CUSTID
--------------------------------------------------------

  CREATE INDEX "ISSCATGRP_CUSTID" ON "ISSUE_CATEGORY_GROUP" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_ROLE_LOB_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ADMIN_ROLE_LOB_PK_IDX" ON "ADMIN_ROLES_LOB_REF" ("ID") 
;
--------------------------------------------------------
--  DDL for Index REGION_IDX_PARENTID
--------------------------------------------------------

  CREATE INDEX "REGION_IDX_PARENTID" ON "SPOTLIGHT_CUST_REGION" ("PARENT_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCOMM_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "ISSCOMM_IDX_USRID" ON "ISSUE_COMMENTS" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index USRADD_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "USRADD_IDX_USRID" ON "USER_ADDRESS" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_CUST_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_CUST_PK_IDX" ON "SPOTLIGHT_CUSTOMER" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUSRSUPP_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSUSRSUPP_IDX_ISSUEID" ON "ISSUE_USER_SUPPORT" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_UPDATEISSWRKFLW
--------------------------------------------------------

  CREATE INDEX "ISSCATMS_IDX_UPDATEISSWRKFLW" ON "ISSUE_CATEGORY_MS" ("UPDATE_ISSUE_WORKFLOW") 
;
--------------------------------------------------------
--  DDL for Index LOB_IDX_CUSTID
--------------------------------------------------------

  CREATE INDEX "LOB_IDX_CUSTID" ON "SPOTLIGHT_CUST_LOB" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_CREATEISSWRKFLW
--------------------------------------------------------

  CREATE INDEX "ISSCATMS_IDX_CREATEISSWRKFLW" ON "ISSUE_CATEGORY_MS" ("CREATE_ISSUE_WORKFLOW") 
;
--------------------------------------------------------
--  DDL for Index ISSCFREF_IDX_CFID
--------------------------------------------------------

  CREATE INDEX "ISSCFREF_IDX_CFID" ON "ISSUE_CUSTOM_FIELD_REF" ("CUSTOM_FIELD_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_USER_SPAM_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_USER_SPAM_PK_IDX" ON "ISSUE_USER_SPAM" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUSRSPAM_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSUSRSPAM_IDX_ISSUEID" ON "ISSUE_USER_SPAM" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCOMM_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSCOMM_IDX_ISSUEID" ON "ISSUE_COMMENTS" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSADT_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSADT_IDX_ISSUEID" ON "ISSUE_AUDIT" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index USRROLLOBREF_IDX_LOBID
--------------------------------------------------------

  CREATE INDEX "USRROLLOBREF_IDX_LOBID" ON "ADMIN_ROLES_LOB_REF" ("LOB_ID") 
;
--------------------------------------------------------
--  DDL for Index GIS_OUTAGES_REGION_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "GIS_OUTAGES_REGION_IDX" ON "GIS_REGIONS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ADMIN_PK_IDX" ON "ADMIN" ("LOGIN_ID") 
;
--------------------------------------------------------
--  DDL for Index USROLREGREF_IDX_REGID
--------------------------------------------------------

  CREATE INDEX "USROLREGREF_IDX_REGID" ON "ADMIN_ROLES_REGION_REF" ("REGION_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IDX_CUSTID
--------------------------------------------------------

  CREATE INDEX "ISSUE_IDX_CUSTID" ON "ISSUE" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_CAT_CUSTFIELD_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_CAT_CUSTFIELD_PK_IDX" ON "ISSUE_CATEGORY_CUSTFIELD" ("ID") 
;
--------------------------------------------------------
--  DDL for Index USER_ADD_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "USER_ADD_PK_IDX" ON "USER_ADDRESS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IDX_ISSCATID
--------------------------------------------------------

  CREATE INDEX "ISSUE_IDX_ISSCATID" ON "ISSUE" ("ISSUE_CATEGORY_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCFREF_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSCFREF_IDX_ISSUEID" ON "ISSUE_CUSTOM_FIELD_REF" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_NOTI_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_NOTI_PK_IDX" ON "ISSUE_NOTIFICATION" ("ID") 
;
--------------------------------------------------------
--  DDL for Index USRROLE_IDX_CUSTID
--------------------------------------------------------

  CREATE INDEX "USRROLE_IDX_CUSTID" ON "ADMIN_ROLE" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_DEFASS
--------------------------------------------------------

  CREATE INDEX "ISSCATMS_IDX_DEFASS" ON "ISSUE_CATEGORY_MS" ("DEFAULT_ASSIGNEE") 
;
--------------------------------------------------------
--  DDL for Index ISSUSRNOTREF_IDX_ISSUEID
--------------------------------------------------------

  CREATE INDEX "ISSUSRNOTREF_IDX_ISSUEID" ON "ISSUE_USER_NOTIFICATION_REF" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_AUDIT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_AUDIT_PK_IDX" ON "ISSUE_AUDIT" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_CUSTID
--------------------------------------------------------

  CREATE INDEX "ISSCATMS_IDX_CUSTID" ON "ISSUE_CATEGORY_MS" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_TWTHASH
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSCATMS_IDX_TWTHASH" ON "ISSUE_CATEGORY_MS" ("TWITTER_SHORTCODE_HASH") 
;
--------------------------------------------------------
--  DDL for Index GLOBAL_PROP_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "GLOBAL_PROP_PK_IDX" ON "GLOBAL_PROPERTY_KEY_VALUE" ("GLOBAL_KEY") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "ISSUE_IDX_USRID" ON "ISSUE" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index APIKEYMGMT_IDX_CUSTID
--------------------------------------------------------

  CREATE INDEX "APIKEYMGMT_IDX_CUSTID" ON "API_KEY_MANAGEMENT" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_ALERT_AUD_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ADMIN_ALERT_AUD_PK_IDX" ON "ADMIN_ALERTS_AUDIT" ("ID") 
;
--------------------------------------------------------
--  DDL for Index USRROLLOBREF_IDX_USRROLID
--------------------------------------------------------

  CREATE INDEX "USRROLLOBREF_IDX_USRROLID" ON "ADMIN_ROLES_LOB_REF" ("USER_ROLE_ID") 
;
--------------------------------------------------------
--  DDL for Index CUST_USER_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "CUST_USER_PK_IDX" ON "CUSTOMER_USER" ("EMAIL_ID") 
;
--------------------------------------------------------
--  DDL for Index OUTAGE_NOTI_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OUTAGE_NOTI_PK_IDX" ON "OUTAGE_NOTIFICATION" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_CUSTOMFIELD_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_CUSTOMFIELD_PK_IDX" ON "ISSUE_CUSTOM_FIELD_REF" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IDX_ASSID
--------------------------------------------------------

  CREATE INDEX "ISSUE_IDX_ASSID" ON "ISSUE" ("ASSIGNEE_ID") 
;
--------------------------------------------------------
--  DDL for Index USER_ACCOUNT_ELECTRIC_SER_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "USER_ACCOUNT_ELECTRIC_SER_PK" ON "CUST_USER_ACT_ELEC_SVC" ("SERVICE_ID") 
;
--------------------------------------------------------
--  DDL for Index LOBISSCATREF_IDX_ISSCATID
--------------------------------------------------------

  CREATE INDEX "LOBISSCATREF_IDX_ISSCATID" ON "LOB_ISSUE_CATEGORY_REF" ("ISSUE_CATGORY_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_CATEGORY_GROUP_UNQ_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_CATEGORY_GROUP_UNQ_IDX" ON "ISSUE_CATEGORY_GROUP" ("ID") 
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_CUST_LOB_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_CUST_LOB_PK_IDX" ON "SPOTLIGHT_CUST_LOB" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_USER_NOTI_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_USER_NOTI_PK_IDX" ON "ISSUE_USER_NOTIFICATION_REF" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSCATMS_IDX_SEARCHISSWRKFLW
--------------------------------------------------------

  CREATE INDEX "ISSCATMS_IDX_SEARCHISSWRKFLW" ON "ISSUE_CATEGORY_MS" ("SEARCH_ISSUE_WORKFLOW") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_ADDRESS_ISSUE_ID
--------------------------------------------------------

  CREATE INDEX "ISSUE_ADDRESS_ISSUE_ID" ON "ISSUE_ADDRESS" ("ISSUE_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IDX_RGNID
--------------------------------------------------------

  CREATE INDEX "ISSUE_IDX_RGNID" ON "ISSUE" ("REGION_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_PK_IDX" ON "ISSUE" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ADMIN_IDX_CUSTOMERID
--------------------------------------------------------

  CREATE INDEX "ADMIN_IDX_CUSTOMERID" ON "ADMIN" ("CUSTOMER_ID") 
;
--------------------------------------------------------
--  DDL for Index NOTIFICATION_SETTING_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "NOTIFICATION_SETTING_PK_IDX" ON "OUTAGE_NOTIFICATION_SETTING" ("ID") 
;

--------------------------------------------------------
--  DDL for Index ADMIN_ROLE_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ADMIN_ROLE_PK_IDX" ON "ADMIN_ROLE" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_COMMENT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_COMMENT_PK_IDX" ON "ISSUE_COMMENTS" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_USER_SUPPORT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISSUE_USER_SUPPORT_PK_IDX" ON "ISSUE_USER_SUPPORT" ("ID") 
;
  
--------------------------------------------------------
--  DDL for Index GIS_REGION_TYPE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "GIS_REGION_TYPE_PK" ON "GIS_REGION_TYPE" ("REGION_ID") 
;

--------------------------------------------------------
--  DDL for Index ADMIN_ALERT_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "ADMIN_ALERT_PK_IDX" ON "ADMIN_ALERT" ("ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUSRSPAM_IDX_USRID
--------------------------------------------------------

  CREATE INDEX "ISSUSRSPAM_IDX_USRID" ON "ISSUE_USER_SPAM" ("USER_ID") 
;
--------------------------------------------------------
--  DDL for Index ISSUE_IDX_LOBID
--------------------------------------------------------

  CREATE INDEX "ISSUE_IDX_LOBID" ON "ISSUE" ("LOB_ID") 
;
  
--------------------------------------------------------
--  DDL for Index OUT_DEV_IDX_OUTAGE_ID
--------------------------------------------------------

  CREATE INDEX "OUT_DEV_IDX_OUTAGE_ID" ON "OMS_OUTAGE_DEVICE" ("OUTAGE_ID") 
;

--------------------------------------------------------
--  DDL for Index OUT_DEV_IDX_DEVTYPE_ID
--------------------------------------------------------

  CREATE INDEX "OUT_DEV_IDX_DEVTYPE_ID" ON "OMS_OUTAGE_DEVICE" ("DEVICE_TYPE_ID") 
;
  
--------------------------------------------------------
--  DDL for Index CUST_USR_ACT_GAS_SVC_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "CUST_USR_ACT_GAS_SVC_PK_IDX" ON "CUST_USER_ACT_GAS_SVC" ("SERVICE_ID") 
;
--------------------------------------------------------
--  DDL for Index OUTAGE_DEVICE_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OUTAGE_DEVICE_PK_IDX" ON "OMS_OUTAGE_DEVICE" ("ID") 
;
--------------------------------------------------------
--  DDL for Index DEVICE_TYPE_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "DEVICE_TYPE_PK_IDX" ON "OMS_DEVICE_TYPE" ("ID") 
;
--------------------------------------------------------
--  DDL for Index SPOTLIGHT_FAIL_REQ_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPOTLIGHT_FAIL_REQ_PK_IDX" ON "SPOTLIGHT_FAILED_REQUEST" ("ID") 
;
  
--------------------------------------------------------
--  Constraints for Table ADMIN_ALERTS_AUDIT
--------------------------------------------------------

  ALTER TABLE "ADMIN_ALERTS_AUDIT" ADD CONSTRAINT "ADMIN_ALERT_AUDIT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ADMIN_ALERTS_AUDIT" MODIFY ("ALERT_NAME" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERTS_AUDIT" MODIFY ("ADMIN__LOGIN_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERTS_AUDIT" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERTS_AUDIT" MODIFY ("ALERT_BODY" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERTS_AUDIT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGES_REGIONS
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGES_REGIONS" ADD CONSTRAINT "OMS_OUT_REGION_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OMS_OUTAGES_REGIONS" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGES_REGIONS" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGES_REGIONS" MODIFY ("OUTAGE_REGION_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CUST_USER_ACT_ELEC_SVC
--------------------------------------------------------

  ALTER TABLE "CUST_USER_ACT_ELEC_SVC" ADD CONSTRAINT "USER_ACCOUNT_ELECTRIC_SER_PK" PRIMARY KEY ("SERVICE_ID");
  ALTER TABLE "CUST_USER_ACT_ELEC_SVC" MODIFY ("SERVICE_ACCOUNT_ID" NOT NULL ENABLE);
  ALTER TABLE "CUST_USER_ACT_ELEC_SVC" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "CUST_USER_ACT_ELEC_SVC" MODIFY ("PREMISE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OUTAGE_NOTIFICATION_SETTING
--------------------------------------------------------

  ALTER TABLE "OUTAGE_NOTIFICATION_SETTING" ADD CONSTRAINT "NOTIFICATION_SETTING_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OUTAGE_NOTIFICATION_SETTING" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_NOTIFICATION_SETTING" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_NOTIFICATION_SETTING" MODIFY ("NOTIFICATION_SETTING_ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table PHONE_TYPE
--------------------------------------------------------

  ALTER TABLE "PHONE_TYPE" ADD CONSTRAINT "PHONE_TYPE_PK" PRIMARY KEY ("ID");
  ALTER TABLE "PHONE_TYPE" MODIFY ("ID" NOT NULL ENABLE);
  
--------------------------------------------------------
--  Constraints for Table CUST_USER_PHONE_RECORD
--------------------------------------------------------

  ALTER TABLE "CUST_USER_PHONE_RECORD" ADD CONSTRAINT "CUST_USER_PHONE_RECORD_PK" PRIMARY KEY ("ID");
  ALTER TABLE "CUST_USER_PHONE_RECORD" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "CUST_USER_PHONE_RECORD" MODIFY ("CUSTOMER_USER_ID" NOT NULL ENABLE);
  ALTER TABLE "CUST_USER_PHONE_RECORD" MODIFY ("PHONE_TYPE_ID" NOT NULL ENABLE);
  ALTER TABLE "CUST_USER_PHONE_RECORD" MODIFY ("PHONE_NUMBER" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table ADMIN_ROLES_LOB_REF
--------------------------------------------------------

  ALTER TABLE "ADMIN_ROLES_LOB_REF" ADD CONSTRAINT "ADMIN_ROLE_LOB_PK" PRIMARY KEY ("ID");
  
  ALTER TABLE "ADMIN_ROLES_LOB_REF" MODIFY ("USER_ROLE_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ROLES_LOB_REF" MODIFY ("LOB_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ROLES_LOB_REF" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_CATEGORY_MS
--------------------------------------------------------

  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "ISSUE_CATEGORY_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_CATEGORY_MS" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_MS" MODIFY ("PRIORITY" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_MS" MODIFY ("CATEGORY_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_MS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CUST_USER_ACT_GAS_SVC
--------------------------------------------------------

  ALTER TABLE "CUST_USER_ACT_GAS_SVC" ADD CONSTRAINT "USER_ACCOUNT_GAS_SER_PK" PRIMARY KEY ("SERVICE_ID");
  ALTER TABLE "CUST_USER_ACT_GAS_SVC" MODIFY ("SERVICE_ACCOUNT_ID" NOT NULL ENABLE);
  ALTER TABLE "CUST_USER_ACT_GAS_SVC" MODIFY ("SERVICE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_COMMENTS
--------------------------------------------------------

  ALTER TABLE "ISSUE_COMMENTS" ADD CONSTRAINT "ISSUE_COMMENT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_COMMENTS" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_COMMENTS" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_COMMENTS" MODIFY ("TEXT" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_COMMENTS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_IMAGES
--------------------------------------------------------

  ALTER TABLE "ISSUE_IMAGES" ADD CONSTRAINT "ISSUE_IMAGES_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_IMAGES" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_IMAGES" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OUTAGE_USER_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "OUTAGE_USER_NOTIFICATION" ADD CONSTRAINT "OUTAGE_USER_NOTI_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OUTAGE_USER_NOTIFICATION" MODIFY ("NOTIFY_OPTION_TYPE" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_USER_NOTIFICATION" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_USER_NOTIFICATION" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_USER_NOTIFICATION" MODIFY ("OUTAGENUMBER" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_CATEGORY_GROUP
--------------------------------------------------------

  ALTER TABLE "ISSUE_CATEGORY_GROUP" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_GROUP" MODIFY ("GROUP_NAME" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_GROUP" ADD CONSTRAINT "ISSUE_CAT_GRP_PK" PRIMARY KEY ("ID");
--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_WORKFLOWS
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_WORKFLOWS" ADD CONSTRAINT "SPOTLIGHT_WORKFLOWS_PK" PRIMARY KEY ("ID");
  ALTER TABLE "SPOTLIGHT_WORKFLOWS" MODIFY ("IS_ASYNCHRONOUS" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_WORKFLOWS" MODIFY ("WORKFLOW_TYPE" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_WORKFLOWS" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_WORKFLOWS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_ADDRESS
--------------------------------------------------------

  ALTER TABLE "ISSUE_ADDRESS" ADD CONSTRAINT "ISSUE_ADDRESS_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_ADDRESS" MODIFY ("ZIP_CODE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_ADDRESS" MODIFY ("STATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_ADDRESS" MODIFY ("CITY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GIS_REGION_TYPE
--------------------------------------------------------

  ALTER TABLE "GIS_REGION_TYPE" ADD CONSTRAINT "GIS_REGION_TYPE_PK" PRIMARY KEY ("REGION_ID");
  ALTER TABLE "GIS_REGION_TYPE" MODIFY ("REGION_ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_DEVICE
--------------------------------------------------------

   ALTER TABLE "OMS_OUTAGE_DEVICE" ADD CONSTRAINT "OUTAGE_DEVICE_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OMS_OUTAGE_DEVICE" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE" MODIFY ("DEVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE" MODIFY ("DEVICE_TYPE_ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table OMS_DEVICE_TYPE
--------------------------------------------------------

  ALTER TABLE "OMS_DEVICE_TYPE" ADD CONSTRAINT "DEVICE_TYPE_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OMS_DEVICE_TYPE" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_DEVICE_TYPE" MODIFY ("DEVICE_TYPE" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_CUST_LOB
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_CUST_LOB" ADD CONSTRAINT "SPOTLIGHT_CUST_LOB_PK" PRIMARY KEY ("ID");
  ALTER TABLE "SPOTLIGHT_CUST_LOB" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUST_LOB" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUST_LOB" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GIS_REGIONS
--------------------------------------------------------

  ALTER TABLE "GIS_REGIONS" ADD CONSTRAINT "GIS_OUTAGES_REGION_PK" PRIMARY KEY ("ID");
  ALTER TABLE "GIS_REGIONS" MODIFY ("REGION_NAME" NOT NULL ENABLE);
  ALTER TABLE "GIS_REGIONS" MODIFY ("REGION_TYPE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table USER_ADDRESS
--------------------------------------------------------

  ALTER TABLE "USER_ADDRESS" ADD CONSTRAINT "USER_ADDRESS_PK" PRIMARY KEY ("ID");
  ALTER TABLE "USER_ADDRESS" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "USER_ADDRESS" MODIFY ("ZIP_CODE" NOT NULL ENABLE);
  ALTER TABLE "USER_ADDRESS" MODIFY ("STATE" NOT NULL ENABLE);
  ALTER TABLE "USER_ADDRESS" MODIFY ("CITY" NOT NULL ENABLE);
  ALTER TABLE "USER_ADDRESS" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_USER_SUPPORT
--------------------------------------------------------

  ALTER TABLE "ISSUE_USER_SUPPORT" ADD CONSTRAINT "ISSUE_USER_SUPPORT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_USER_SUPPORT" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_SUPPORT" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_SUPPORT" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_SUPPORT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OMS_CURRENT_OUTAGES
--------------------------------------------------------

  ALTER TABLE "OMS_CURRENT_OUTAGES" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_CURRENT_OUTAGES" ADD CONSTRAINT "STAGE_CURRENT_OUTAGES_PK" PRIMARY KEY ("OUTAGE_ID");
  ALTER TABLE "OMS_CURRENT_OUTAGES" MODIFY ("IS_REMOTE" DEFAULT 0 NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_CAUSE
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_CAUSE" ADD CONSTRAINT "OUTAGE_CAUSE_PK" PRIMARY KEY ("CAUSE_KEY");
  ALTER TABLE "OMS_OUTAGE_CAUSE" MODIFY ("CAUSE_KEY" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_CAUSE" MODIFY ("CAUSE_MSG" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_STATUS
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_STATUS" ADD CONSTRAINT "OUTAGE_STATUS_PK" PRIMARY KEY ("STATUS_KEY");
  ALTER TABLE "OMS_OUTAGE_STATUS" MODIFY ("STATUS_KEY" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_STATUS" MODIFY ("STATUS_MSG" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table ISSUE_CUSTOM_FIELD_REF
--------------------------------------------------------

  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" ADD CONSTRAINT "ISSUE_CUSTOM_FIELD_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" MODIFY ("BOOLEAN_FIELD" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" MODIFY ("CUSTOM_FIELD_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table LOB_ISSUE_CATEGORY_REF
--------------------------------------------------------

  ALTER TABLE "LOB_ISSUE_CATEGORY_REF" ADD CONSTRAINT "LOB_ISSUE_CAT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "LOB_ISSUE_CATEGORY_REF" MODIFY ("LOB_ID" NOT NULL ENABLE);
  ALTER TABLE "LOB_ISSUE_CATEGORY_REF" MODIFY ("ISSUE_CATGORY_ID" NOT NULL ENABLE);
  ALTER TABLE "LOB_ISSUE_CATEGORY_REF" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table API_KEY_MANAGEMENT
--------------------------------------------------------

  ALTER TABLE "API_KEY_MANAGEMENT" ADD CONSTRAINT "API_KEY_MANAGE_PK" PRIMARY KEY ("ACCESS_KEY");
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("IS_ACTIVE" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("VALID_TILL" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("VALID_FROM" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("LAST_MODIFED_DATE" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("SECRET_KEY" NOT NULL ENABLE);
  ALTER TABLE "API_KEY_MANAGEMENT" MODIFY ("ACCESS_KEY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "ISSUE_NOTIFICATION" ADD CONSTRAINT "ISSUE_NOTIFICATION_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_NOTIFICATION" MODIFY ("TYPE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_NOTIFICATION" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_NOTIFICATION" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_NOTIFICATION" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_NOTIFICATION" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table OUTAGE_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "OUTAGE_NOTIFICATION" ADD CONSTRAINT "OUTAGE_NOTIFICATION_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OUTAGE_NOTIFICATION" MODIFY ("TYPE" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_NOTIFICATION" MODIFY ("OUTAGE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_NOTIFICATION" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_NOTIFICATION" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "OUTAGE_NOTIFICATION" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table API_ASYNC_PROCESS_TRACK
--------------------------------------------------------

  ALTER TABLE "API_ASYNC_PROCESS_TRACK" ADD CONSTRAINT "API_ASYNC_PROCESS_PK" PRIMARY KEY ("ID");
  ALTER TABLE "API_ASYNC_PROCESS_TRACK" MODIFY ("PROCESS_STATUS" NOT NULL ENABLE);
  ALTER TABLE "API_ASYNC_PROCESS_TRACK" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "API_ASYNC_PROCESS_TRACK" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ADMIN_ALERT
--------------------------------------------------------

  ALTER TABLE "ADMIN_ALERT" ADD CONSTRAINT "ADMIN_ALERT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ADMIN_ALERT" MODIFY ("IS_ENABLED" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("ADMIN_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("PERIOD_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("ISSUE_COUNT" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("IS_SMS" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("IS_SENT" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("IS_REPEATABLE" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("IS_EMAIL" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("ALERT_NAME" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("ALERT_COUNT_CONDITION" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("PERIOD_CYCLE" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ALERT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CUSTOMER_USER
--------------------------------------------------------

  ALTER TABLE "CUSTOMER_USER" ADD CONSTRAINT "CUST_USER_PK" PRIMARY KEY ("EMAIL_ID");
  ALTER TABLE "CUSTOMER_USER" MODIFY ("EMAIL_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ADMIN_ROLES_REGION_REF
--------------------------------------------------------

  ALTER TABLE "ADMIN_ROLES_REGION_REF" ADD CONSTRAINT "ADMIN_ROLE_REG_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ADMIN_ROLES_REGION_REF" MODIFY ("USER_ROLE_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ROLES_REGION_REF" MODIFY ("REGION_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ROLES_REGION_REF" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_CUSTOMER
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_CUSTOMER" ADD CONSTRAINT "SPOTLIGHT_CUST_PK" PRIMARY KEY ("ID");
  ALTER TABLE "SPOTLIGHT_CUSTOMER" MODIFY ("WEB_URL" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUSTOMER" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUSTOMER" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ADMIN_ROLE
--------------------------------------------------------

  ALTER TABLE "ADMIN_ROLE" ADD CONSTRAINT "ADMIN_ROLE_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ADMIN_ROLE" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ROLE" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "ADMIN_ROLE" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CUSTOMER_USER_ACCOUNT
--------------------------------------------------------

  ALTER TABLE "CUSTOMER_USER_ACCOUNT" MODIFY ("ACCOUNT_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "CUSTOMER_USER_ACCOUNT" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "CUSTOMER_USER_ACCOUNT" ADD CONSTRAINT "CUST_USER_ACCOUNT_PK" PRIMARY KEY ("ACCOUNT_NUMBER");
--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_MESSAGE_TEXT
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_MESSAGE_TEXT" ADD CONSTRAINT "SPOTLIGHT_MSG_PK" PRIMARY KEY ("MSG_KEY");
  ALTER TABLE "SPOTLIGHT_MESSAGE_TEXT" MODIFY ("MSG_VALUE" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_MESSAGE_TEXT" MODIFY ("MSG_KEY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ADMIN
--------------------------------------------------------

  ALTER TABLE "ADMIN" ADD CONSTRAINT "ADMIN_PK" PRIMARY KEY ("LOGIN_ID");
  ALTER TABLE "ADMIN" MODIFY ("ACCESS_ROLE" NOT NULL ENABLE);
  ALTER TABLE "ADMIN" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "ADMIN" MODIFY ("LOGIN_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_CATEGORY_CUSTFIELD
--------------------------------------------------------

  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" ADD CONSTRAINT "ISSUE_CAT_CUSTFIELD_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("SERVICE_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("UI_CONTROL_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("IS_VISIBLE_ON_FORM" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("IS_VISIBLE_ON_DISPLAY" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("ISSUE_CATEGORY_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("XML_TAG_NAME" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("TITLE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("IS_MANDATORY" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("CUSTOM_FIELD_NAME" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("COLUMN_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_CUST_REGION
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_CUST_REGION" ADD CONSTRAINT "SPOTLIGHT_CUST_REG_PK" PRIMARY KEY ("ID");
  ALTER TABLE "SPOTLIGHT_CUST_REGION" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUST_REGION" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUST_REGION" MODIFY ("GEO_POINTS" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_CUST_REGION" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GLOBAL_PROPERTY_KEY_VALUE
--------------------------------------------------------

  ALTER TABLE "GLOBAL_PROPERTY_KEY_VALUE" ADD CONSTRAINT "GLOBAL_PROP_PK" PRIMARY KEY ("GLOBAL_KEY");
  ALTER TABLE "GLOBAL_PROPERTY_KEY_VALUE" MODIFY ("IS_EDITABLE_ON_UI" NOT NULL ENABLE);
  ALTER TABLE "GLOBAL_PROPERTY_KEY_VALUE" MODIFY ("UI_DISPLAY_NAME" NOT NULL ENABLE);
  ALTER TABLE "GLOBAL_PROPERTY_KEY_VALUE" MODIFY ("SHOW_ON_UI" NOT NULL ENABLE);
  ALTER TABLE "GLOBAL_PROPERTY_KEY_VALUE" MODIFY ("GLOBAL_VALUE" NOT NULL ENABLE);
  ALTER TABLE "GLOBAL_PROPERTY_KEY_VALUE" MODIFY ("GLOBAL_KEY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table NOTIFICATION_SETTING
--------------------------------------------------------

  ALTER TABLE "NOTIFICATION_SETTING" ADD CONSTRAINT "NOTI_SETTING_PK" PRIMARY KEY ("ID");
 
  ALTER TABLE "NOTIFICATION_SETTING" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_USER_SPAM
--------------------------------------------------------

  ALTER TABLE "ISSUE_USER_SPAM" ADD CONSTRAINT "ISSUE_USER_SPAM_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_USER_SPAM" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_SPAM" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_SPAM" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_SPAM" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE_AUDIT
--------------------------------------------------------

  ALTER TABLE "ISSUE_AUDIT" ADD CONSTRAINT "ISSUE_AUDIT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("PRIORITY" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("IS_SPAM" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("IS_PUBLIC" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_AUDIT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ISSUE
--------------------------------------------------------

  ALTER TABLE "ISSUE" ADD CONSTRAINT "ISSUE_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE" MODIFY ("IS_ARCHIVED" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("PRIORITY" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("LAST_STATUS_CHANGE_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("REGION_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("CUSTOMER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("IS_SPAM" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("ISSUE_CATEGORY_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("TITLE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("LONGITUDE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("LATITUDE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("LAST_MODIFIED_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("IS_PUBLIC" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_REQUEST_TRACK
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_REQUEST_TRACK" ADD CONSTRAINT "SPOTLIGHT_REQ_TRACK_PK" PRIMARY KEY ("ID");
  ALTER TABLE "SPOTLIGHT_REQUEST_TRACK" MODIFY ("REQUEST_TYPE" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_REQUEST_TRACK" MODIFY ("REQUEST_STATUS" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_REQUEST_TRACK" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_REQUEST_TRACK" MODIFY ("ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table SPOTLIGHT_FAILED_REQUEST
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_FAILED_REQUEST" ADD CONSTRAINT "SPOTLIGHT_FAIL_REQ_PK" PRIMARY KEY ("ID");
  ALTER TABLE "SPOTLIGHT_FAILED_REQUEST" MODIFY ("REQUEST_TYPE" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_FAILED_REQUEST" MODIFY ("REQUEST_STATUS" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_FAILED_REQUEST" MODIFY ("CREATION_DATE" NOT NULL ENABLE);
  ALTER TABLE "SPOTLIGHT_FAILED_REQUEST" MODIFY ("ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table ISSUE_USER_NOTIFICATION_REF
--------------------------------------------------------

  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" ADD CONSTRAINT "ISSUE_USER_NOTI_PK" PRIMARY KEY ("ID");
  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" MODIFY ("NOTIFY_OPTION_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" MODIFY ("ISSUE_ID" NOT NULL ENABLE);
  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table ADMIN
--------------------------------------------------------

  ALTER TABLE "ADMIN" ADD CONSTRAINT "FK_ADMIN_CUSTOMERID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
  ALTER TABLE "ADMIN" ADD CONSTRAINT "FK_ADMIN_USERID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
  ALTER TABLE "ADMIN" ADD CONSTRAINT "FK_ADMIN_USRROLEID" FOREIGN KEY ("USER_ROLE_ID")
	  REFERENCES "ADMIN_ROLE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ADMIN_ALERT
--------------------------------------------------------

  ALTER TABLE "ADMIN_ALERT" ADD CONSTRAINT "FK_ADMALRT_ADMID" FOREIGN KEY ("ADMIN_ID")
	  REFERENCES "ADMIN" ("LOGIN_ID") ENABLE;
  ALTER TABLE "ADMIN_ALERT" ADD CONSTRAINT "FK_ADMALRT_ISSCATID" FOREIGN KEY ("ISSUE_CATEGORY_ID")
	  REFERENCES "ISSUE_CATEGORY_MS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ADMIN_ROLE
--------------------------------------------------------

  ALTER TABLE "ADMIN_ROLE" ADD CONSTRAINT "FK_USRROLE_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ADMIN_ROLES_LOB_REF
--------------------------------------------------------

  ALTER TABLE "ADMIN_ROLES_LOB_REF" ADD CONSTRAINT "FK_USRROLLOBREF_LOBID" FOREIGN KEY ("LOB_ID")
	  REFERENCES "SPOTLIGHT_CUST_LOB" ("ID") ENABLE;
  ALTER TABLE "ADMIN_ROLES_LOB_REF" ADD CONSTRAINT "FK_USRROLLOBREF_USRROLID" FOREIGN KEY ("USER_ROLE_ID")
	  REFERENCES "ADMIN_ROLE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ADMIN_ROLES_REGION_REF
--------------------------------------------------------

  ALTER TABLE "ADMIN_ROLES_REGION_REF" ADD CONSTRAINT "FK_USROLREGREF_REGID" FOREIGN KEY ("REGION_ID")
	  REFERENCES "SPOTLIGHT_CUST_REGION" ("ID") ENABLE;
  ALTER TABLE "ADMIN_ROLES_REGION_REF" ADD CONSTRAINT "FK_USROLREGREF_USRROLID" FOREIGN KEY ("USER_ROLE_ID")
	  REFERENCES "ADMIN_ROLE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table API_KEY_MANAGEMENT
--------------------------------------------------------

  ALTER TABLE "API_KEY_MANAGEMENT" ADD CONSTRAINT "FK_APIKEYMGMT_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE
--------------------------------------------------------

  ALTER TABLE "ISSUE" ADD CONSTRAINT "FK_ISSUE_ASSID" FOREIGN KEY ("ASSIGNEE_ID")
	  REFERENCES "ADMIN" ("LOGIN_ID") ENABLE;
  ALTER TABLE "ISSUE" ADD CONSTRAINT "FK_ISSUE_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
  ALTER TABLE "ISSUE" ADD CONSTRAINT "FK_ISSUE_ISSCATID" FOREIGN KEY ("ISSUE_CATEGORY_ID")
	  REFERENCES "ISSUE_CATEGORY_MS" ("ID") ENABLE;
  ALTER TABLE "ISSUE" ADD CONSTRAINT "FK_ISSUE_LOBID" FOREIGN KEY ("LOB_ID")
	  REFERENCES "SPOTLIGHT_CUST_LOB" ("ID") ENABLE;
  ALTER TABLE "ISSUE" ADD CONSTRAINT "FK_ISSUE_RGNID" FOREIGN KEY ("REGION_ID")
	  REFERENCES "SPOTLIGHT_CUST_REGION" ("ID") ENABLE;
  ALTER TABLE "ISSUE" ADD CONSTRAINT "FK_ISSUE_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_AUDIT
--------------------------------------------------------

  ALTER TABLE "ISSUE_AUDIT" ADD CONSTRAINT "FK_ISSADT_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_CATEGORY_CUSTFIELD
--------------------------------------------------------

  ALTER TABLE "ISSUE_CATEGORY_CUSTFIELD" ADD CONSTRAINT "FK_CUSTCATCF_ISSUECATID" FOREIGN KEY ("ISSUE_CATEGORY_ID")
	  REFERENCES "ISSUE_CATEGORY_MS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_CATEGORY_GROUP
--------------------------------------------------------

  ALTER TABLE "ISSUE_CATEGORY_GROUP" ADD CONSTRAINT "FK_ISSCATGRP_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_CATEGORY_MS
--------------------------------------------------------

  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "FK_ISSCATMS_CREATEISSWRKFLW" FOREIGN KEY ("CREATE_ISSUE_WORKFLOW")
	  REFERENCES "SPOTLIGHT_WORKFLOWS" ("ID") ENABLE;
  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "FK_ISSCATMS_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "FK_ISSCATMS_DEFASS" FOREIGN KEY ("DEFAULT_ASSIGNEE")
	  REFERENCES "ADMIN_ROLE" ("ID") ENABLE;
  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "FK_ISSCATMS_ISSCATGRPID" FOREIGN KEY ("ISSUE_CATEGORY_GROUP_ID")
	  REFERENCES "ISSUE_CATEGORY_GROUP" ("ID") ENABLE;
  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "FK_ISSCATMS_SEARCHISSWRKFLW" FOREIGN KEY ("SEARCH_ISSUE_WORKFLOW")
	  REFERENCES "SPOTLIGHT_WORKFLOWS" ("ID") ENABLE;
  ALTER TABLE "ISSUE_CATEGORY_MS" ADD CONSTRAINT "FK_ISSCATMS_UPDATEISSWRKFLW" FOREIGN KEY ("UPDATE_ISSUE_WORKFLOW")
	  REFERENCES "SPOTLIGHT_WORKFLOWS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_COMMENTS
--------------------------------------------------------

  ALTER TABLE "ISSUE_COMMENTS" ADD CONSTRAINT "FK_ISSCOMM_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
  ALTER TABLE "ISSUE_COMMENTS" ADD CONSTRAINT "FK_ISSCOMM_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_CUSTOM_FIELD_REF
--------------------------------------------------------

  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" ADD CONSTRAINT "FK_ISSCFREF_CFID" FOREIGN KEY ("CUSTOM_FIELD_ID")
	  REFERENCES "ISSUE_CATEGORY_CUSTFIELD" ("ID") ENABLE;
  ALTER TABLE "ISSUE_CUSTOM_FIELD_REF" ADD CONSTRAINT "FK_ISSCFREF_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_IMAGES
--------------------------------------------------------

  ALTER TABLE "ISSUE_IMAGES" ADD CONSTRAINT "FK_ISSIMG_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "ISSUE_NOTIFICATION" ADD CONSTRAINT "FK_NOTF_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_USER_NOTIFICATION_REF
--------------------------------------------------------

  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" ADD CONSTRAINT "FK_ISSUSRNOTREF_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
  ALTER TABLE "ISSUE_USER_NOTIFICATION_REF" ADD CONSTRAINT "FK_ISSUSRNOTREF_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_USER_SPAM
--------------------------------------------------------

  ALTER TABLE "ISSUE_USER_SPAM" ADD CONSTRAINT "FK_ISSUSRSPAM_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
  ALTER TABLE "ISSUE_USER_SPAM" ADD CONSTRAINT "FK_ISSUSRSPAM_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ISSUE_USER_SUPPORT
--------------------------------------------------------

  ALTER TABLE "ISSUE_USER_SUPPORT" ADD CONSTRAINT "FK_ISSUSRSUPP_ISSUEID" FOREIGN KEY ("ISSUE_ID")
	  REFERENCES "ISSUE" ("ID") ENABLE;
  ALTER TABLE "ISSUE_USER_SUPPORT" ADD CONSTRAINT "FK_ISSUSRSUPP_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table LOB_ISSUE_CATEGORY_REF
--------------------------------------------------------

  ALTER TABLE "LOB_ISSUE_CATEGORY_REF" ADD CONSTRAINT "FK_LOBISSCATREF_ISSCATID" FOREIGN KEY ("ISSUE_CATGORY_ID")
	  REFERENCES "ISSUE_CATEGORY_MS" ("ID") ENABLE;
  ALTER TABLE "LOB_ISSUE_CATEGORY_REF" ADD CONSTRAINT "FK_LOBISSCATREF_LOBID" FOREIGN KEY ("LOB_ID")
	  REFERENCES "SPOTLIGHT_CUST_LOB" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OUTAGE_USER_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "OUTAGE_USER_NOTIFICATION" ADD CONSTRAINT "FK_OUTUSRNOTREF_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table SPOTLIGHT_CUST_LOB
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_CUST_LOB" ADD CONSTRAINT "FK_LOB_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table SPOTLIGHT_CUST_REGION
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_CUST_REGION" ADD CONSTRAINT "FK_REGION_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
  ALTER TABLE "SPOTLIGHT_CUST_REGION" ADD CONSTRAINT "FK_REGION_PARENTID" FOREIGN KEY ("PARENT_ID")
	  REFERENCES "SPOTLIGHT_CUST_REGION" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table SPOTLIGHT_WORKFLOWS
--------------------------------------------------------

  ALTER TABLE "SPOTLIGHT_WORKFLOWS" ADD CONSTRAINT "FK_RASWRKFLWS_CUSTID" FOREIGN KEY ("CUSTOMER_ID")
	  REFERENCES "SPOTLIGHT_CUSTOMER" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table USER_ADDRESS
--------------------------------------------------------

  ALTER TABLE "USER_ADDRESS" ADD CONSTRAINT "FK_USRADD_USRID" FOREIGN KEY ("USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table OMS_OUTAGE_DEVICE
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_DEVICE" ADD CONSTRAINT "FK_OUTDEV_DEVTYPEID" FOREIGN KEY ("DEVICE_TYPE_ID")
	  REFERENCES "OMS_DEVICE_TYPE" ("ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table GIS_REGIONS
--------------------------------------------------------

  ALTER TABLE "GIS_REGIONS" ADD CONSTRAINT "GIS_OUT_REGION_REG_TYPE_FK" FOREIGN KEY ("REGION_TYPE_ID")
	  REFERENCES "GIS_REGION_TYPE" ("REGION_ID") ENABLE;

--------------------------------------------------------
--  Ref Constraints for Table CUST_USER_PHONE_RECORD
--------------------------------------------------------

  ALTER TABLE "CUST_USER_PHONE_RECORD" ADD CONSTRAINT "CUST_USER_PH_CUSTUSER_FK1" FOREIGN KEY ("CUSTOMER_USER_ID")
	  REFERENCES "CUSTOMER_USER" ("EMAIL_ID") ENABLE;
 
  ALTER TABLE "CUST_USER_PHONE_RECORD" ADD CONSTRAINT "CUST_USER_PH_PHTYPE_FK1" FOREIGN KEY ("PHONE_TYPE_ID")
	  REFERENCES "PHONE_TYPE" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OUTAGE_NOTIFICATION_SETTING
--------------------------------------------------------

  ALTER TABLE "OUTAGE_NOTIFICATION_SETTING" ADD CONSTRAINT "OUTAGE_NOTIFICATION_SETTI_FK1" FOREIGN KEY ("NOTIFICATION_SETTING_ID")
	  REFERENCES "NOTIFICATION_SETTING" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table OMS_OUTAGES_REGIONS
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGES_REGIONS" ADD CONSTRAINT "OMS_OUT_REGION_GIS_REG_FK" FOREIGN KEY ("OUTAGE_REGION_ID")
	  REFERENCES "GIS_REGIONS" ("ID") ENABLE;
  ALTER TABLE "OMS_OUTAGES_REGIONS" ADD CONSTRAINT "OMS_OUT_REGION_OUTAGE_FK" FOREIGN KEY ("OUTAGE_ID")
	  REFERENCES "OMS_CURRENT_OUTAGES" ("OUTAGE_ID") ENABLE;