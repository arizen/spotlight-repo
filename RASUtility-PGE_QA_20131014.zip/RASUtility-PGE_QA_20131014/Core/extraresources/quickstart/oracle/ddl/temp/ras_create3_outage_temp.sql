--------------------------------------------------------
--  DDL for Table OMS_CURRENT_OUTAGES_TMP
--------------------------------------------------------

  CREATE TABLE "OMS_CURRENT_OUTAGES_TMP" 
   (	"OUTAGE_ID" NUMBER(10,0), 
	"OUTAGE_EXTENT" VARCHAR2(20 BYTE), 
	"OUTAGE_DEVICE_ID" VARCHAR2(100 BYTE), 
	"OUTAGE_DEVICE_NAME" VARCHAR2(100 BYTE), 
	"OUTAGE_CIRCUIT_ID" VARCHAR2(100 BYTE), 
	"OUTAGE_START" TIMESTAMP (6), 
	"CREW_ETA" TIMESTAMP (6), 
	"CREW_CURRENT_STATUS" VARCHAR2(100 BYTE), 
	"AUTO_ETOR" TIMESTAMP (6), 
	"CURRENT_ETOR" TIMESTAMP (6), 
	"OUTAGE_CAUSE" VARCHAR2(100 BYTE), 
	"EST_CUSTOMERS" NUMBER, 
	"LAST_UPDATE" TIMESTAMP (6), 
	"HAZARD_FLAG" NUMBER, 
	"OUTAGE_LATITUDE" FLOAT(126), 
	"OUTAGE_LONGITUDE" FLOAT(126)
   );
  
--------------------------------------------------------
--  DDL for Index STAGE_OUTAGES_TMP_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "STAGE_OUTAGES_TMP_PK_IDX" ON "OMS_CURRENT_OUTAGES_TMP" ("OUTAGE_ID");
  
--------------------------------------------------------
--  Constraints for Table OMS_CURRENT_OUTAGES_TMP
--------------------------------------------------------

  ALTER TABLE "OMS_CURRENT_OUTAGES_TMP" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_CURRENT_OUTAGES_TMP" ADD CONSTRAINT "STAGE_OUTAGES_TMP_PK" PRIMARY KEY ("OUTAGE_ID")

--------------------------------------------------------
--  DDL for Table OMS_OUTAGE_DEVICE_TMP
--------------------------------------------------------

  CREATE TABLE "OMS_OUTAGE_DEVICE_TMP" 
   ( "ID" NUMBER,	
   "DEVICE_ID" VARCHAR2(100 BYTE), 
	"DEVICE_NAME" VARCHAR2(100 BYTE),
	"LATITUDE" FLOAT(126), 
	"LONGITUDE" FLOAT(126),
	"CIRCUIT_ID" VARCHAR2(100 BYTE),
	"OUTAGE_ID" NUMBER(10,0),
	"DEVICE_TYPE_ID" NUMBER(10,0)
   );
   
--------------------------------------------------------
--  DDL for Index OUTAGE_DEVICE__TMP_PK_IDX
--------------------------------------------------------

  CREATE UNIQUE INDEX "OUTAGE_DEVICE__TMP_PK_IDX" ON "OMS_OUTAGE_DEVICE_TMP" ("ID") ;

--------------------------------------------------------
--  DDL for Index OUT_DEV__TMP_IDX_DEVTYPE_ID
--------------------------------------------------------

  CREATE INDEX "OUT_DEV__TMP_IDX_DEVTYPE_ID" ON "OMS_OUTAGE_DEVICE_TMP" ("DEVICE_TYPE_ID") ;
--------------------------------------------------------
--  Constraints for Table OMS_OUTAGE_DEVICE_TMP
--------------------------------------------------------

   ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" ADD CONSTRAINT "OUTAGE_DEVICE_TMP_PK" PRIMARY KEY ("ID");
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("DEVICE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("OUTAGE_ID" NOT NULL ENABLE);
  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" MODIFY ("DEVICE_TYPE_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table OMS_OUTAGE_DEVICE_TMP
--------------------------------------------------------

  ALTER TABLE "OMS_OUTAGE_DEVICE_TMP" ADD CONSTRAINT "FK_OUTDEV_TMP_DEVTYPEID" FOREIGN KEY ("DEVICE_TYPE_ID")
	  REFERENCES "OMS_DEVICE_TYPE" ("ID") ENABLE;
	  
	  commit;


