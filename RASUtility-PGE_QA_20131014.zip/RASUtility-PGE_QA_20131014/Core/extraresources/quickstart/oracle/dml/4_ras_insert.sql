--SPOTLIGHT_RULE_GROUP
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,message_key,group_type,is_hard,priority) values ('GLOBAL','user.accounts.custom.all.retrieve.rules.globalrulefailed',0, 1,1);
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY,is_hard) values ('INELIGIBLE_TO_PAY',0,'user.accounts.custom.all.retrieve.rules.ineligibletopay',1);
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY,is_hard) values ('SONP',0,'user.accounts.custom.all.retrieve.rules.sonp',1);
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY,is_hard) values ('NO_STATEMENTS',0,'user.accounts.custom.all.retrieve.rules.nostatements',1);
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY) values ('PAYMENTS_PENDING',0,'user.accounts.custom.all.retrieve.rules.pendingpayments');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY) values ('RECURRING_PAYMENT_APS',0,'user.accounts.custom.all.retrieve.rules.recurringpaymentsAPS');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY) values ('LARGE_CUSTOMER',0,'user.accounts.custom.all.retrieve.rules.largecustomer');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY) values ('OTHERS',0,'user.accounts.custom.all.retrieve.rules.others');
INSERT INTO SPOTLIGHT_RULE_GROUP (GROUP_NAME,group_type,MESSAGE_KEY) VALUES ('INELIGIBLE_TO_PAY_BY_BANK',0, 'user.accounts.custom.rules.inelligibleToPay');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,message_key,group_type,is_hard,priority,parent_group_name) values ('HARD_GROUP_1','user.accounts.custom.all.retrieve.rules.hardgroup1',1, 1,-9999,'INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_RULE_GROUP (GROUP_NAME,message_key,group_type,is_hard,priority,parent_group_name) values ('HARD_GROUP_2','user.accounts.custom.all.retrieve.rules.hardgroup2',1, 1,-9999,'INELIGIBLE_TO_PAY');


-- SPOTLIGHT_USER_ACCOUNT_RULE
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('100','Password account','GLOBAL');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('124','Fraud','GLOBAL');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('104','Closed account with no balance','INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('106','RTM in the last 30 days','INELIGIBLE_TO_PAY_BY_BANK');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('135','2 RTMs in last 365 days','INELIGIBLE_TO_PAY_BY_BANK');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('152','Bankruptcy','INELIGIBLE_TO_PAY');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('118','Automatic Payment Setup (APS)','RECURRING_PAYMENT_APS');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('103','SONP','SONP');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('186','Large Customer','LARGE_CUSTOMER');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('Pending','Pending Payments','PAYMENTS_PENDING');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('Recurring','Recurring Payments','RECURRING_PAYMENT_APS');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('NO_STATEMENTS','No Statements','NO_STATEMENTS');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('186','Large Customer','HARD_GROUP_1');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('106','RTM in the last 30 days','HARD_GROUP_1');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('186','Large Customer','HARD_GROUP_2');
Insert into SPOTLIGHT_USER_ACCOUNT_RULE (RULE_KEY,RULE_INFO,USER_ACCOUNT_RULE_GROUP) values ('135','RTM in the last 30 days','HARD_GROUP_2');


commit;