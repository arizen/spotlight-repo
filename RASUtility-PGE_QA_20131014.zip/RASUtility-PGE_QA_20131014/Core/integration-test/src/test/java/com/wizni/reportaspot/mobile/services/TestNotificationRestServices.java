/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services;

import org.javatuples.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wizni.reportaspot.utility.JSONParserCheck;

/**
 * The Class TestAllServices.
 * 
 * @author Abhishek Chavan
 * @version $Revision: 1.0 $
 */
@SuppressWarnings("unchecked")
public class TestNotificationRestServices {
	
	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(TestNotificationRestServices.class);

	/** The Constant strUrl. */
	// public static final String strUrl = "http://dev.reportaspot.com/V2/mobile/services/notifications";

	public static final String strUrl = "http://localhost:8080/reportaspotdispatch/V2/mobile/services";

	/** The Constant FORBIDDEN_RESULT. */
	public static final Integer FORBIDDEN_RESULT = Integer.valueOf(403);

	/** The Constant OK_RESULT. */
	public static final Integer OK_RESULT = Integer.valueOf(200);

	/** The Constant header. */
	private static final Pair<String, String> header = new Pair<String, String>(
			"SECAPIKEY",
			"BCC320BB77E65ECBD7AF14844676A4CDF63A0DECB8B96A4F1101F7CE1C83749DA4D24331A26C79847D15C634902656F0AB8063C9D2C8ED743F4960E9788C7850;f8aa9c80a9c40e96c016e76f314341d1075505b3;1354527977");

	/** The Constant userKeyHeader. */
	private static final Pair<String, String> userKeyHeader = new Pair<String, String>("X-RAS-API-USERKEY", "reportaspotUser1");

	/** The Constant passKeyHeader. */
	private static final Pair<String, String> passKeyHeader = new Pair<String, String>("X-RAS-API-PASSKEY", "reportaspot@123");

	/**
	 * Setup.
	 */
	@Before
	public void setup() {

	}

	/**
	 * Test register notification with headers.
	 */
	@Test
	public void testRegisterNotificationWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/issues/", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"serviceIssue\": {\"reportId\": \""
					+ JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"reporter\": { \"emailId\": \"harish@wizni.com\" },\"notification\": {\"sms\": \"0\",\"email\": \"1\",\"localNotification\": \"1\",\"pushNotification\": \"1\",\"notifyOption\": 0}}}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/notifications/register", xmlToPost, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testRegisterNotificationWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testRegisterNotificationWithHeaders failed");
		}
	}

	/**
	 * Test unregister notification with headers.
	 */
	@Test
	public void testUnRegisterNotificationWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/issues/", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"serviceIssue\": {\"reportId\": \""
					+ JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"reporter\": { \"emailId\": \"harish@wizni.com\" },\"notification\": {\"sms\": \"0\",\"email\": \"0\",\"localNotification\": \"0\",\"pushNotification\": \"0\",\"notifyOption\": 0}}}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/notifications/unregister", xmlToPost, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testUnRegisterNotificationWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testUnRegisterNotificationWithHeaders failed");
		}
	}

}
