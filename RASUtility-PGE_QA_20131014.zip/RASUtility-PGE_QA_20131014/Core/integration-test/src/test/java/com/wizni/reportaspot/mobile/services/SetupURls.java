/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services;

import java.io.IOException;
import java.util.Properties;

import org.junit.Before;

/**
 * @author WizniDev
 * 
 */
public class SetupURls {

	public static String strUrl;

	@Before
	public void init() throws IOException {
		Properties properties = new Properties();
		properties.load(SetupURls.class.getResourceAsStream("/urls.properties"));
		strUrl = properties.getProperty("url");
	}
}
