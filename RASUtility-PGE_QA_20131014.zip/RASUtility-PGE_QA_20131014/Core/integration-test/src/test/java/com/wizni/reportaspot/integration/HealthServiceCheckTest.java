/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.junit.Test;

/**
 * The Class HealthServiceCheckTest.
 */
public class HealthServiceCheckTest {

    /**
     * Check service availability.
     * 
     * @throws Exception the exception
     */
    @Test
    public void checkServiceAvailability() throws Exception{
        ReportASpotServiceClient serviceClient=new ReportASpotServiceClient();
        Map<String, String> headers=new HashMap<String, String>();
        headers.put("Accept", "text/html");
        HttpResponse response = serviceClient.executeGetRequest("http://dev.reportaspot.com/health/ping", headers);
        int statusCode = response.getStatusLine().getStatusCode();
        List<?> lines = IOUtils.readLines(response.getEntity().getContent());
        assertEquals(200,statusCode);
        assertNotNull(lines);
        assertEquals("pong",lines.get(0));
    }
}
