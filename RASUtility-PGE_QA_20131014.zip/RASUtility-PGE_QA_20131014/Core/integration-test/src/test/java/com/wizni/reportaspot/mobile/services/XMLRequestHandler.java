/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.javatuples.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class PostXML.
 * 
 * @author Abhishek Chavan
 */
public class XMLRequestHandler {
	
	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(XMLRequestHandler.class);

	/**
	 * Post xml.
	 * 
	 * @param strURL the str url
	 * @param strXMLFilename the str xml filename
	 * @param headerKeyValue the header key value
	 * @param moreHeaders the more headers
	 * @return the pair
	 * @throws FileNotFoundException the file not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws HttpException the http exception
	 */
	public static Pair<Integer, String> postXML(String strURL, String strXMLFilename, Pair<String, String> headerKeyValue,
			Pair<String, String>... moreHeaders) throws FileNotFoundException, IOException, HttpException {
		// Get target URL
		// Get file to be posted
		// Prepare HTTP post
		HttpPost post = new HttpPost(strURL);

		// Request content will be retrieved directly
		// from the input stream
		// Per default, the request content needs to be buffered
		// in order to determine its length.
		// Request body buffering can be avoided when
		// content length is explicitly specified

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		IOUtils.copy(XMLRequestHandler.class.getResourceAsStream(strXMLFilename), out);

		post.setEntity(new ByteArrayEntity(out.toByteArray()));
		if (headerKeyValue != null) {
			post.addHeader(headerKeyValue.getValue0(), headerKeyValue.getValue1());
			post.addHeader("accept", "application/xml");

			if (moreHeaders != null) {
				for (Pair<String, String> hhh : moreHeaders) {
					post.addHeader(hhh.getValue0(), hhh.getValue1());
				}
			}
		}

		// Specify content type and encoding
		// If content encoding is not explicitly specified
		// ISO-8859-1 is assumed
		// post.setRequestHeader(
		// "Content-type", "text/xml; charset=ISO-8859-1");

		// Get HTTP client
		HttpClient httpclient = new DefaultHttpClient();

		// Execute request
		try {

			HttpResponse result = httpclient.execute(post);

			// Display status code
			// Display response

			ByteArrayOutputStream out2 = new ByteArrayOutputStream();
			IOUtils.copy(result.getEntity().getContent(), out2);
			if (logger.isDebugEnabled()) {
				logger.debug("postXML(String, String, Pair<String,String>, Pair<String,String>) - {}", out2.toString()); //$NON-NLS-1$
			}
			return new Pair<Integer, String>(result.getStatusLine().getStatusCode(), out2.toString());
		} finally {
			// Release current connection to the connection pool
			// once you are done
		}

	}

	/**
	 * Post xml.
	 *
	 * @param strURL the str url
	 * @param data the data
	 * @param headerKeyValue the header key value
	 * @param moreHeaders the more headers
	 * @return the pair
	 * @throws FileNotFoundException the file not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws HttpException the http exception
	 */
	public static Pair<Integer, String> postXMLWithString(String strURL, String data, Pair<String, String> headerKeyValue,
			Pair<String, String>... moreHeaders) throws FileNotFoundException, IOException, HttpException {
		// Get target URL
		// Get file to be posted
		// Prepare HTTP post
		HttpPost post = new HttpPost(strURL);

		// Request content will be retrieved directly
		// from the input stream
		// Per default, the request content needs to be buffered
		// in order to determine its length.
		// Request body buffering can be avoided when
		// content length is explicitly specified

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		out.write(data.getBytes());

		post.setEntity(new ByteArrayEntity(out.toByteArray()));
		if (headerKeyValue != null) {
			post.addHeader(headerKeyValue.getValue0(), headerKeyValue.getValue1());
			post.addHeader("accept", "application/xml");

			if (moreHeaders != null) {
				for (Pair<String, String> hhh : moreHeaders) {
					post.addHeader(hhh.getValue0(), hhh.getValue1());
				}
			}
		}

		// Specify content type and encoding
		// If content encoding is not explicitly specified
		// ISO-8859-1 is assumed
		// post.setRequestHeader(
		// "Content-type", "text/xml; charset=ISO-8859-1");

		// Get HTTP client
		HttpClient httpclient = new DefaultHttpClient();

		// Execute request
		try {

			HttpResponse result = httpclient.execute(post);

			// Display status code
			// Display response

			ByteArrayOutputStream out2 = new ByteArrayOutputStream();
			IOUtils.copy(result.getEntity().getContent(), out2);
			if (logger.isDebugEnabled()) {
				logger.debug("postXML(String, String, Pair<String,String>, Pair<String,String>) - {}", out2.toString()); //$NON-NLS-1$
			}
			return new Pair<Integer, String>(result.getStatusLine().getStatusCode(), out2.toString());
		} finally {
			// Release current connection to the connection pool
			// once you are done
		}

	}

	/**
	 * Gets the xml.
	 *
	 * @param strURL the str url
	 * @param requestParams the request params
	 * @param headerKeyValue the header key value
	 * @param moreHeaders the more headers
	 * @return the xml
	 * @throws URISyntaxException the uRI syntax exception
	 * @throws ClientProtocolException the client protocol exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static Pair<Integer, String> getXML(String strURL, List<Pair<String, String>> requestParams,
			Pair<String, String> headerKeyValue, Pair<String, String>... moreHeaders) throws URISyntaxException, ClientProtocolException,
			IOException {

		HttpGet get = new HttpGet(strURL);
		URIBuilder uriBuilder = new URIBuilder(get.getURI());

		if (requestParams != null && !requestParams.isEmpty()) {
			for (Pair<String, String> pair : requestParams) {
				uriBuilder.addParameter(pair.getValue0(), pair.getValue1());
			}
		}

		get.setURI(uriBuilder.build());

		if (headerKeyValue != null) {
			get.addHeader(headerKeyValue.getValue0(), headerKeyValue.getValue1());
			get.addHeader("accept", "application/xml");

			if (moreHeaders != null) {
				for (Pair<String, String> hhh : moreHeaders) {
					get.addHeader(hhh.getValue0(), hhh.getValue1());
				}
			}
		}

		HttpClient httpClient = new DefaultHttpClient();
		HttpResponse result = httpClient.execute(get);

		// Display status code
		// Display response

		ByteArrayOutputStream out2 = new ByteArrayOutputStream();
		IOUtils.copy(result.getEntity().getContent(), out2);
		if (logger.isDebugEnabled()) {
			logger.debug("getXML(String, String, Pair<String,String>, Pair<String,String>) - {}", out2.toString()); //$NON-NLS-1$
		}
		return new Pair<Integer, String>(result.getStatusLine().getStatusCode(), out2.toString());
	}
}
