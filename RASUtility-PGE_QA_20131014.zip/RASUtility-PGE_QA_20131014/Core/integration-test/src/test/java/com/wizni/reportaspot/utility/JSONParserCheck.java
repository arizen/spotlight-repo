/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.utility;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

import com.jayway.jsonpath.JsonPath;

/**
 * The Class JSONParserCheck.
 *
 * @author Abhishek Chavan
 */
public class JSONParserCheck {

	/**
	 * Checks if is jSON valid.
	 *
	 * @param json the json
	 * @return true, if is jSON valid
	 * @throws SAXException the sAX exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ParserConfigurationException the parser configuration exception
	 * @throws XPathExpressionException the x path expression exception
	 */
	public static boolean isJSONValid(String json) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException {
		Boolean isSucess = JsonPath.read(json, "$..isSuccess[0]");
		return isSucess;
	}

	/**
	 * Gets the report id.
	 *
	 * @param json the json
	 * @return the report id
	 * @throws SAXException the sAX exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ParserConfigurationException the parser configuration exception
	 * @throws XPathExpressionException the x path expression exception
	 */
	public static String getReportId(String json) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException {
		String isSucess = JsonPath.read(json, "$..generatedId[0]");
		return isSucess;
	}
}
