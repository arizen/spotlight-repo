/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;



/**
 * The Class SendJson.
 * 
 * @author Abhishek Chavan
 */
public class SendJson {
	
	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(SendJson.class);


    /**
     * Post json.
     * 
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void  postJson() throws IOException {
        // Get target URL
        // Get file to be posted
        // Prepare HTTP post
        HttpPost post = new HttpPost("http://localhost:8080/reportaspot/health/jsonHit");

        // Request content will be retrieved directly
        // from the input stream
        // Per default, the request content needs to be buffered
        // in order to determine its length.
        // Request body buffering can be avoided when
        // content length is explicitly specified
        post.setEntity(new StringEntity("{\"latitude\":\"123\",\"longitude\" : \"212\"}"));

        // Specify content type and encoding
        // If content encoding is not explicitly specified
        // ISO-8859-1 is assumed
        // post.setRequestHeader(
        // "Content-type", "text/xml; charset=ISO-8859-1");

        post.setHeader("Content-type", "application/json");

        // Get HTTP client
        HttpClient httpclient = new DefaultHttpClient();

        // Execute request
        try {

            HttpResponse result  = httpclient.execute(post);

            // Display status code
            // Display response
			if (logger.isDebugEnabled()) {
				logger.debug("postJson() - {}", result.getEntity().getContent()); //$NON-NLS-1$
			}
        } finally {
            // Release current connection to the connection pool
            // once you are done
        }

    }

    /**
     * The main method.
     * 
     * @param args the arguments
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void main(String[] args) throws IOException {
        postJson();
    }


}
