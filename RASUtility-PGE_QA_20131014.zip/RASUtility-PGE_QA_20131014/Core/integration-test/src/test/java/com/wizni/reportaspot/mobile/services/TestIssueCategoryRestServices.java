/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services;

import org.javatuples.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wizni.reportaspot.utility.JSONParserCheck;

/**
 * The Class TestAllServices.
 * 
 * @author Abhishek Chavan
 * @version $Revision: 1.0 $
 */
@SuppressWarnings("unchecked")
public class TestIssueCategoryRestServices {
	
	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(TestIssueCategoryRestServices.class);

	/** The Constant strUrl. */
	// public static final String strUrl = "http://dev.reportaspot.com/V2/mobile/services/issuecategories";

	public static final String strUrl = "http://localhost:8080/reportaspotdispatch/V2/mobile/services/issuecategories";

	/** The Constant FORBIDDEN_RESULT. */
	public static final Integer FORBIDDEN_RESULT = Integer.valueOf(403);

	/** The Constant OK_RESULT. */
	public static final Integer OK_RESULT = Integer.valueOf(200);

	/** The Constant header. */
	private static final Pair<String, String> header = new Pair<String, String>(
			"SECAPIKEY",
			"BCC320BB77E65ECBD7AF14844676A4CDF63A0DECB8B96A4F1101F7CE1C83749DA4D24331A26C79847D15C634902656F0AB8063C9D2C8ED743F4960E9788C7850;f8aa9c80a9c40e96c016e76f314341d1075505b3;1354527977");

	/** The Constant userKeyHeader. */
	private static final Pair<String, String> userKeyHeader = new Pair<String, String>("X-RAS-API-USERKEY", "reportaspotUser1");

	/** The Constant passKeyHeader. */
	private static final Pair<String, String> passKeyHeader = new Pair<String, String>("X-RAS-API-PASSKEY", "reportaspot@123");

	/**
	 * Setup.
	 */
	@Before
	public void setup() {

	}

	/**
	 * Test get category metadata with headers.
	 */
	@Test
	public void testGetCategoryMetadataWithHeaders() {

		try {
			Long categoryId = new Long(7);

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/" + categoryId.toString(), null, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetCategoryMetadataWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetCategoryMetadataWithHeaders failed");
		}
	}

	/**
	 * Test get service categories with headers.
	 */
	@Test
	public void testGetServiceCategoriesWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/", null, header, userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetServiceCategoriesWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetServiceCategoriesWithHeaders failed");
		}
	}

}
