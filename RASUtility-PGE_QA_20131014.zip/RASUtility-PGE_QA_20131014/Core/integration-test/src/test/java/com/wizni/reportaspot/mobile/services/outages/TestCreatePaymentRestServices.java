/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services.outages;

import org.javatuples.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wizni.reportaspot.mobile.services.JSONRequestHandler;
import com.wizni.reportaspot.mobile.services.SetupURls;
import com.wizni.reportaspot.utility.JSONParserCheck;

/**
 * The Class TestAllServices.
 * 
 * @author Abhishek Chavan
 * @version $Revision: 1.0 $
 */
@SuppressWarnings("unchecked")
public class TestCreatePaymentRestServices extends SetupURls {

	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(TestSearchByPhoneOutageRestServices.class);

	/** The Constant FORBIDDEN_RESULT. */
	public static final Integer FORBIDDEN_RESULT = Integer.valueOf(403);

	/** The Constant OK_RESULT. */
	public static final Integer OK_RESULT = Integer.valueOf(200);

	/** The Constant header. */
	private static final Pair<String, String> header = new Pair<String, String>(
			"SA_USER",
			"mekauser0713_1");

	/** The Constant userKeyHeader. */
	private static final Pair<String, String> userKeyHeader = new Pair<String, String>("X-RAS-API-USERKEY", "reportaspotUser1");

	/** The Constant passKeyHeader. */
	private static final Pair<String, String> passKeyHeader = new Pair<String, String>("X-RAS-API-PASSKEY", "reportaspot@123");

	String strUrl = "localhost:8081/reportadispatch";
	/**
	 * Setup.
	 */
	@Before
	public void setup() {

	}

	/**
	 * Test phone search report with headers.
	 */
	@Test
	public void testCreatePayment() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON("http://localhost:7001/reportaspotdispatch/ras/secure/v2/accounts/1/payments",
					"/jsonfiles/accounts/createPayment.json", header, userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testPhoneSearchReportWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testPhoneSearchReportWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testPhoneSearchReportWithHeaders failed");
		}
	}
}

