/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.mobile.services;

import java.util.ArrayList;
import java.util.List;

import org.javatuples.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wizni.reportaspot.utility.JSONParserCheck;

/**
 * The Class TestAllServices.
 * 
 * @author Abhishek Chavan
 * @version $Revision: 1.0 $
 */
@SuppressWarnings("unchecked")
public class TestAllServicesJSON {
	
	/** Logger for this class. */
	private static final Logger logger = LoggerFactory.getLogger(TestAllServicesJSON.class);

	/** The Constant strUrl. */
	public static final String strUrl = "http://dev.reportaspot.com/V2/mobile/services";

	// public static final String strUrl = "http://localhost:8082/reportaspotdispatch/V2/mobile/services";

	/** The Constant FORBIDDEN_RESULT. */
	public static final Integer FORBIDDEN_RESULT = Integer.valueOf(403);

	/** The Constant OK_RESULT. */
	public static final Integer OK_RESULT = Integer.valueOf(200);

	/** The Constant header. */
	private static final Pair<String, String> header = new Pair<String, String>(
			"SECAPIKEY",
			"BCC320BB77E65ECBD7AF14844676A4CDF63A0DECB8B96A4F1101F7CE1C83749DA4D24331A26C79847D15C634902656F0AB8063C9D2C8ED743F4960E9788C7850;f8aa9c80a9c40e96c016e76f314341d1075505b3;1354527977");

	/** The Constant userKeyHeader. */
	private static final Pair<String, String> userKeyHeader = new Pair<String, String>("X-RAS-API-USERKEY", "reportaspotUser1");

	/** The Constant passKeyHeader. */
	private static final Pair<String, String> passKeyHeader = new Pair<String, String>("X-RAS-API-PASSKEY", "reportaspot@123");

	/**
	 * Setup.
	 */
	@Before
	public void setup() {

	}

	/**
	 * Test account search report with headers.
	 */
	@Test
	public void testAccountSearchReportWithHeaders() {
		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/searchIssue", "/jsonfiles/accountSearchReport.json",
					header, userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testAccountSearchReportWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testAccountSearchReportWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAccountSearchReportWithoutHeaders failed");
		}
	}

	/**
	 * Test address search report with headers.
	 */
	@Test
	public void testAddressSearchReportWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/searchIssue", "/jsonfiles/addressSearchReport.json",
					header, userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testAddressSearchReportWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testAddressSearchReportWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAccountSearchReportWithoutHeaders failed");
		}
	}

	/**
	 * Test full outage with headers.
	 */
	@Test
	public void testFullOutageWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testFullOutageWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testFullOutageWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAccountSearchReportWithoutHeaders failed");
		}
	}

	/**
	 * Test get category metadata with headers.
	 */
	@Test
	public void testGetCategoryMetadataWithHeaders() {

		try {
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("categoryId", "7"));

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getCategoryMetadata", requestParams, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetCategoryMetadataWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetCategoryMetadataWithHeaders failed");
		}
	}

	/**
	 * Test get my issues with headers.
	 */
	@Test
	public void testGetMyIssuesWithHeaders() {

		try {
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("emailId", "ras@wz.com"));
			requestParams.add(new Pair<String, String>("date", "0"));

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getMyIssues", requestParams, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetMyIssuesWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetMyIssuesWithHeaders failed");
		}
	}

	/**
	 * Test get my notification with headers.
	 */
	@Test
	public void testGetMyNotificationsWithHeaders() {

		try {
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("emailId", "ras@wz.com"));
			requestParams.add(new Pair<String, String>("date", "0"));

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getMyNotifications", requestParams, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetMyNotificationsWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetMyNotificationsWithHeaders failed");
		}
	}

	/**
	 * Test register notification with headers.
	 */
	@Test
	public void testRegisterNotificationWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"serviceIssue\": {\"reportId\": \""
					+ JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"reporter\": { \"emailId\": \"harish@wizni.com\" },\"notification\": {\"sms\": \"0\",\"email\": \"1\",\"localNotification\": \"1\",\"pushNotification\": \"1\",\"notifyOption\": 0}}}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/registerNotification", xmlToPost, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testRegisterNotificationWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testRegisterNotificationWithHeaders failed");
		}
	}

	/**
	 * Test unregister notification with headers.
	 */
	@Test
	public void testUnRegisterNotificationWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"serviceIssue\": {\"reportId\": \""
					+ JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"reporter\": { \"emailId\": \"harish@wizni.com\" },\"notification\": {\"sms\": \"0\",\"email\": \"0\",\"localNotification\": \"0\",\"pushNotification\": \"0\",\"notifyOption\": 0}}}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/unregisterNotification", xmlToPost, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testUnRegisterNotificationWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testUnRegisterNotificationWithHeaders failed");
		}
	}

	/**
	 * Test get my outage notifications with headers.
	 */
	@Test
	public void testGetMyOutageNotificationsWithHeaders() {

		try {
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("emailId", "ras@wz.com"));
			requestParams.add(new Pair<String, String>("date", "0"));

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getMyOutageNotifications", requestParams, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetMyOutageNotificationsWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetMyOutageNotificationsWithHeaders failed");
		}
	}

	/**
	 * Test get my watchlist with headers.
	 */
	@Test
	public void testGetMyWatchlistWithHeaders() {

		try {
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("emailId", "ras@wz.com"));

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getMyWatchlist", requestParams, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetMyWatchlistWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetMyWatchlistWithHeaders failed");
		}
	}

	/**
	 * Test get recent issues with headers.
	 */
	@Test
	public void testGetRecentIssuesWithHeaders() {

		try {
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("issueId", "200"));
			requestParams.add(new Pair<String, String>("date", "0"));

			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getRecentIssues", requestParams, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetRecentIssuesWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetRecentIssuesWithHeaders failed");
		}
	}

	/**
	 * Test get service categories with headers.
	 */
	@Test
	public void testGetServiceCategoriesWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.getJSON(strUrl + "/getServiceCategories", null, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testGetServiceCategoriesWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetServiceCategoriesWithHeaders failed");
		}
	}

	/**
	 * Test partial outage with headers.
	 */
	@Test
	public void testPartialOutageWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/partialOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testPartialOutageWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testPartialOutageWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAccountSearchReportWithoutHeaders failed");
		}
	}

	/**
	 * Test phone search report with headers.
	 */
	@Test
	public void testPhoneSearchReportWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/searchIssue", "/jsonfiles/phoneSearchReport.json",
					header, userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testPhoneSearchReportWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testPhoneSearchReportWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testPhoneSearchReportWithHeaders failed");
		}
	}

	/**
	 * Test register for outage with headers.
	 */
	@Test
	public void testRegisterForOutageWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/registerForOutage", "/jsonfiles/registerForOutage.json",
					header, userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testRegisterForOutageWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAccountSearchReportWithoutHeaders failed");
		}
	}

	/**
	 * Test support issue with headers. These will fail if no proper issue is present in system on server.
	 */
	@Test
	public void testSupportIssueWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"reportId\": \"" + JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"emailAddress\": \"harish@wizni.com\",\"isSupport\": \"true\"}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/supportIssue", xmlToPost, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testSupportIssueWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testSupportIssueWithHeaders failed");
		}
	}

	/**
	 * Test spam issue with headers.These will fail if no proper issue is present in system on server.
	 */
	@Test
	public void testSpamIssueWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"reportId\": \"" + JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"emailAddress\": \"harish@wizni.com\"}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/spamIssue", xmlToPost, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testSpamIssueWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testSpamIssueWithHeaders failed");
		}
	}

	/**
	 * Test add issue comment with headers.
	 */
	@Test
	public void testAddIssueCommentWithHeaders() {

		try {

			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());

			String xmlToPost = "{\"reportId\": \"" + JSONParserCheck.getReportId(result.getValue1())
					+ "\",\"userId\": \"harish@wizni.com\" ,\"comment\": {\"text\": \"Issue updated.\"}}";

			Pair<Integer, String> result2 = JSONRequestHandler.postJSONWithString(strUrl + "/addIssueComment", xmlToPost, header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testAddIssueCommentWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAddIssueCommentWithHeaders failed");
		}
	}

	/**
	 * Test get issue with headers.
	 */
	@Test
	public void testGetIssueWithHeaders() {

		try {

			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/fullOutage.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			List<Pair<String, String>> requestParams = new ArrayList<Pair<String, String>>();
			requestParams.add(new Pair<String, String>("issueId", JSONParserCheck.getReportId(result.getValue1())));

			Pair<Integer, String> result2 = JSONRequestHandler.getJSON(strUrl + "/getIssue", requestParams, header, userKeyHeader,
					passKeyHeader);
			Assert.assertEquals(OK_RESULT, result2.getValue0());
			Assert.assertNotNull(result2.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result2.getValue1()));
		} catch (Exception e) {
			logger.error("testGetIssueWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testGetIssueWithHeaders failed");
		}
	}

	/**
	 * Test register user with headers.
	 */
	@Test
	public void testRegisterUserWithHeaders() {

		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/registerUser", "/jsonfiles/registeruser.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
		} catch (Exception e) {
			logger.error("testRegisterUserWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testAccountSearchReportWithoutHeaders failed");
		}
	}

	/**
	 * Test street light with headers.
	 */
	@Test
	public void testStreetLightWithHeaders() {
		try {
			Pair<Integer, String> result = JSONRequestHandler.postJSON(strUrl + "/createIssue", "/jsonfiles/streetLight.json", header,
					userKeyHeader, passKeyHeader);
			Assert.assertEquals(OK_RESULT, result.getValue0());
			Assert.assertNotNull(result.getValue1());
			Assert.assertTrue(JSONParserCheck.isJSONValid(result.getValue1()));
			if (logger.isDebugEnabled()) {
				logger.debug("testStreetLightWithHeaders() - {}", result.getValue1()); //$NON-NLS-1$
			}
		} catch (Exception e) {
			logger.error("testStreetLightWithHeaders()", e); //$NON-NLS-1$
			Assert.fail("testStreetLightWithHeaders failed");
		}
	}
}
