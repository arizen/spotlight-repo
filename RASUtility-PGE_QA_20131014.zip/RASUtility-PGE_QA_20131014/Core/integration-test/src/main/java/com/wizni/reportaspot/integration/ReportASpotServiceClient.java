/*
 * Copyright (c) 2012-2013 Wizni, Inc. All Rights Reserved.
 *
 * This file is part of Wizni, Inc. software licensed to you under enterprise Software License Agreement (the "License")
 * You may not use this file except in compliance with the License. For licensing contact: support@wizni.com
 * 
 * Unauthorized reverse engineering, disassembly or modifications prohibited.
 * Wizni, Inc. Confidential
 */
package com.wizni.reportaspot.integration;

import java.io.IOException;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;



/**
 * The Class ReportASpotServiceClient.
 */
public class ReportASpotServiceClient {

    /**
     * Execute get request.
     * 
     * @param url the url
     * @param headers the headers
     * @return the http response
     * @throws ClientProtocolException the client protocol exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public HttpResponse executeGetRequest(String url,Map<String, String> headers) throws ClientProtocolException, IOException{
        HttpGet request = new HttpGet(url);
        for(String key:headers.keySet()){
            request.addHeader(key, headers.get(key));
        }
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse response = httpClient.execute(request);
        return response;
    }
    
}
